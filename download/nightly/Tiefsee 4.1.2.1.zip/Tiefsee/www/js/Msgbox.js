class Msgbox {
  constructor(_i18n) {
    this._isShow = false;
    if (_i18n === void 0) {
      this.i18n = new I18n();
      this.i18n.pushData({
        msg: {
          yes: { "en": "Yes" },
          no: { "en": "No" }
        }
      });
    } else {
      this.i18n = _i18n;
    }
  }
  isShow() {
    return this._isShow;
  }
  show(json) {
    this._isShow = true;
    let txt = "";
    let type = "txt";
    let inputTxt = "";
    let isAllowClose = true;
    let isShowBtn = true;
    let arRadio = [];
    let radioValue = "";
    let funcYes = (dom2, value) => {
      this.close(dom2);
    };
    let funcClose = (dom2) => {
      this.close(dom2);
    };
    if (json.txt !== void 0) {
      txt = json.txt;
    }
    if (json.type !== void 0) {
      type = json.type;
    }
    if (json.inputTxt !== void 0) {
      inputTxt = json.inputTxt;
    }
    if (json.isAllowClose !== void 0) {
      isAllowClose = json.isAllowClose;
    }
    if (json.isShowBtn !== void 0) {
      isShowBtn = json.isShowBtn;
    }
    if (json.arRadio !== void 0) {
      arRadio = json.arRadio;
    }
    if (json.radioValue !== void 0) {
      radioValue = json.radioValue;
    }
    if (json.funcYes !== void 0) {
      funcYes = json.funcYes;
    }
    if (json.funcClose !== void 0) {
      funcClose = json.funcClose;
    }
    let htmlRadio = "";
    for (let i = 0; i < arRadio.length; i++) {
      const item = arRadio[i];
      let checked = item.value == radioValue ? "checked" : "";
      htmlRadio += `
            <label class="msgbox-radio">
                <input class="base-radio" type="radio" name="msgbox-radio" value="${item.value}" ${checked}>
                <span>${item.name}</span>
            </label>`;
    }
    if (arRadio.length > 0) {
      htmlRadio = `
            <div class="msgbox-radioList">
                ${htmlRadio}
            </div>`;
    }
    let dom = Lib.newDom(`<div class="msgbox">
                <div class="msgbox-box" active="false">
                    <div class="msgbox-close"></div>
                    <div class="msgbox-txt base-scrollbar">${txt}</div>
                    <input class="msgbox-input" type="text">
                   
                    ${htmlRadio}
                
                    <div class="msgbox-bottom">
                        <div class="msgbox-btn msgbox-btn__yes" i18n="msg.yes">${this.i18n.t("msg.yes")}</div>
                        <div class="msgbox-btn msgbox-btn__no" i18n="msg.no">${this.i18n.t("msg.no")}</div>
                    </div>
                </div>
            </div>`);
    let donBox = dom.querySelector(".msgbox-box");
    let donInput = dom.querySelector(".msgbox-input");
    let donBtnClose = dom.querySelector(".msgbox-close");
    let donBottom = dom.querySelector(".msgbox-bottom");
    let donBtnNo = dom.querySelector(".msgbox-btn__no");
    let donBtnYes = dom.querySelector(".msgbox-btn__yes");
    setTimeout(() => {
      donBox.setAttribute("active", "true");
    }, 1);
    if (json.funcYes === void 0) {
      donBtnNo.style.display = "none";
    }
    if (isAllowClose === false) {
      donBtnClose.style.display = "none";
      donBtnNo.style.display = "none";
    }
    if (isShowBtn === false) {
      donBottom.style.display = "none";
    }
    if (type !== "text") {
      donInput.style.display = "none";
    }
    donInput.value = inputTxt;
    donBtnClose.addEventListener("click", () => {
      funcClose(dom);
    });
    donBtnNo.addEventListener("click", () => {
      funcClose(dom);
    });
    donBtnYes.addEventListener("click", () => {
      let value = "";
      if (type === "txt") {
      }
      if (type === "text") {
        value = donInput.value;
      }
      if (type === "radio") {
        let radioChecked = dom.querySelector(".msgbox-radio :checked");
        if (radioChecked != null) {
          value = radioChecked.value;
        }
      }
      funcYes(dom, value);
    });
    document.body.appendChild(dom);
    if (type === "text") {
      donInput.focus();
      donInput.select();
    }
    return {
      domMsg: dom,
      domInput: donInput
    };
  }
  close(dom) {
    dom.parentNode?.removeChild(dom);
    let arMsgbox = document.querySelectorAll(".msgbox-box");
    for (let i = 0; i < arMsgbox.length; i++) {
      const item = arMsgbox[i];
      if (item.getAttribute("active") == "true") {
        this._isShow = true;
        return;
      }
    }
    this._isShow = false;
  }
  closeAll() {
    let arMsgbox = document.querySelectorAll(".msgbox");
    for (let i = 0; i < arMsgbox.length; i++) {
      const dom = arMsgbox[i];
      dom.parentNode?.removeChild(dom);
    }
    this._isShow = false;
  }
  closeNow() {
    let arMsgbox = document.querySelectorAll(".msgbox");
    if (arMsgbox.length === 0) {
      return;
    }
    if (arMsgbox.length === 1) {
      this._isShow = false;
    }
    const dom = arMsgbox[arMsgbox.length - 1];
    dom.parentNode?.removeChild(dom);
  }
  clickYes() {
    let arMsgbox = document.querySelectorAll(".msgbox");
    if (arMsgbox.length === 0) {
      return;
    }
    const dom = arMsgbox[arMsgbox.length - 1];
    const btnYes = dom.querySelector(".msgbox-btn__yes");
    btnYes.click();
  }
}
