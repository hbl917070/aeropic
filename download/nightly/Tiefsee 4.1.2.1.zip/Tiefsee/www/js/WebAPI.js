const _WebAPI = class {
  static async sendPost(url, postData) {
    let json;
    await fetch(url, {
      "body": JSON.stringify(postData),
      "method": "POST"
    }).then((response) => {
      return response.json();
    }).then((html) => {
      json = html;
    }).catch((err) => {
      console.log("sendPost Error: ", err);
    });
    return json;
  }
  static async sort(ar, type) {
    let url = APIURL + "/api/sort";
    let postData = { ar, type };
    return _WebAPI.sendPost(url, postData);
  }
  static async sort2(ar, type) {
    if (ar.length === 0) {
      return [];
    }
    let dirPath = Lib.GetDirectoryName(ar[0]);
    if (dirPath === null) {
      return [];
    }
    for (let i = 0; i < ar.length; i++) {
      const path = ar[i];
      if (path.indexOf(dirPath) !== 0) {
        dirPath = Lib.GetDirectoryName(dirPath);
      }
    }
    let retAr = [];
    let dirPathLen = dirPath.length;
    for (let i = 0; i < ar.length; i++) {
      retAr.push(ar[i].substring(dirPathLen));
    }
    if (type === "name" || type === "nameDesc") {
      retAr = await this.sort(retAr, type);
    } else {
      let url = APIURL + "/api/sort2";
      let postData = { dir: dirPath, ar: retAr, type };
      retAr = await _WebAPI.sendPost(url, postData);
    }
    for (let i = 0; i < retAr.length; i++) {
      retAr[i] = dirPath + retAr[i];
    }
    return retAr;
  }
  static async getText(path) {
    let encodePath = encodeURIComponent(path);
    let url = APIURL + `/api/getText?path=${encodePath}&r=${Math.random()}`;
    let ret = await Lib.sendGet("text", url);
    return ret;
  }
  static getPdf(fileInfo2) {
    let path = fileInfo2.Path;
    let fileTime = `LastWriteTimeUtc=${fileInfo2.LastWriteTimeUtc}`;
    let encodePath = encodeURIComponent(path);
    let url = `${APIURL}/api/getPdf?path=${encodePath}&${fileTime}`;
    return url;
  }
  static async getExif(fileInfo2, maxLength) {
    let path = fileInfo2.Path;
    let fileTime = `LastWriteTimeUtc=${fileInfo2.LastWriteTimeUtc}`;
    let encodePath = encodeURIComponent(path);
    let url = APIURL + `/api/getExif?maxLength=${maxLength}&path=${encodePath}&${fileTime}`;
    let json = await Lib.sendGet("json", url);
    return json;
  }
  static async getFileInfo2(path) {
    let s = await WV_File.GetFileInfo2(path);
    let json = JSON.parse(s);
    json.FullPath = json.Path;
    return json;
  }
  static async getFileInfo2List(arPath) {
    let url = APIURL + "/api/getFileInfo2List";
    let postData = { ar: arPath };
    let retAr = await _WebAPI.sendPost(url, postData);
    for (let i = 0; i < retAr.length; i++) {
      retAr[i].FullPath = retAr[i].Path;
    }
    return retAr;
  }
  static async getUwpList() {
    let url = APIURL + "/api/getUwpList";
    let postData = {};
    let ret = await _WebAPI.sendPost(url, postData);
    return ret;
  }
};
let WebAPI = _WebAPI;
WebAPI.Directory = class {
  static async getSiblingDir(path, arExt, maxCount) {
    let url = APIURL + "/api/directory/getSiblingDir";
    let postData = { path, arExt, maxCount };
    let retJson = await _WebAPI.sendPost(url, postData);
    let parentPath = Lib.GetDirectoryName(path) ?? path;
    let json = {};
    for (const key in retJson) {
      if (retJson.hasOwnProperty(key) == false) {
        continue;
      }
      var newKey = Lib.Combine([parentPath, key]);
      json[newKey] = retJson[key].map((value) => {
        return value;
      });
    }
    return json;
  }
  static async getFiles2(dirPath, arName) {
    let url = APIURL + "/api/directory/getFiles2";
    let postData = { dirPath, arName };
    let retAr = await _WebAPI.sendPost(url, postData);
    for (let i = 0; i < retAr.length; i++) {
      retAr[i] = dirPath + retAr[i];
    }
    return retAr;
  }
  static async getFiles(path, searchPattern) {
    let url = APIURL + "/api/directory/getFiles";
    let postData = { path, searchPattern };
    let retAr = await _WebAPI.sendPost(url, postData);
    for (let i = 0; i < retAr.length; i++) {
      retAr[i] = path + retAr[i];
    }
    return retAr;
  }
  static async getDirectories(path, searchPattern) {
    let url = APIURL + "/api/directory/getDirectories";
    let postData = { path, searchPattern };
    let retAr = await _WebAPI.sendPost(url, postData);
    for (let i = 0; i < retAr.length; i++) {
      retAr[i] = path + retAr[i];
    }
    return retAr;
  }
};
WebAPI.Img = class {
  static fileIcon(path) {
    return APIURL + "/api/getFileIcon?size=256&path=" + encodeURIComponent(path);
  }
  static async getUrl(type, fileInfo2) {
    let _path = fileInfo2.Path;
    let encodePath = encodeURIComponent(_path);
    let fileTime = `LastWriteTimeUtc=${fileInfo2.LastWriteTimeUtc}`;
    if (type === "web") {
      return Lib.pathToURL(_path) + `?${fileTime}`;
    }
    if (type === "webIcc") {
      return APIURL + `/api/img/webIcc?path=${encodePath}&${fileTime}`;
    }
    if (type === "icon") {
      return this.fileIcon(_path);
    }
    if (type === "wpf") {
      return APIURL + `/api/img/wpf?path=${encodePath}&${fileTime}`;
    }
    if (type === "magick" || type === "magickBmp") {
      return APIURL + `/api/img/magick?type=bmp&path=${encodePath}&${fileTime}`;
    }
    if (type === "magickPng") {
      return APIURL + `/api/img/magick?type=png&path=${encodePath}&${fileTime}`;
    }
    if (type === "dcraw") {
      return APIURL + `/api/img/dcraw?path=${encodePath}&${fileTime}`;
    }
    if (type === "nconvert" || type === "nconvertBmp") {
      let url = APIURL + `/api/img/nconvert?type=bmp&path=${encodePath}&${fileTime}`;
      url = Lib.pathToURL(await Lib.sendGet("text", url));
      return url;
    }
    if (type === "nconvertPng") {
      let url = APIURL + `/api/img/nconvert?type=png&path=${encodePath}&${fileTime}`;
      url = Lib.pathToURL(await Lib.sendGet("text", url));
      return url;
    }
    return APIURL + `/api/img/magick?path=${encodePath}&${fileTime}`;
  }
  static async vipsInit(vipsType, fileInfo2) {
    let _path = fileInfo2.Path;
    let encodePath = encodeURIComponent(_path);
    let fileTime = `LastWriteTimeUtc=${fileInfo2.LastWriteTimeUtc}`;
    let u = APIURL + `/api/img/vipsInit?path=${encodePath}&type=${vipsType}&${fileTime}`;
    let imgInitInfo = await Lib.sendGet("json", u);
    return imgInitInfo;
  }
  static vipsResize(scale, fileInfo2) {
    let _path = fileInfo2.Path;
    let encodePath = encodeURIComponent(_path);
    let fileTime = `LastWriteTimeUtc=${fileInfo2.LastWriteTimeUtc}`;
    let imgU = APIURL + `/api/img/vipsResize?path=${encodePath}&scale=${scale}&${fileTime}`;
    return imgU;
  }
  static async webInit(data) {
    let url = "";
    if (typeof data === "string") {
      url = data;
    } else {
      let fileInfo2 = data;
      let path = fileInfo2.Path;
      let fileTime = `LastWriteTimeUtc=${fileInfo2.LastWriteTimeUtc}`;
      url = Lib.pathToURL(path) + `?${fileTime}`;
    }
    let code = "-1";
    let width = 1;
    let height = 1;
    let img = document.createElement("img");
    await new Promise((resolve, reject) => {
      img.addEventListener("load", (e) => {
        code = "1";
        width = img.naturalWidth;
        height = img.naturalHeight;
        resolve(true);
      });
      img.addEventListener("error", (e) => {
        code = "-1";
        width = 1;
        height = 1;
        resolve(false);
      });
      img.src = url;
    });
    return {
      code,
      path: url,
      width,
      height
    };
  }
};
