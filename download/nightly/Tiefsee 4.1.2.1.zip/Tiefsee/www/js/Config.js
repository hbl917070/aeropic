class Config {
  constructor(_baseWindow) {
    this.otherAppOpenList = {
      absolute: [],
      startMenu: [
        { name: "mspaint", type: ["img"] },
        { name: "photoshop", type: ["img"] },
        { name: "illustrator", type: ["img"] },
        { name: "Lightroom", type: ["img"] },
        { name: "Paint", type: ["img"] },
        { name: "photo", type: ["img"] },
        { name: "gimp", type: ["img"] },
        { name: "FireAlpaca", type: ["img"] },
        { name: "openCanvas", type: ["img"] },
        { name: "SAI", type: ["img"] },
        { name: "Pixia", type: ["img"] },
        { name: "AzPainter2", type: ["img"] },
        { name: "CorelDRAW", type: ["img"] },
        { name: "Krita", type: ["img"] },
        { name: "Artweaver", type: ["img"] },
        { name: "Lightroom", type: ["img"] },
        { name: "Perfect Effects", type: ["img"] },
        { name: "Artweaver ", type: ["img"] },
        { name: "Honeyview", type: ["img"] },
        { name: "ACDSee", type: ["img"] },
        { name: "IrfanView", type: ["img"] },
        { name: "XnView", type: ["img"] },
        { name: "FastStone", type: ["img"] },
        { name: "Hamana", type: ["img"] },
        { name: "Vieas", type: ["img"] },
        { name: "FreeVimager", type: ["img"] },
        { name: "Imagine", type: ["img"] },
        { name: "XnConvert", type: ["img"] },
        { name: "FotoSketcher", type: ["img"] },
        { name: "PhoXo", type: ["img"] },
        { name: "ScreenSketch", type: ["img"] },
        { name: "imageGlass", type: ["img"] }
      ]
    };
    this.exif = {
      whitelist: [
        "Date/Time Original",
        "Windows XP Keywords",
        "Rating",
        "Image Width/Height",
        "Length",
        "Windows XP Title",
        "Artist",
        "Copyright",
        "Image Description",
        "Windows XP Comment",
        "User Comment",
        "Make",
        "Model",
        "Windows XP Subject",
        "F-Number",
        "Exposure Time",
        "ISO Speed Ratings",
        "Exposure Bias Value",
        "Focal Length",
        "Max Aperture Value",
        "Metering Mode",
        "Flash",
        "Focal Length 35",
        "Orientation",
        "Software",
        "Creation Time",
        "Last Write Time",
        "Textual Data",
        "Map"
      ]
    };
    this.imgSearch = {
      list: [
        { name: "sauceNAO", icon: "./img/imgSearch/saucenao.png", url: "https://saucenao.com/search.php?db=999&url={url}" },
        { name: "Yandex", icon: "./img/imgSearch/yandex.png", url: "https://yandex.com/images/search?rpt=imageview&url={url}" },
        { name: "Ascii2d", icon: "./img/imgSearch/ascii2d.png", url: "https://ascii2d.net/search/url/{url}" },
        { name: "Google", icon: "./img/imgSearch/google.png", url: "https://www.google.com/searchbyimage?sbisrc=cr_1_5_2&image_url={url}" },
        { name: "Google Lens", icon: "./img/imgSearch/googleLens.svg", url: "https://lens.google.com/uploadbyurl?url={url}" },
        { name: "Bing", icon: "./img/imgSearch/bing.png", url: "https://www.bing.com/images/search?view=detailv2&iss=sbi&FORM=SBIIDP&sbisrc=UrlPaste&idpbck=1&q=imgurl:{url}" }
      ],
      imgServer: [
        { url: "https://hbl917070.com/imgSearch/upload", timeout: 8 * 1e3 },
        { url: "https://tiefseesearchimageserver.onrender.com/imgSearch/upload", timeout: 10 * 1e3 }
      ]
    };
    this.settings = {
      theme: {
        "aeroType": "none",
        "zoomFactor": 1,
        "fontWeight": "400",
        "svgWeight": "0px",
        "--window-border-radius": 7,
        "--color-window-background": { r: 31, g: 39, b: 43, a: 0.97 },
        "--color-window-border": { r: 255, g: 255, b: 255, a: 0.25 },
        "--color-white": { r: 255, g: 255, b: 255 },
        "--color-black": { r: 0, g: 0, b: 0 },
        "--color-blue": { r: 0, g: 200, b: 255 },
        "--color-grey": { r: 30, g: 30, b: 30 }
      },
      image: {
        "dpizoom": "-1",
        "tiefseeviewImageRendering": "0",
        tiefseeviewZoomType: "full-100%",
        tiefseeviewZoomValue: 100,
        tiefseeviewAlignType: "C",
        tiefseeviewBigimgscaleRatio: 0.8
      },
      sort: {
        fileSort: "name",
        dirSort: "name"
      },
      layout: {
        fileListEnabled: true,
        fileListShowNo: true,
        fileListShowName: true,
        fileListShowWidth: 100,
        dirListEnabled: false,
        dirListShowNo: true,
        dirListShowName: true,
        dirListShowWidth: 200,
        dirListImgNumber: 3,
        mainExifEnabled: false,
        mainExifShowWidth: 150,
        mainExifMaxLine: 20,
        mainExifHorizontal: true,
        mainToolbarEnabled: true,
        mainToolbarAlign: "left",
        largeBtn: "bottom"
      },
      position: {
        left: -9999,
        top: -9999,
        width: 600,
        height: 600,
        windowState: "Normal"
      },
      mainToolbar: {
        img: [
          { "n": "prevFile", "v": false },
          { "n": "nextFile", "v": false },
          { "n": "showMenuFile", "v": true },
          { "n": "prevDir", "v": false },
          { "n": "nextDir", "v": false },
          { "n": "showMenuSort", "v": true },
          { "n": "showMenuCopy", "v": true },
          { "n": "dragDropFile", "v": true },
          { "n": "showDeleteMsg", "v": true },
          { "n": "showMenuImageSearch", "v": true },
          { "n": "bulkView", "v": true },
          { "n": "showSetting", "v": true },
          { "n": "showMenuRotation", "v": true },
          { "n": "zoomToFit", "v": true }
        ],
        pdf: [
          { "n": "prevFile", "v": false },
          { "n": "nextFile", "v": false },
          { "n": "showMenuFile", "v": true },
          { "n": "prevDir", "v": false },
          { "n": "nextDir", "v": false },
          { "n": "showMenuSort", "v": true },
          { "n": "showMenuCopy", "v": true },
          { "n": "dragDropFile", "v": true },
          { "n": "showDeleteMsg", "v": true },
          { "n": "bulkView", "v": true },
          { "n": "showSetting", "v": true }
        ],
        txt: [
          { "n": "prevFile", "v": false },
          { "n": "nextFile", "v": false },
          { "n": "showMenuFile", "v": true },
          { "n": "prevDir", "v": false },
          { "n": "nextDir", "v": false },
          { "n": "showMenuSort", "v": true },
          { "n": "showMenuCopy", "v": true },
          { "n": "dragDropFile", "v": true },
          { "n": "showDeleteMsg", "v": true },
          { "n": "bulkView", "v": true },
          { "n": "showSetting", "v": true }
        ],
        bulkView: [
          { "n": "showMenuFile", "v": true },
          { "n": "prevDir", "v": true },
          { "n": "nextDir", "v": true },
          { "n": "showMenuSort", "v": true },
          { "n": "showMenuCopy", "v": true },
          { "n": "dragDropFile", "v": true },
          { "n": "showDeleteMsg", "v": true },
          { "n": "showSetting", "v": true },
          { "n": "showBulkViewSetting", "v": true }
        ]
      },
      advanced: {
        dirListMaxCount: 5e3,
        highQualityLimit: 4e3,
        exifReadMaxLength: 2e5
      },
      quickLook: {
        keyboardSpaceRun: true,
        mouseMiddleRun: true
      },
      bulkView: {
        columns: 5,
        waterfall: "horizontal",
        gaplessMode: "off",
        fixedWidth: "off",
        align: "left",
        indentation: "off",
        show: {
          number: true,
          fileName: true,
          imageSize: false,
          fileSize: false,
          lastWriteDate: false,
          lastWriteTime: false
        },
        imgMaxCount: 100
      },
      other: {
        fileDeletingShowCheckMsg: true,
        whenInsertingFile: "auto",
        lang: ""
      },
      mouse: {
        leftDoubleClick: "maximizeWindow",
        scrollWheelButton: "none",
        mouseButton4: "prevFile",
        mouseButton5: "nextFile",
        scrollUp: "imageZoomIn",
        scrollDown: "imageZoomOut",
        scrollUpCtrl: "imageZoomIn",
        scrollDownCtrl: "imageZoomOut",
        scrollUpShift: "imageMoveRight",
        scrollDownShift: "imageMoveLeft",
        scrollUpAlt: "imageMoveUp",
        scrollDownAlt: "imageMoveDown",
        bulkViewScrollUpCtrl: "decColumns",
        bulkViewScrollDownCtrl: "incrColumns",
        bulkViewScrollUpShift: "incrFixedWidth",
        bulkViewScrollDownShift: "decFixedWidth",
        bulkViewScrollUpAlt: "prevPage",
        bulkViewScrollDownAlt: "nextPage"
      }
    };
    this._allowFile_img = [];
    this._allowFile_video = [];
    this._allowFile_pdf = [];
    this._allowFile_txt = [];
    this.baseWindow = _baseWindow;
  }
  initAllowFileType() {
    let plugin = this.baseWindow.appInfo?.plugin;
    if (plugin == null) {
      return;
    }
    (() => {
      this._allowFile_img = [
        { ext: "jpg", type: "vips", vipsType: "jpg" },
        { ext: "jpeg", type: "vips", vipsType: "jpg" },
        { ext: "jfif", type: "vips", vipsType: "jpg" },
        { ext: "jpe", type: "vips", vipsType: "jpg" },
        { ext: "png", type: "vips", vipsType: "vips" },
        { ext: "webp", type: "vips", vipsType: "vips" },
        { ext: "bmp", type: "vips", vipsType: "bitmap" },
        { ext: "apng", type: "web" },
        { ext: "gif", type: "web" },
        { ext: "svg", type: "web" },
        { ext: "ico", type: "web" },
        { ext: "tif", type: "vips", vipsType: "tif" },
        { ext: "tiff", type: "vips", vipsType: "tif" },
        { ext: "dds", type: "vips", vipsType: "wpf" },
        { ext: "psd", type: "vips", vipsType: "magick" },
        { ext: "psb", type: "vips", vipsType: "magick" },
        { ext: "pcx", type: "vips", vipsType: "magick" },
        { ext: "heic", type: "vips", vipsType: "magick" },
        { ext: "avif", type: "vips", vipsType: "wpf,magick" },
        { ext: "fits", type: "vips", vipsType: "magick" },
        { ext: "hdr", type: "vips", vipsType: "magick" },
        { ext: "miff", type: "vips", vipsType: "magick" },
        { ext: "mng", type: "vips", vipsType: "magick" },
        { ext: "otb", type: "vips", vipsType: "magick" },
        { ext: "pfm", type: "vips", vipsType: "magick" },
        { ext: "pgm", type: "vips", vipsType: "magick" },
        { ext: "ppm", type: "vips", vipsType: "magick" },
        { ext: "tga", type: "vips", vipsType: "magick" },
        { ext: "xcf", type: "vips", vipsType: "magick" },
        { ext: "xpm", type: "vips", vipsType: "magick" },
        { ext: "qoi", type: "vips", vipsType: "magick" },
        { ext: "pbm", type: "vips", vipsType: "magick" },
        { ext: "exr", type: "vips", vipsType: "magick" },
        { ext: "jpf", type: "vips", vipsType: "magick" },
        { ext: "jp2", type: "vips", vipsType: "magick" },
        { ext: "sct", type: "vips", vipsType: "magick" },
        { ext: "mef", type: "vips", vipsType: "magick" },
        { ext: "wmf", type: "vips", vipsType: "magick" },
        { ext: "mpo", type: "vips", vipsType: "magick" },
        { ext: "jxl", type: "vips", vipsType: "magick" },
        { ext: "crw", type: "vips", vipsType: "dcraw" },
        { ext: "raf", type: "vips", vipsType: "dcraw" },
        { ext: "cr2", type: "vips", vipsType: "dcraw" },
        { ext: "mrw", type: "vips", vipsType: "dcraw" },
        { ext: "nef", type: "vips", vipsType: "dcraw" },
        { ext: "x3f", type: "vips", vipsType: "dcraw" },
        { ext: "pef", type: "vips", vipsType: "dcraw" },
        { ext: "orf", type: "vips", vipsType: "dcraw" },
        { ext: "rw2", type: "vips", vipsType: "dcraw" },
        { ext: "arw", type: "vips", vipsType: "dcraw" },
        { ext: "erf", type: "vips", vipsType: "dcraw" },
        { ext: "sr2", type: "vips", vipsType: "dcraw" },
        { ext: "srw", type: "vips", vipsType: "dcraw" },
        { ext: "dng", type: "vips", vipsType: "dcraw" },
        { ext: "afphoto", type: "vips", vipsType: "extractPng" },
        { ext: "afdesign", type: "vips", vipsType: "extractPng" },
        { ext: "clip", type: "vips", vipsType: "clip" }
      ];
    })();
    (() => {
      this._allowFile_video = [
        { ext: "mp4", type: "video" },
        { ext: "webm", type: "video" },
        { ext: "ogv", type: "video" }
      ];
    })();
    (() => {
      this._allowFile_pdf = [
        { ext: "pdf", type: "pdf" },
        { ext: "ai", type: "pdf" }
      ];
      if (plugin.PDFTronWebviewer) {
        this._allowFile_pdf.push({ ext: "doc", type: "PDFTronWebviewer" }, { ext: "docx", type: "PDFTronWebviewer" }, { ext: "ppt", type: "PDFTronWebviewer" }, { ext: "pptx", type: "PDFTronWebviewer" });
      }
    })();
    (() => {
      this._allowFile_txt = [
        { ext: "sass", type: "auto" },
        { ext: "js", type: "javascript" },
        { ext: "ts", type: "typescript" },
        { ext: "ejs", type: "html" },
        { ext: "log", type: "auto" },
        { ext: "url", type: "auto" },
        { ext: "md", type: "md" },
        { ext: "markdown", type: "md" },
        { ext: "gitignore", type: "auto" },
        { ext: "csv", type: "auto" },
        { ext: "vue", type: "vue" }
      ];
      let arExt = [
        "txt",
        "abap",
        "cls",
        "azcli",
        "bat",
        "cmd",
        "bicep",
        "mligo",
        "clj",
        "cljs",
        "cljc",
        "edn",
        "coffee",
        "c",
        "h",
        "cpp",
        "cc",
        "cxx",
        "hpp",
        "hh",
        "hxx",
        "cs",
        "csx",
        "cake",
        "css",
        "cypher",
        "cyp",
        "dart",
        "dockerfile",
        "ecl",
        "ex",
        "exs",
        "flow",
        "fs",
        "fsi",
        "ml",
        "mli",
        "fsx",
        "fsscript",
        "ftl",
        "ftlh",
        "ftlx",
        "go",
        "graphql",
        "gql",
        "handlebars",
        "hbs",
        "tf",
        "tfvars",
        "hcl",
        "html",
        "htm",
        "shtml",
        "xhtml",
        "mdoc",
        "jsp",
        "asp",
        "aspx",
        "jshtm",
        "ini",
        "properties",
        "gitconfig",
        "java",
        "jav",
        "js",
        "es6",
        "jsx",
        "mjs",
        "cjs",
        "jl",
        "kt",
        "less",
        "lex",
        "lua",
        "liquid",
        "html.liquid",
        "m3",
        "i3",
        "mg",
        "ig",
        "markdown",
        "mdown",
        "mkdn",
        "mkd",
        "mdwn",
        "mdtxt",
        "mdtext",
        "s",
        "dax",
        "msdax",
        "m",
        "pas",
        "p",
        "pp",
        "ligo",
        "pl",
        "php",
        "php4",
        "php5",
        "phtml",
        "ctp",
        "pla",
        "dats",
        "sats",
        "hats",
        "pq",
        "pqm",
        "ps1",
        "psm1",
        "psd1",
        "proto",
        "jade",
        "pug",
        "py",
        "rpy",
        "pyw",
        "cpy",
        "gyp",
        "gypi",
        "qs",
        "r",
        "rhistory",
        "rmd",
        "rprofile",
        "rt",
        "cshtml",
        "redis",
        "rst",
        "rb",
        "rbx",
        "rjs",
        "gemspec",
        "pp",
        "rs",
        "rlib",
        "sb",
        "scala",
        "sc",
        "sbt",
        "scm",
        "ss",
        "sch",
        "rkt",
        "scss",
        "sh",
        "bash",
        "sol",
        "aes",
        "rq",
        "sql",
        "st",
        "iecst",
        "iecplc",
        "lc3lib",
        "swift",
        "sv",
        "svh",
        "v",
        "vh",
        "tcl",
        "twig",
        "tsx",
        "vb",
        "xml",
        "dtd",
        "ascx",
        "csproj",
        "config",
        "wxi",
        "wxl",
        "wxs",
        "xaml",
        "svgz",
        "opf",
        "xsl",
        "yaml",
        "yml",
        "json",
        "bowerrc",
        "jshintrc",
        "jscsrc",
        "eslintrc",
        "babelrc",
        "har"
      ];
      for (let i = 0; i < arExt.length; i++) {
        this._allowFile_txt.push({ ext: arExt[i], type: "auto" });
      }
    })();
  }
  allowFileType(type) {
    let plugin = this.baseWindow.appInfo?.plugin;
    if (plugin == null) {
      return [];
    }
    if (this._allowFile_img.length === 0) {
      this.initAllowFileType();
    }
    if (type === GroupType.img) {
      return this._allowFile_img;
    }
    if (type === GroupType.video) {
      return this._allowFile_video;
    }
    if (type === GroupType.pdf) {
      return this._allowFile_pdf;
    }
    if (type === GroupType.txt) {
      return this._allowFile_txt;
    }
    return [];
  }
  getAllowFileTypeItem(type, ext) {
    let ar = this.allowFileType(type);
    for (let i = 0; i < ar.length; i++) {
      const item = ar[i];
      if (item.ext === ext) {
        return item;
      }
    }
    return null;
  }
}
var GroupType = {
  welcome: "welcome",
  none: "none",
  unknown: "unknown",
  img: "img",
  imgs: "imgs",
  pdf: "pdf",
  office: "office",
  txt: "txt",
  md: "md",
  monacoEditor: "monacoEditor",
  video: "video",
  bulkView: "bulkView",
  bulkViewSub: "bulkViewSub"
};
