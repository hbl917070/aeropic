class LibIframe {
  constructor() {
    this._theme = {};
    this.isReadonly = false;
    window.addEventListener("keydown", (e) => {
      if (this.isReadonly === false) {
        return;
      }
      if (e.code == "KeyC" && e.ctrlKey === true) {
      } else if (e.code == "KeyA" && e.ctrlKey === true) {
      } else {
        e.preventDefault();
        e.stopPropagation();
      }
    }, true);
  }
  async closeIME() {
    var domFocus = document.activeElement;
    var text = document.createElement("input");
    text.setAttribute("type", "url");
    text.style.position = "relative";
    text.style.opacity = "0";
    text.style.pointerEvents = "none";
    document.body.appendChild(text);
    text.focus();
    await new Promise((resolve, reject) => {
      setTimeout(() => {
        text.blur();
        document.body.removeChild(text);
        if (domFocus !== null) {
          domFocus.focus();
        }
        resolve(0);
      }, 10);
    });
  }
  initEventDrop(dom) {
    dom.addEventListener("dragenter", (e) => {
      e.stopPropagation();
      e.preventDefault();
    }, false);
    dom.addEventListener("dragover", (e) => {
      e.stopPropagation();
      e.preventDefault();
    }, false);
    dom.addEventListener("drop", (e) => {
      const dropEvent = new CustomEvent("drop", {
        bubbles: true,
        detail: {
          event: e
        }
      });
      window.parent.dispatchEvent(dropEvent);
    }, true);
  }
  initTextHotkey() {
    window.addEventListener("keydown", async (e) => {
      if (e.code === "KeyS" && e.ctrlKey) {
        let json = {
          type: "saveText"
        };
        this.postMsg(json);
      }
    }, true);
  }
  postMsg(json) {
    parent.postMessage(json, "*");
  }
  getAppInfo() {
    let getUrlString = location.href;
    let url = new URL(getUrlString);
    let appInfo = url.searchParams.get("appInfo");
    if (appInfo == null) {
      return {};
    }
    let json = JSON.parse(appInfo);
    return json;
  }
  getPluginPath(appInfo) {
    if (appInfo === void 0) {
      appInfo = this.getAppInfo();
    }
    let appDataPath = appInfo.appDataPath.replace(/\\/g, "/");
    let pathLib = "file:///" + appDataPath + "/Plugin";
    return pathLib;
  }
  getLang() {
    let getUrlString = location.href;
    let url = new URL(getUrlString);
    let lang = url.searchParams.get("lang");
    return lang;
  }
  initTheme() {
    let strTheme = window.localStorage.getItem("settings.theme");
    if (strTheme === null) {
      return null;
    }
    let theme = JSON.parse(strTheme);
    function getTheme() {
      let bg = theme["--color-window-background"];
      let n = (bg.r > 127 ? 1 : 0) + (bg.g > 127 ? 1 : 0) + (bg.b > 127 ? 1 : 0);
      if (n >= 2) {
        return "light";
      }
      return "dark";
    }
    theme["windowBackground"] = theme["--color-window-background"];
    theme["windowBorder"] = theme["--color-window-border"];
    theme["white"] = theme["--color-white"];
    theme["black"] = theme["--color-black"];
    theme["blue"] = theme["--color-blue"];
    theme["grey"] = theme["--color-grey"];
    theme["theme"] = getTheme();
    this._theme = theme;
    return theme;
  }
  colorToHex(color) {
    let c = this.decimalToHex(color.r, 2) + this.decimalToHex(color.g, 2) + this.decimalToHex(color.b, 2);
    return c;
  }
  decimalToHex(d, padding) {
    var hex = Number(d).toString(16);
    padding = typeof padding === "undefined" || padding === null ? padding = 2 : padding;
    while (hex.length < padding) {
      hex = "0" + hex;
    }
    return hex;
  }
  setReadonly(val) {
    this.isReadonly = val;
  }
  async addScript(src) {
    var script = document.createElement("script");
    script.src = src;
    document.head.appendChild(script);
    await new Promise((resolve, reject) => {
      script.onload = function() {
        resolve(1);
      };
    });
  }
  openUrl(url) {
    if (url.indexOf("http:") === 0 || url.indexOf("https:") === 0) {
      let json = {
        type: "openUrl",
        data: url
      };
      this.postMsg(json);
    } else {
      let json = {
        type: "openFile",
        data: url
      };
      this.postMsg(json);
    }
  }
}
