class DirSort {
  constructor(M) {
    var dom_dirSort_name = document.getElementById("menuitem-dirSort-name");
    var dom_dirSort_lastWriteTime = document.getElementById("menuitem-dirSort-lastWriteTime");
    var dom_dirSort_lastAccessTime = document.getElementById("menuitem-dirSort-lastAccessTime");
    var dom_dirSort_creationTime = document.getElementById("menuitem-dirSort-creationTime");
    var dom_dirSort_random = document.getElementById("menuitem-dirSort-random");
    var dom_dirSort_asc = document.getElementById("menuitem-dirSort-asc");
    var dom_dirSort_desc = document.getElementById("menuitem-dirSort-desc");
    var yesSvgTxt = SvgList["yes.svg"];
    var sortType = DirSortType.name;
    var orderbyType = DirOrderbyType.asc;
    this.readSortType = readSortType;
    this.updateMenu = updateMenu;
    this.sort = sort;
    dom_dirSort_name.addEventListener("click", () => {
      sortType = DirSortType.name;
      updateSort();
    });
    dom_dirSort_lastWriteTime.addEventListener("click", () => {
      sortType = DirSortType.lastWriteTime;
      updateSort();
    });
    dom_dirSort_lastAccessTime.addEventListener("click", () => {
      sortType = DirSortType.lastAccessTime;
      updateSort();
    });
    dom_dirSort_creationTime.addEventListener("click", () => {
      sortType = DirSortType.creationTime;
      updateSort();
    });
    dom_dirSort_random.addEventListener("click", () => {
      sortType = DirSortType.random;
      updateSort();
    });
    dom_dirSort_asc.addEventListener("click", () => {
      orderbyType = DirOrderbyType.asc;
      updateSort();
    });
    dom_dirSort_desc.addEventListener("click", () => {
      orderbyType = DirOrderbyType.desc;
      updateSort();
    });
    async function updateSort() {
      if (orderbyType === DirOrderbyType.desc) {
        if (sortType === DirSortType.name) {
          sortType = DirSortType.nameDesc;
        }
        if (sortType === DirSortType.lastWriteTime) {
          sortType = DirSortType.lastWriteTimeDesc;
        }
        if (sortType === DirSortType.lastAccessTime) {
          sortType = DirSortType.lastAccessTimeDesc;
        }
        if (sortType === DirSortType.creationTime) {
          sortType = DirSortType.creationTimeDesc;
        }
      }
      if (orderbyType === DirOrderbyType.asc) {
        if (sortType === DirSortType.nameDesc) {
          sortType = DirSortType.name;
        }
        if (sortType === DirSortType.lastWriteTimeDesc) {
          sortType = DirSortType.lastWriteTime;
        }
        if (sortType === DirSortType.lastAccessTimeDesc) {
          sortType = DirSortType.lastAccessTime;
        }
        if (sortType === DirSortType.creationTimeDesc) {
          sortType = DirSortType.creationTime;
        }
      }
      await sort();
      let dirPath = M.fileLoad.getDirPath();
      let dirParentPath = Lib.GetDirectoryName(dirPath);
      if (dirParentPath === null) {
        dirParentPath = dirPath;
      }
      setDirSortType(dirParentPath, sortType);
      M.fileLoad.updateTitle();
      M.mainDirList.init();
      M.mainDirList.updateLocation();
      updateMenu();
    }
    function updateMenu() {
      dom_dirSort_name.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_dirSort_lastWriteTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_dirSort_lastAccessTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_dirSort_creationTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_dirSort_random.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_dirSort_asc.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_dirSort_desc.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      if (sortType === DirSortType.name || sortType === DirSortType.nameDesc) {
        dom_dirSort_name.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (sortType === DirSortType.lastWriteTime || sortType === DirSortType.lastWriteTimeDesc) {
        dom_dirSort_lastWriteTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (sortType === DirSortType.lastAccessTime || sortType === DirSortType.lastAccessTimeDesc) {
        dom_dirSort_lastAccessTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (sortType === DirSortType.creationTime || sortType === DirSortType.creationTimeDesc) {
        dom_dirSort_creationTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (sortType === DirSortType.random) {
        dom_dirSort_random.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (orderbyType === DirOrderbyType.asc) {
        dom_dirSort_asc.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (orderbyType === DirOrderbyType.desc) {
        dom_dirSort_desc.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
    }
    async function sort(path) {
      if (path === void 0) {
        path = M.fileLoad.getDirPath();
      }
      let arDir = M.fileLoad.getWaitingDir();
      let arKey = M.fileLoad.getWaitingDirKey();
      if (arKey.length <= 1) {
        return;
      }
      arKey = await WebAPI.sort2(arKey, sortType);
      let ar = {};
      for (let i = 0; i < arKey.length; i++) {
        const dirPath = arKey[i];
        ar[dirPath] = arDir[dirPath];
      }
      M.fileLoad.setWaitingDir(ar);
      await M.fileLoad.updateFlagDir(path);
    }
    function setDirSortType(dirPath, _sortType) {
      let t = window.localStorage.getItem("sortDir");
      let json = {};
      if (t !== null) {
        json = JSON.parse(t);
      }
      json[dirPath] = sortType;
      window.localStorage.setItem("sortDir", JSON.stringify(json));
    }
    function readSortType(dirPath) {
      let t = window.localStorage.getItem("sortDir");
      if (t === null) {
        t = "{}";
      }
      let json = JSON.parse(t);
      let _sortType = json[dirPath];
      if (_sortType !== void 0) {
        sortType = _sortType;
      } else {
        let defaultSort = M.config.settings.sort["dirSort"];
        if (Object.keys(DirSortType).indexOf(defaultSort) === -1) {
          defaultSort = DirSortType.name;
        }
        sortType = defaultSort;
      }
      if (sortType.indexOf("Desc") !== -1) {
        orderbyType = DirOrderbyType.desc;
      } else {
        orderbyType = DirOrderbyType.asc;
      }
    }
  }
}
var DirSortType = {
  name: "name",
  nameDesc: "nameDesc",
  lastWriteTime: "lastWriteTime",
  lastWriteTimeDesc: "lastWriteTimeDesc",
  lastAccessTime: "lastAccessTime",
  lastAccessTimeDesc: "lastAccessTimeDesc",
  creationTime: "creationTime",
  creationTimeDesc: "creationTimeDesc",
  random: "random"
};
var DirOrderbyType = {
  desc: "desc",
  asc: "asc"
};
