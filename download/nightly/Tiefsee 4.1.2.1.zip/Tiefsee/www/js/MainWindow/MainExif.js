class MainExif {
  constructor(M) {
    this.init = init;
    this.setEnabled = setEnabled;
    this.setHide = setHide;
    this.setItemWidth = setItemWidth;
    this.setHorizontal = setHorizontal;
    var dom_mainExif = document.getElementById("mainExif");
    var dom_mainExifList = document.getElementById("mainExifList");
    var dom_dragbar_mainFileList = document.getElementById("dragbar-mainExif");
    var fileInfo2;
    var isHide = false;
    var isEnabled = true;
    var dragbar = new Dragbar();
    dragbar.init("left", dom_mainExif, dom_dragbar_mainFileList, M.dom_mainR);
    dragbar.setEventStart(() => {
    });
    dragbar.setEventMove((val) => {
      if (val < 10) {
        dom_mainExif.style.opacity = "0";
        dragbar.setPosition(0);
      } else {
        dom_mainExif.style.opacity = "1";
        setItemWidth(val);
      }
    });
    dragbar.setEventEnd((val) => {
      if (val < 10) {
        setEnabled(false);
      }
    });
    function setHide(val) {
      isHide = val;
      if (val) {
        dom_mainExif.setAttribute("hide", "true");
        dragbar.setEnabled(false);
      } else {
        dom_mainExif.setAttribute("hide", "");
        dragbar.setEnabled(M.config.settings.layout.mainExifEnabled);
      }
    }
    function setEnabled(val) {
      if (val) {
        dom_mainExif.setAttribute("active", "true");
      } else {
        dom_mainExif.setAttribute("active", "");
      }
      M.config.settings.layout.mainExifEnabled = val;
      dragbar.setEnabled(val);
      dom_mainExif.style.opacity = "1";
      if (isEnabled === val) {
        return;
      }
      isEnabled = val;
      load();
    }
    function setItemWidth(val) {
      let valMin = 150;
      let valMax = 400;
      if (val <= valMin) {
        val = valMin;
      }
      if (val >= valMax) {
        val = valMax;
      }
      M.config.settings.layout.mainExifShowWidth = val;
      dom_mainExif.style.width = val + "px";
      dragbar.setPosition(val);
    }
    function init(_fileInfo2, noCheckPath = false) {
      fileInfo2 = _fileInfo2;
      load(noCheckPath);
    }
    async function load(noCheckPath = false) {
      if (isEnabled === false) {
        return;
      }
      dom_mainExifList.innerHTML = "";
      if (fileInfo2.Type === "none") {
        return;
      }
      let path = fileInfo2.Path;
      let maxLength = M.config.settings.advanced.exifReadMaxLength;
      let json = await WebAPI.getExif(fileInfo2, maxLength);
      if (json.code != "1") {
        return;
      }
      if (noCheckPath === false) {
        if (M.fileLoad.getFilePath() !== path) {
          return;
        }
      }
      let GPS_lat = getItem(json.data, "GPS Latitude");
      let GPS_lng = getItem(json.data, "GPS Longitude");
      if (GPS_lat === `0\xB0 0' 0"` && GPS_lng === `0\xB0 0' 0"`) {
        GPS_lat = void 0;
        GPS_lng = void 0;
      }
      let hasGPS = GPS_lat !== void 0 && GPS_lng !== void 0;
      if (hasGPS) {
        json.data.push({ group: "GPS", name: "Map", value: `${GPS_lat},${GPS_lng}` });
      }
      let ar = json.data;
      let whitelist = M.config.exif.whitelist;
      for (let i = 0; i < whitelist.length; i++) {
        let name = whitelist[i];
        let value = getItem(ar, name);
        if (value === void 0) {
          continue;
        } else if (name === "Map") {
          value = encodeURIComponent(value);
          let mapHtml = `
						<div class="mainExifItem">
							<div class="mainExifMap">
								<iframe class="mainExifMapIframe" src="https://maps.google.com.tw/maps?q=${value}&z=16&output=embed"></iframe>
							</div>
						</div>`;
          dom_mainExifList.appendChild(Lib.newDom(mapHtml));
        } else if (name === "User Comment" && value.indexOf("Steps: ") !== -1 && value.indexOf("Seed: ") !== -1) {
          ar.push({
            group: "PNG-tEXt",
            name: "Textual Data",
            value: "parameters: " + value
          });
        } else if (name === "Textual Data") {
          let vals = getItems(ar, name);
          for (let i2 = 0; i2 < vals.length; i2++) {
            let val = vals[i2];
            let x = val.indexOf(": ");
            if (x === -1) {
              dom_mainExifList.appendChild(getItemHtml(name, val));
            } else {
              name = val.substring(0, x);
              val = val.substring(x + 1);
              if (name === "Comment") {
                try {
                  if (val.indexOf(`"steps": `) !== -1) {
                    let jsonComment = JSON.parse(val);
                    let arCommentkey = Object.keys(jsonComment);
                    for (let i3 = 0; i3 < arCommentkey.length; i3++) {
                      let keyComment = arCommentkey[i3];
                      let valComment = jsonComment[keyComment];
                      dom_mainExifList.appendChild(getItemHtml(keyComment, valComment));
                    }
                  } else {
                    dom_mainExifList.appendChild(getItemHtml(name, val));
                  }
                } catch (e) {
                  dom_mainExifList.appendChild(getItemHtml(name, val));
                }
              } else if (name === "parameters") {
                let parseParameters2 = function(input) {
                  input = input.replace(/\\"/g, "\uFDD9");
                  let parts = input.split(/,(?=(?:[^"]|"[^"]*")*$)/).map((s) => s.replace(/\uFDD9/g, '\\"').trim());
                  let result = [];
                  for (let i3 = 0; i3 < parts.length; i3++) {
                    let subParts = parts[i3].split(":");
                    let title = subParts[0].trim();
                    let text = subParts.slice(1).join(":").trim();
                    if (text.startsWith('"') && text.endsWith('"')) {
                      text = text.slice(1, -1);
                      text = text.replace(/\\["]/g, '"');
                    }
                    result.push({ title, text });
                  }
                  return result;
                };
                var parseParameters = parseParameters2;
                let promptSplit = val.indexOf("Negative prompt: ");
                let otherSplit = val.indexOf("Steps: ");
                if (promptSplit !== -1 && otherSplit !== -1) {
                  dom_mainExifList.appendChild(getItemHtml("Prompt", val.substring(0, promptSplit)));
                  dom_mainExifList.appendChild(getItemHtml("Negative prompt", val.substring(promptSplit + 17, otherSplit)));
                  let otherText = val.substring(otherSplit);
                  let arOther = parseParameters2(otherText);
                  for (let i3 = 0; i3 < arOther.length; i3++) {
                    const title = arOther[i3].title;
                    const text = arOther[i3].text;
                    dom_mainExifList.appendChild(getItemHtml(title, text));
                  }
                } else if (promptSplit === -1 && otherSplit !== -1) {
                  dom_mainExifList.appendChild(getItemHtml("Prompt", val.substring(0, otherSplit)));
                  let otherText = val.substring(otherSplit);
                  let arOther = parseParameters2(otherText);
                  for (let i3 = 0; i3 < arOther.length; i3++) {
                    const title = arOther[i3].title;
                    const text = arOther[i3].text;
                    dom_mainExifList.appendChild(getItemHtml(title, text));
                  }
                } else {
                  dom_mainExifList.appendChild(getItemHtml(name, val));
                }
              } else {
                dom_mainExifList.appendChild(getItemHtml(name, val));
              }
            }
          }
        } else {
          let nameI18n = `exif.name.${name}`;
          let valueI18n = "";
          if (name === "Metering Mode") {
            value = M.i18n.t(`exif.value.${name}.${value}`);
            valueI18n = `exif.value.${name}.${value}`;
          }
          if (name === "Flash") {
            value = M.i18n.t(`exif.value.${name}.${value}`);
            valueI18n = `exif.value.${name}.${value}`;
          }
          if (name === "Length") {
            value = Lib.getFileLength(Number(value));
          }
          name = M.i18n.t(`exif.name.${name}`);
          dom_mainExifList.appendChild(getItemHtml(name, value, nameI18n, valueI18n));
        }
      }
    }
    function getItemHtml(name, value, nameI18n = "", valueI18n = "") {
      let oVal = value;
      name = name.toString();
      value = value.toString();
      name = Lib.escape(name);
      value = Lib.escape(value);
      value = value.replace(/\n/g, "<br>");
      let html = `
				<div class="mainExifItem">
					<div class="mainExifName" i18n="${nameI18n}">${name}</div>
					<div class="mainExifValue" i18n="${valueI18n}">${value}</div>
					<div class="mainExifCopyBtn" title="${M.i18n.t("menu.copy")}">${SvgList["tool-copy.svg"]}</div>
				</div>`;
      let div = Lib.newDom(html);
      let btn = div.querySelector(".mainExifCopyBtn");
      btn.addEventListener("click", async () => {
        await WV_System.SetClipboard_Txt(oVal);
        Toast.show(M.i18n.t("msg.copyExif", { v: name }), 1e3 * 3);
      });
      return div;
    }
    function getItems(ar, key) {
      let arOutput = [];
      for (let i = 0; i < ar.length; i++) {
        let item = ar[i];
        if (item.name == key) {
          arOutput.push(item.value);
        }
      }
      return arOutput;
    }
    function getItem(ar, key) {
      for (let i = 0; i < ar.length; i++) {
        let item = ar[i];
        if (item.name == key) {
          return item.value;
        }
      }
      return void 0;
    }
    function setHorizontal(val) {
      if (val) {
        dom_mainExif.classList.add("mainExif--horizontal");
      } else {
        dom_mainExif.classList.remove("mainExif--horizontal");
      }
    }
  }
}
