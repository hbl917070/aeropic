class FileSort {
  constructor(M) {
    var dom_fileSort_name = document.getElementById("menuitem-fileSort-name");
    var dom_fileSort_lastWriteTime = document.getElementById("menuitem-fileSort-lastWriteTime");
    var dom_fileSort_length = document.getElementById("menuitem-fileSort-length");
    var dom_fileSort_lastAccessTime = document.getElementById("menuitem-fileSort-lastAccessTime");
    var dom_fileSort_creationTime = document.getElementById("menuitem-fileSort-creationTime");
    var dom_fileSort_random = document.getElementById("menuitem-fileSort-random");
    var dom_fileSort_asc = document.getElementById("menuitem-fileSort-asc");
    var dom_fileSort_desc = document.getElementById("menuitem-fileSort-desc");
    var yesSvgTxt = SvgList["yes.svg"];
    var sortType = FileSortType.name;
    var orderbyType = FileOrderbyType.asc;
    this.readSortType = readSortType;
    this.updateMenu = updateMenu;
    this.sort = sort;
    this.getSortType = () => {
      return sortType;
    };
    this.getOrderbyType = () => {
      return orderbyType;
    };
    dom_fileSort_name.addEventListener("click", () => {
      sortType = FileSortType.name;
      updateSort();
    });
    dom_fileSort_lastWriteTime.addEventListener("click", () => {
      sortType = FileSortType.lastWriteTime;
      updateSort();
    });
    dom_fileSort_length.addEventListener("click", () => {
      sortType = FileSortType.length;
      updateSort();
    });
    dom_fileSort_lastAccessTime.addEventListener("click", () => {
      sortType = FileSortType.lastAccessTime;
      updateSort();
    });
    dom_fileSort_creationTime.addEventListener("click", () => {
      sortType = FileSortType.creationTime;
      updateSort();
    });
    dom_fileSort_random.addEventListener("click", () => {
      sortType = FileSortType.random;
      updateSort();
    });
    dom_fileSort_asc.addEventListener("click", () => {
      orderbyType = FileOrderbyType.asc;
      updateSort();
    });
    dom_fileSort_desc.addEventListener("click", () => {
      orderbyType = FileOrderbyType.desc;
      updateSort();
    });
    async function updateSort() {
      if (orderbyType === FileOrderbyType.desc) {
        if (sortType === FileSortType.name) {
          sortType = FileSortType.nameDesc;
        }
        if (sortType === FileSortType.lastWriteTime) {
          sortType = FileSortType.lastWriteTimeDesc;
        }
        if (sortType === FileSortType.length) {
          sortType = FileSortType.lengthDesc;
        }
        if (sortType === FileSortType.lastAccessTime) {
          sortType = FileSortType.lastAccessTimeDesc;
        }
        if (sortType === FileSortType.creationTime) {
          sortType = FileSortType.creationTimeDesc;
        }
      }
      if (orderbyType === FileOrderbyType.asc) {
        if (sortType === FileSortType.nameDesc) {
          sortType = FileSortType.name;
        }
        if (sortType === FileSortType.lastWriteTimeDesc) {
          sortType = FileSortType.lastWriteTime;
        }
        if (sortType === FileSortType.lengthDesc) {
          sortType = FileSortType.length;
        }
        if (sortType === FileSortType.lastAccessTimeDesc) {
          sortType = FileSortType.lastAccessTime;
        }
        if (sortType === FileSortType.creationTimeDesc) {
          sortType = FileSortType.creationTime;
        }
      }
      let path = M.fileLoad.getFilePath();
      let dirPath = Lib.GetDirectoryName(path);
      if (dirPath === null) {
        return;
      }
      setFileSortType(dirPath);
      let ar = await sort(M.fileLoad.getWaitingFile());
      M.fileLoad.setFlagFile(0);
      for (let i = 0; i < ar.length; i++) {
        if (ar[i] == path) {
          M.fileLoad.setFlagFile(i);
          break;
        }
      }
      M.fileLoad.setWaitingFile(ar);
      M.fileLoad.updateTitle();
      M.mainFileList.init();
      M.mainFileList.updateLocation();
      updateMenu();
      if (M.fileLoad.getIsBulkView()) {
        M.bulkView.load();
      }
    }
    function updateMenu() {
      dom_fileSort_name.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_fileSort_lastWriteTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_fileSort_length.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_fileSort_lastAccessTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_fileSort_creationTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_fileSort_random.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_fileSort_asc.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      dom_fileSort_desc.getElementsByClassName("menu-hor-icon")[0].innerHTML = "";
      if (sortType === FileSortType.name || sortType === FileSortType.nameDesc) {
        dom_fileSort_name.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (sortType === FileSortType.lastWriteTime || sortType === FileSortType.lastWriteTimeDesc) {
        dom_fileSort_lastWriteTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (sortType === FileSortType.length || sortType === FileSortType.lengthDesc) {
        dom_fileSort_length.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (sortType === FileSortType.lastAccessTime || sortType === FileSortType.lastAccessTimeDesc) {
        dom_fileSort_lastAccessTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (sortType === FileSortType.creationTime || sortType === FileSortType.creationTimeDesc) {
        dom_fileSort_creationTime.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (sortType === FileSortType.random) {
        dom_fileSort_random.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (orderbyType === FileOrderbyType.asc) {
        dom_fileSort_asc.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
      if (orderbyType === FileOrderbyType.desc) {
        dom_fileSort_desc.getElementsByClassName("menu-hor-icon")[0].innerHTML = yesSvgTxt;
      }
    }
    async function sort(arWaitingFile) {
      arWaitingFile = await WebAPI.sort2(arWaitingFile, sortType);
      return arWaitingFile;
    }
    function setFileSortType(dirPath) {
      let t = window.localStorage.getItem("sortFile");
      let json = {};
      if (t !== null) {
        json = JSON.parse(t);
      }
      json[dirPath] = sortType;
      window.localStorage.setItem("sortFile", JSON.stringify(json));
    }
    function readSortType(dirPath) {
      let t = window.localStorage.getItem("sortFile");
      if (t === null) {
        t = "{}";
      }
      let json = JSON.parse(t);
      let _sortType = json[dirPath];
      if (_sortType !== void 0) {
        sortType = _sortType;
      } else {
        let defaultSort = M.config.settings.sort["fileSort"];
        if (Object.keys(FileSortType).indexOf(defaultSort) === -1) {
          defaultSort = FileSortType.name;
        }
        sortType = defaultSort;
      }
      if (sortType.indexOf("Desc") !== -1) {
        orderbyType = FileOrderbyType.desc;
      } else {
        orderbyType = FileOrderbyType.asc;
      }
    }
  }
}
var FileSortType = {
  name: "name",
  nameDesc: "nameDesc",
  lastWriteTime: "lastWriteTime",
  lastWriteTimeDesc: "lastWriteTimeDesc",
  length: "length",
  lengthDesc: "lengthDesc",
  lastAccessTime: "lastAccessTime",
  lastAccessTimeDesc: "lastAccessTimeDesc",
  creationTime: "creationTime",
  creationTimeDesc: "creationTimeDesc",
  random: "random"
};
var FileOrderbyType = {
  desc: "desc",
  asc: "asc"
};
