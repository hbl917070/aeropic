class MainToolbar {
  constructor(M) {
    var ar = [];
    this.setEnabled = setEnabled;
    this.getArrray = getArrray;
    init();
    function init() {
      initToolbarImg();
      initToolbarPdf();
      initToolbarTxt();
      initToolbarWelcome();
      initBulkView();
      if (M === null) {
        return;
      }
      for (let i = 0; i < ar.length; i++) {
        const item = ar[i];
        if (item.type === "html") {
          addToolbarHtml({
            group: item.group,
            html: item.html,
            i18n: item.i18n,
            func: item.func
          });
        }
        if (item.type === "hr") {
          addToolbarHr({
            group: item.group,
            func: item.func
          });
        }
        if (item.type === "button") {
          addToolbarBtn({
            group: item.group,
            name: item.name,
            icon: item.icon,
            i18n: item.i18n,
            func: item.func
          });
        }
      }
    }
    function getArrray() {
      return ar;
    }
    function setEnabled(val) {
      if (M == null) {
        return;
      }
      if (val) {
        M.dom_toolbar.style.display = "";
      } else {
        M.dom_toolbar.style.display = "none";
      }
      M.config.settings.layout.mainToolbarEnabled = val;
    }
    function initToolbarImg() {
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.prevFile",
        group: GroupType.img,
        name: "prevFile",
        icon: "tool-prev.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.prevFile();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.nextFile",
        group: GroupType.img,
        name: "nextFile",
        icon: "tool-next.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.nextFile();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuFile",
        group: GroupType.img,
        name: "showMenuFile",
        icon: "tool-open.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuFile(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.prevDir",
        group: GroupType.img,
        name: "prevDir",
        icon: "tool-prevDir.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.prevDir();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.nextDir",
        group: GroupType.img,
        name: "nextDir",
        icon: "tool-nextDir.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.nextDir();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuSort",
        group: GroupType.img,
        name: "showMenuSort",
        icon: "tool-sort.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuSort(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuCopy",
        group: GroupType.img,
        name: "showMenuCopy",
        icon: "tool-copy.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuCopy(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.dragDropFile",
        group: GroupType.img,
        name: "dragDropFile",
        icon: "tool-dragDropFile.svg",
        func: (btn) => {
          btn.addEventListener("mousedown", (e) => {
            if (e.button === 0) {
              M?.script.file.dragDropFile();
            }
          });
          btn.addEventListener("mousedown", (e) => {
            if (e.button === 2) {
              M?.script.file.showContextMenu();
            }
          });
          btn.setAttribute("data-menu", "none");
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showDeleteFileMsg",
        group: GroupType.img,
        name: "showDeleteMsg",
        icon: "tool-delete.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.showDeleteMsg();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuImageSearch",
        group: GroupType.img,
        name: "showMenuImageSearch",
        icon: "tool-search.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuImageSearch(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.bulkView",
        group: GroupType.img,
        name: "bulkView",
        icon: "tool-bulkView.svg",
        func: (btn) => {
          btn.addEventListener("click", async () => {
            M?.script.bulkView.show();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showSetting",
        group: GroupType.img,
        name: "showSetting",
        icon: "tool-setting.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.setting.showSetting();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuRotation",
        group: GroupType.img,
        name: "showMenuRotation",
        icon: "tool-rotate.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuRotation(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.zoomToFit",
        group: GroupType.img,
        name: "zoomToFit",
        icon: "tool-full.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.img.zoomToFit();
          });
        }
      });
      ar.push({
        type: "html",
        html: `
                    <div class="main-toolbar-btn js-noDrag">
                        <div style="margin:0 3px; user-select:none; pointer-events:none;" data-name="btnScale">100%</div>
                    </div>
                `,
        i18n: "menu.infoZoomRatio",
        group: GroupType.img,
        name: "infoZoomRatio",
        icon: "",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.img.zoomTo100();
          });
        }
      });
      ar.push({
        type: "html",
        html: `
                    <div class="main-toolbar-txt" data-name="infoSize">
                        <!-- 100<br>200 -->
                    </div>
                `,
        i18n: "menu.infoSize",
        group: GroupType.img,
        name: "infoSize",
        icon: "",
        func: (btn) => {
        }
      });
      ar.push({
        type: "html",
        html: `
                    <div class="main-toolbar-txt" data-name="infoType">
                        <!-- JPG<br>123.4MB -->
                    </div>
                `,
        i18n: "menu.infoType",
        group: GroupType.img,
        name: "infoType",
        icon: "",
        func: (btn) => {
        }
      });
      ar.push({
        type: "html",
        html: `
                    <div class="main-toolbar-txt" data-name="infoWriteTime">
                        <!--2022-05-02<br>01:19:49 -->
                    </div>
                `,
        i18n: "menu.infoWriteTime",
        group: GroupType.img,
        name: "infoWriteTime",
        icon: "",
        func: (btn) => {
        }
      });
    }
    function initToolbarPdf() {
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.prevFile",
        group: GroupType.pdf,
        name: "prevFile",
        icon: "tool-prev.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.prevFile();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.nextFile",
        group: GroupType.pdf,
        name: "nextFile",
        icon: "tool-next.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.nextFile();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuFile",
        group: GroupType.pdf,
        name: "showMenuFile",
        icon: "tool-open.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuFile(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.prevDir",
        group: GroupType.pdf,
        name: "prevDir",
        icon: "tool-prevDir.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.prevDir();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.nextDir",
        group: GroupType.pdf,
        name: "nextDir",
        icon: "tool-nextDir.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.nextDir();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuSort",
        group: GroupType.pdf,
        name: "showMenuSort",
        icon: "tool-sort.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuSort(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuCopy",
        group: GroupType.pdf,
        name: "showMenuCopy",
        icon: "tool-copy.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuCopy(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.dragDropFile",
        group: GroupType.pdf,
        name: "dragDropFile",
        icon: "tool-dragDropFile.svg",
        func: (btn) => {
          btn.addEventListener("mousedown", (e) => {
            if (e.button === 0) {
              M?.script.file.dragDropFile();
            }
          });
          btn.addEventListener("mousedown", (e) => {
            if (e.button === 2) {
              M?.script.file.showContextMenu();
            }
          });
          btn.setAttribute("data-menu", "none");
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showDeleteFileMsg",
        group: GroupType.pdf,
        name: "showDeleteMsg",
        icon: "tool-delete.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.showDeleteMsg();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.bulkView",
        group: GroupType.pdf,
        name: "bulkView",
        icon: "tool-bulkView.svg",
        func: (btn) => {
          btn.addEventListener("click", async () => {
            M?.script.bulkView.show();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showSetting",
        group: GroupType.pdf,
        name: "showSetting",
        icon: "tool-setting.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.setting.showSetting();
          });
        }
      });
      ar.push({
        type: "html",
        html: `
                    <div class="main-toolbar-txt" data-name="infoType">
                        <!-- JPG<br>123.4MB -->
                    </div>
                `,
        i18n: "menu.infoType",
        group: GroupType.pdf,
        name: "infoType",
        icon: "",
        func: (btn) => {
        }
      });
      ar.push({
        type: "html",
        html: `
                    <div class="main-toolbar-txt" data-name="infoWriteTime">
                        <!--2022-05-02<br>01:19:49 -->
                    </div>
                `,
        i18n: "menu.infoWriteTime",
        group: GroupType.pdf,
        name: "infoWriteTime",
        icon: "",
        func: (btn) => {
        }
      });
    }
    function initToolbarTxt() {
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.prevFile",
        group: GroupType.txt,
        name: "prevFile",
        icon: "tool-prev.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.prevFile();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.nextFile",
        group: GroupType.txt,
        name: "nextFile",
        icon: "tool-next.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.nextFile();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuFile",
        group: GroupType.txt,
        name: "showMenuFile",
        icon: "tool-open.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuFile(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showSave",
        group: GroupType.txt,
        name: "showSave",
        icon: "tool-save.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.file.save(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.prevDir",
        group: GroupType.txt,
        name: "prevDir",
        icon: "tool-prevDir.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.prevDir();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.nextDir",
        group: GroupType.txt,
        name: "nextDir",
        icon: "tool-nextDir.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.nextDir();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuSort",
        group: GroupType.txt,
        name: "showMenuSort",
        icon: "tool-sort.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuSort(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuCopy",
        group: GroupType.txt,
        name: "showMenuCopy",
        icon: "tool-copy.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuCopy(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.dragDropFile",
        group: GroupType.txt,
        name: "dragDropFile",
        icon: "tool-dragDropFile.svg",
        func: (btn) => {
          btn.addEventListener("mousedown", (e) => {
            if (e.button === 0) {
              M?.script.file.dragDropFile();
            }
          });
          btn.addEventListener("mousedown", (e) => {
            if (e.button === 2) {
              M?.script.file.showContextMenu();
            }
          });
          btn.setAttribute("data-menu", "none");
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showDeleteFileMsg",
        group: GroupType.txt,
        name: "showDeleteMsg",
        icon: "tool-delete.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.showDeleteMsg();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.bulkView",
        group: GroupType.txt,
        name: "bulkView",
        icon: "tool-bulkView.svg",
        func: (btn) => {
          btn.addEventListener("click", async () => {
            M?.script.bulkView.show();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showSetting",
        group: GroupType.txt,
        name: "showSetting",
        icon: "tool-setting.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.setting.showSetting();
          });
        }
      });
      ar.push({
        type: "html",
        html: `
                    <div class="main-toolbar-txt" data-name="infoType">
                        <!-- JPG<br>123.4MB -->
                    </div>
                `,
        i18n: "menu.infoType",
        group: GroupType.txt,
        name: "infoType",
        icon: "",
        func: (btn) => {
        }
      });
      ar.push({
        type: "html",
        html: `
                    <div class="main-toolbar-txt" data-name="infoWriteTime">
                        <!--2022-05-02<br>01:19:49 -->
                    </div>
                `,
        i18n: "menu.infoWriteTime",
        group: GroupType.txt,
        name: "infoWriteTime",
        icon: "",
        func: (btn) => {
        }
      });
    }
    function initToolbarWelcome() {
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.openFile",
        group: GroupType.welcome,
        name: "openFile",
        icon: "tool-open.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.open.openFile();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showSetting",
        group: GroupType.welcome,
        name: "showSetting",
        icon: "tool-setting.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.setting.showSetting();
          });
        }
      });
    }
    function initBulkView() {
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuFile",
        group: GroupType.bulkView,
        name: "showMenuFile",
        icon: "tool-open.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuFile(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.prevDir",
        group: GroupType.bulkView,
        name: "prevDir",
        icon: "tool-prevDir.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.prevDir();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.nextDir",
        group: GroupType.bulkView,
        name: "nextDir",
        icon: "tool-nextDir.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.nextDir();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuSort",
        group: GroupType.bulkView,
        name: "showMenuSort",
        icon: "tool-sort.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuSort(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showMenuCopy",
        group: GroupType.bulkView,
        name: "showMenuCopy",
        icon: "tool-copy.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuCopy(btn);
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.dragDropFile",
        group: GroupType.bulkView,
        name: "dragDropFile",
        icon: "tool-dragDropFile.svg",
        func: (btn) => {
          btn.addEventListener("mousedown", (e) => {
            if (e.button === 0) {
              M?.script.file.dragDropFile();
            }
          });
          btn.addEventListener("mousedown", (e) => {
            if (e.button === 2) {
              M?.script.file.showContextMenu();
            }
          });
          btn.setAttribute("data-menu", "none");
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showDeleteDirMsg",
        group: GroupType.bulkView,
        name: "showDeleteMsg",
        icon: "tool-delete.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.fileLoad.showDeleteMsg();
          });
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showSetting",
        group: GroupType.bulkView,
        name: "showSetting",
        icon: "tool-setting.svg",
        func: (btn) => {
          btn.addEventListener("click", () => {
            M?.script.setting.showSetting();
          });
        }
      });
      ar.push({
        type: "html",
        html: `
                    <div class="main-toolbar-txt" data-name="infoWriteTime">
                        <!--2022-05-02<br>01:19:49 -->
                    </div>
                `,
        i18n: "menu.infoWriteTime",
        group: GroupType.bulkView,
        name: "infoWriteTime",
        icon: "",
        func: (btn) => {
        }
      });
      ar.push({
        type: "button",
        html: "",
        i18n: "menu.showBulkViewSetting",
        group: GroupType.bulkView,
        name: "showBulkViewSetting",
        icon: "tool-setting2.svg",
        func: (btn) => {
          btn.style.order = "2001";
          btn.addEventListener("click", () => {
            M?.script.menu.showMenuBulkView(btn);
          });
        }
      });
    }
    function addToolbarHtml(item) {
      let div = Lib.newDom(item.html);
      div.setAttribute("title", item.i18n);
      div.setAttribute("i18n", item.i18n);
      div.style.order = "999";
      addToolbarDom({
        group: item.group,
        dom: div,
        func: item.func
      });
    }
    function addToolbarHr(item) {
      let div = Lib.newDom(`<div class="main-toolbar-hr"> </div>`);
      div.style.order = "888";
      addToolbarDom({
        group: item.group,
        dom: div,
        func: item.func
      });
    }
    function addToolbarBtn(item) {
      let div = Lib.newDom(`
                <div class="main-toolbar-btn js-noDrag" data-name="${item.name}" title="${item.i18n}" i18n="${item.i18n}">
                    ${SvgList[item.icon]}
                </div>`);
      div.style.order = "888";
      addToolbarDom({
        group: item.group,
        dom: div,
        func: item.func
      });
    }
    function addToolbarDom(item) {
      if (M === null) {
        return;
      }
      let dom_group = M.dom_toolbar.querySelector(`.main-toolbar-group[data-name=${item.group}]`);
      if (dom_group === null) {
        let div = Lib.newDom(`<div class="main-toolbar-group" data-name="${item.group}">  </div>`);
        M.dom_toolbar.querySelector("#toolbar-content")?.appendChild(div);
        dom_group = M.dom_toolbar.querySelector(`.main-toolbar-group[data-name=${item.group}]`);
      }
      item.func(item.dom);
      if (dom_group !== null) {
        dom_group.appendChild(item.dom);
      }
    }
  }
}
