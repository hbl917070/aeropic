class MainFileList {
  constructor(M) {
    this.init = init;
    this.select = select;
    this.updateLocation = updateLocation;
    this.setStartLocation = setStartLocation;
    this.setHide = setHide;
    this.setEnabled = setEnabled;
    this.setShowNo = setShowNo;
    this.setShowName = setShowName;
    this.setItemWidth = setItemWidth;
    let dom_fileList = document.getElementById("main-fileList");
    let dom_fileListBody = document.getElementById("main-fileListBody");
    let dom_fileListData = document.getElementById("main-fileListData");
    var dom_dragbar_mainFileList = document.getElementById("dragbar-mainFileList");
    var isHide = false;
    var isEnabled = true;
    var isShowNo = true;
    var isShowName = true;
    var itemWidth = 1;
    var itemHeight = 1;
    var temp_loaded = [];
    var temp_start = 0;
    var temp_count = 0;
    var temp_itemHeight = 0;
    var sc = new TiefseeScroll();
    sc.initGeneral(dom_fileList, "y");
    var dragbar = new Dragbar();
    dragbar.init("right", dom_fileList, dom_dragbar_mainFileList, M.dom_mainL);
    dragbar.setEventStart(() => {
    });
    dragbar.setEventMove((val) => {
      if (val < 10) {
        dom_fileList.style.opacity = "0";
        dragbar.setPosition(0);
      } else {
        dom_fileList.style.opacity = "1";
        setItemWidth(val);
      }
    });
    dragbar.setEventEnd((val) => {
      if (val < 10) {
        setEnabled(false);
      }
    });
    dom_fileList.addEventListener("scroll", () => {
      updateItem();
    });
    new ResizeObserver(() => {
      updateItem();
    }).observe(dom_fileList);
    function setHide(val) {
      if (M.fileLoad.getIsBulkView()) {
        val = true;
      }
      isHide = val;
      if (val) {
        dom_fileList.setAttribute("hide", "true");
        dragbar.setEnabled(false);
      } else {
        dom_fileList.setAttribute("hide", "");
        dragbar.setEnabled(M.config.settings.layout.fileListEnabled);
      }
    }
    function setEnabled(val) {
      if (val) {
        dom_fileList.setAttribute("active", "true");
      } else {
        dom_fileList.setAttribute("active", "");
      }
      M.config.settings.layout.fileListEnabled = val;
      dragbar.setEnabled(val);
      dom_fileList.style.opacity = "1";
      if (isEnabled === val) {
        return;
      }
      isEnabled = val;
      temp_start = -1;
      dom_fileListData.innerHTML = "";
      updateItem();
      setStartLocation();
    }
    function setShowNo(val) {
      if (isShowNo === val) {
        return;
      }
      isShowNo = val;
      temp_start = -1;
      dom_fileListData.innerHTML = "";
      updateItem();
      setStartLocation();
    }
    function setShowName(val) {
      if (isShowName === val) {
        return;
      }
      isShowName = val;
      temp_start = -1;
      dom_fileListData.innerHTML = "";
      updateItem();
      setStartLocation();
    }
    function setItemWidth(val) {
      if (itemWidth === val) {
        return;
      }
      let valMin = 80;
      let valMax = 200;
      if (val <= valMin) {
        val = valMin;
      }
      if (val >= valMax) {
        val = valMax;
      }
      itemWidth = val;
      M.config.settings.layout.fileListShowWidth = val;
      var cssRoot = document.body;
      cssRoot.style.setProperty("--fileList-width", val + "px");
      dragbar.setPosition(val);
      temp_start = -1;
      updateItem();
      setStartLocation();
    }
    function updateItem() {
      if (isEnabled === false) {
        dom_fileListData.innerHTML = "";
        return;
      }
      let noDelay = temp_start === -999;
      let fileListItem = dom_fileListData.querySelector(".fileList-item");
      if (fileListItem === null) {
        newItem(-1, "");
        fileListItem = dom_fileListData.querySelector(".fileList-item");
      }
      if (fileListItem !== null) {
        itemHeight = fileListItem.getBoundingClientRect().height + 6;
      }
      if (temp_itemHeight !== itemHeight) {
        let arWaitingFile2 = M.fileLoad.getWaitingFile();
        dom_fileListBody.style.height = arWaitingFile2.length * itemHeight + 4 + "px";
      }
      temp_itemHeight = itemHeight;
      let start = Math.floor(dom_fileList.scrollTop / itemHeight) - 1;
      let count = Math.floor(dom_fileList.clientHeight / itemHeight) + 5;
      if (start < 0) {
        start = 0;
      }
      if (temp_start === start && temp_count === count) {
        return;
      }
      temp_start = start;
      temp_count = count;
      dom_fileListData.innerHTML = "";
      dom_fileListData.style.marginTop = start * itemHeight + "px";
      let arWaitingFile = M.fileLoad.getWaitingFile();
      let end = start + count;
      if (end > arWaitingFile.length) {
        end = arWaitingFile.length;
      }
      for (let i = start; i < end; i++) {
        const path = arWaitingFile[i];
        newItem(i, path, noDelay);
      }
      select();
    }
    function newItem(i, path, noDelay = false) {
      let name = Lib.GetFileName(path);
      let style = "";
      if (temp_loaded.indexOf(i) === -1 && noDelay === false) {
        if (path !== "") {
          setTimeout(() => {
            if (dom_fileListData.contains(div) === false) {
              return;
            }
            temp_loaded.push(i);
            let _url = getImgUrl(path);
            let domImg = div.getElementsByClassName("fileList-img")[0];
            domImg.style.backgroundImage = `url("${_url}")`;
          }, 30);
        }
      } else {
        let imgUrl = getImgUrl(path);
        style = `background-image:url('${imgUrl}')`;
      }
      let htmlNo = ``;
      let htmlName = ``;
      if (isShowNo === true) {
        htmlNo = `<div class="fileList-no">${i + 1}</div>`;
      }
      if (isShowName === true) {
        htmlName = `<div class="fileList-name">${name}</div>`;
      }
      let div = Lib.newDom(`<div class="fileList-item" data-id="${i}">
                    <div class="fileList-title">
                        ${htmlNo} ${htmlName}
                    </div>
                    <div class="fileList-img" style="${style}"> </div>                                                            
                </div>`);
      dom_fileListData.append(div);
      div.setAttribute("data-path", path);
      div.addEventListener("click", () => {
        M.fileLoad.showFile(i);
      });
      return div;
    }
    function getImgUrl(path) {
      if (Lib.GetExtension(path) === ".svg") {
        return Lib.pathToURL(path);
      }
      return WebAPI.Img.fileIcon(path).replace(/[']/g, "\\'");
    }
    function init() {
      temp_start = -999;
      temp_loaded = [];
      temp_itemHeight = -1;
      updateItem();
    }
    function select() {
      if (isEnabled === false) {
        return;
      }
      document.querySelector(`.fileList-item[active=true]`)?.setAttribute("active", "");
      let id = M.fileLoad.getFlagFile();
      let div = document.querySelector(`.fileList-item[data-id="${id}"]`);
      if (div == null) {
        return;
      }
      div.setAttribute("active", "true");
    }
    function setStartLocation() {
      if (isEnabled === false) {
        return;
      }
      let id = M.fileLoad.getFlagFile();
      let f = (dom_fileList.clientHeight - itemHeight) / 2 - 0;
      dom_fileList.scrollTop = id * itemHeight - f;
    }
    function updateLocation() {
      if (isEnabled === false) {
        return;
      }
      let id = M.fileLoad.getFlagFile();
      let start = Math.floor(dom_fileList.scrollTop / itemHeight);
      if (id <= start) {
        dom_fileList.scrollTop = id * itemHeight;
        return;
      }
      let count = Math.floor(dom_fileList.clientHeight / itemHeight);
      let end = (id - count + 1) * itemHeight - dom_fileList.clientHeight % itemHeight + 3;
      if (dom_fileList.scrollTop < end) {
        dom_fileList.scrollTop = end;
      }
    }
  }
}
