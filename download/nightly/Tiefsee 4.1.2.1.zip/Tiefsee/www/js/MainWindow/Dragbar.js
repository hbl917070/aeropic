class Dragbar {
  constructor() {
    let dom_windowBody = document.getElementById("window-body");
    let dom_box;
    let dom_dragbar;
    let dom_observe;
    let temp_val = 0;
    let temp_width = 0;
    let hammer_dragbar;
    let type = "right";
    let _eventStart = () => {
    };
    let _eventMove = (val) => {
    };
    let _eventEnd = (val) => {
    };
    this.getEventStart = function() {
      return _eventStart;
    };
    this.setEventStart = function(func) {
      _eventStart = func;
    };
    this.getEventMove = function() {
      return _eventMove;
    };
    this.setEventMove = function(func) {
      _eventMove = func;
    };
    this.getEventEnd = function() {
      return _eventEnd;
    };
    this.setEventEnd = function(func) {
      _eventEnd = func;
    };
    this.setEnabled = function(val) {
      if (val) {
        dom_dragbar.style.display = "block";
      } else {
        dom_dragbar.style.display = "none";
      }
    };
    this.setPosition = function(val) {
      if (type === "left") {
        dom_dragbar.style.left = dom_box.getBoundingClientRect().left + "px";
      }
      if (type === "right") {
        dom_dragbar.style.left = dom_box.getBoundingClientRect().left + val + "px";
      }
    };
    this.init = function init(_type, _dom_box, _dom_dragbar, _dom_observe) {
      type = _type;
      dom_box = _dom_box;
      dom_dragbar = _dom_dragbar;
      dom_observe = _dom_observe;
      hammer_dragbar = new Hammer(dom_dragbar);
      function updatePosition() {
        requestAnimationFrame(() => {
          if (type === "left") {
            dom_dragbar.style.top = dom_box.getBoundingClientRect().top + "px";
            dom_dragbar.style.left = dom_box.getBoundingClientRect().left + "px";
            dom_dragbar.style.height = dom_box.getBoundingClientRect().height + "px";
          }
          if (type === "right") {
            dom_dragbar.style.top = dom_box.getBoundingClientRect().top + "px";
            dom_dragbar.style.left = dom_box.getBoundingClientRect().left + dom_box.getBoundingClientRect().width + "px";
            dom_dragbar.style.height = dom_box.getBoundingClientRect().height + "px";
          }
        });
      }
      new ResizeObserver(updatePosition).observe(dom_observe);
      new ResizeObserver(updatePosition).observe(document.body);
      dom_dragbar.addEventListener("pointerdown", (ev) => {
        ev.preventDefault();
        dom_windowBody.style.pointerEvents = "none";
        temp_val = Lib.toNumber(dom_dragbar.style.left);
        temp_width = dom_box.getBoundingClientRect().width;
        _eventStart();
      });
      dom_dragbar.addEventListener("pointerup", () => {
        dom_windowBody.style.pointerEvents = "";
      });
      hammer_dragbar.get("pan").set({ pointers: 0, threshold: 0, direction: Hammer.DIRECTION_ALL });
      hammer_dragbar.on("pan", (ev) => {
        dom_dragbar.setAttribute("active", "true");
        let val = update(ev);
        _eventMove(val);
      });
      hammer_dragbar.on("panend", (ev) => {
        dom_windowBody.style.pointerEvents = "";
        dom_dragbar.setAttribute("active", "");
        let val = update(ev);
        _eventEnd(val);
      });
      function update(ev) {
        let val = 0;
        if (type === "left") {
          val = temp_val * 0 - ev.deltaX - dom_box.getBoundingClientRect().left * 0 + temp_width;
        }
        if (type === "right") {
          val = temp_val + ev.deltaX - dom_box.getBoundingClientRect().left;
        }
        return val;
      }
    };
  }
}
