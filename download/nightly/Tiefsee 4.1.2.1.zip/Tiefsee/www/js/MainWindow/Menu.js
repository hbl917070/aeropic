class Menu {
  constructor(M) {
    this.openAtButton = openAtButton;
    this.openAtMouse = openAtMouse;
    this.openAtPoint = openAtPoint;
    this.openAtOrigin = openAtOrigin;
    this.getIsShow = getIsShow;
    this.close = close;
    var temp_closeList = [];
    var mouseX = 0;
    var mouseY = 0;
    document.body.addEventListener("mouseup", (e) => {
      mouseX = e.x;
      mouseY = e.y;
    });
    function getIsShow() {
      let bool = temp_closeList.length > 0;
      return bool;
    }
    function close() {
      for (let i = 0; i < temp_closeList.length; i++) {
        temp_closeList[i]();
      }
    }
    function openBase(_domMenu, _funcPosition, _funcClose) {
      if (_domMenu === null) {
        return;
      }
      let domMenuBg = _domMenu.parentNode;
      if (domMenuBg === null) {
        return;
      }
      M.updateDomVisibility();
      domMenuBg.setAttribute("active", "true");
      _domMenu.style.bottom = "";
      _funcPosition();
      let funcClose = () => {
        domMenuBg.setAttribute("active", "");
        temp_closeList = temp_closeList.filter((item) => {
          return item !== funcClose;
        });
        domMenuBg.removeEventListener("touchstart", onmousedown);
        domMenuBg.removeEventListener("mousedown", onmousedown);
        _funcClose();
      };
      temp_closeList.push(funcClose);
      let onmousedown = (sender) => {
        let dom = sender.target;
        let isScroll = Lib.isScrollbarVisible(_domMenu);
        if (dom.classList.contains("menu") || isScroll === false && dom.classList.contains("menu-content")) {
          sender.preventDefault();
          funcClose();
        }
      };
      domMenuBg.addEventListener("touchstart", onmousedown);
      domMenuBg.addEventListener("mousedown", onmousedown);
      domMenuBg.onwheel = (sender) => {
        let dom = sender.target;
        let isScroll = Lib.isScrollbarVisible(_domMenu);
        if (dom.classList.contains("menu") || isScroll === false && dom.classList.contains("menu-content")) {
          funcClose();
        }
      };
    }
    function openAtButton(_domMenu, _domBtn, _css) {
      if (_domMenu === null) {
        return;
      }
      if (_domBtn === null) {
        return;
      }
      let funcPosition = () => {
        let left = 0;
        let top = 0;
        top = _domBtn.getBoundingClientRect().top + _domBtn.getBoundingClientRect().height;
        left = _domBtn.getBoundingClientRect().left + _domBtn.getBoundingClientRect().width / 2 - _domMenu.getBoundingClientRect().width / 2;
        if (left < 0) {
          left = 0;
        }
        if (left > document.body.getBoundingClientRect().width - _domMenu.getBoundingClientRect().width) {
          left = document.body.getBoundingClientRect().width - _domMenu.getBoundingClientRect().width;
        }
        _domMenu.style.left = left + "px";
        _domMenu.style.top = top + "px";
        _domMenu.style.bottom = "0";
        _domBtn.classList.add(_css);
      };
      let funcClose = () => {
        _domBtn.classList.remove(_css);
      };
      openBase(_domMenu, funcPosition, funcClose);
    }
    function openAtMouse(_domMenu, offsetX = 0, offsetY = 0) {
      if (_domMenu === null) {
        return;
      }
      let funcPosition = () => {
        let menuHeight = _domMenu.getBoundingClientRect().height;
        let menuWidth = _domMenu.getBoundingClientRect().width;
        let bodyHeight = document.body.getBoundingClientRect().height;
        let bodyWidth = document.body.getBoundingClientRect().width;
        let left = mouseX;
        let top = mouseY;
        if (menuWidth + left + offsetX > bodyWidth) {
          left = left - menuWidth + 10;
        } else {
          left = left + offsetX;
        }
        if (left < 0) {
          left = 0;
        }
        if (menuHeight + top + offsetY > bodyHeight) {
          top = bodyHeight - menuHeight - 5;
        } else {
          top = top + offsetY;
        }
        if (top < 0) {
          top = 0;
        }
        _domMenu.style.left = left + "px";
        _domMenu.style.top = top + "px";
        _domMenu.style.bottom = "0";
      };
      let funcClose = () => {
      };
      openBase(_domMenu, funcPosition, funcClose);
    }
    function openAtPoint(_domMenu, X = 0, Y = 0) {
      if (_domMenu === null) {
        return;
      }
      let funcPosition = () => {
        let menuHeight = _domMenu.getBoundingClientRect().height;
        let menuWidth = _domMenu.getBoundingClientRect().width;
        let bodyHeight = document.body.getBoundingClientRect().height;
        let bodyWidth = document.body.getBoundingClientRect().width;
        let left = X;
        let top = Y;
        if (menuWidth + left > bodyWidth) {
          left = left - menuWidth + 10;
        } else {
          left = left;
        }
        if (left < 0) {
          left = 0;
        }
        if (menuHeight + top > bodyHeight) {
          top = bodyHeight - menuHeight - 5;
        } else {
          top = top;
        }
        if (top < 0) {
          top = 0;
        }
        _domMenu.style.left = left + "px";
        _domMenu.style.top = top + "px";
        _domMenu.style.bottom = "0";
      };
      let funcClose = () => {
      };
      openBase(_domMenu, funcPosition, funcClose);
    }
    function openAtOrigin(_domMenu, offsetX = 0, offsetY = 0) {
      if (_domMenu === null) {
        return;
      }
      let funcPosition = () => {
        let menuWidth = _domMenu.getBoundingClientRect().width;
        let menuHeight = _domMenu.getBoundingClientRect().height;
        let bodyWidth = document.body.getBoundingClientRect().width;
        let bodyHeight = document.body.getBoundingClientRect().height;
        let left = mouseX;
        let top = mouseY;
        left = left - menuWidth / 2 + offsetX;
        if (left + menuWidth > bodyWidth) {
          left = bodyWidth - menuWidth;
        }
        if (left < 0) {
          left = 0;
        }
        top = top + offsetY;
        if (top + menuHeight > bodyHeight) {
          top = bodyHeight - menuHeight;
        }
        if (top < 0) {
          top = 0;
        }
        _domMenu.style.left = left + "px";
        _domMenu.style.top = top + "px";
        _domMenu.style.bottom = "0";
      };
      let funcClose = () => {
      };
      openBase(_domMenu, funcPosition, funcClose);
    }
  }
}
