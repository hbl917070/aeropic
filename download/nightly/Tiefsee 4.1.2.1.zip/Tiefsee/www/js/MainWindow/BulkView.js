class BulkView {
  constructor(M) {
    var dom_bulkView = document.querySelector("#mView-bulkView");
    var dom_bulkViewContent = dom_bulkView.querySelector(".bulkView-content");
    var dom_menu = document.querySelector("#menu-bulkView");
    var dom_columns = dom_menu.querySelector(".js-columns");
    var dom_gaplessMode = dom_menu.querySelector(".js-gaplessMode");
    var dom_fixedWidth = dom_menu.querySelector(".js-fixedWidth");
    var dom_align = dom_menu.querySelector(".js-align");
    var dom_indentation = dom_menu.querySelector(".js-indentation");
    var dom_waterfall = dom_menu.querySelector(".js-waterfall");
    var dom_number = dom_menu.querySelector(".js-number");
    var dom_fileName = dom_menu.querySelector(".js-fileName");
    var dom_imageSize = dom_menu.querySelector(".js-imageSize");
    var dom_fileSize = dom_menu.querySelector(".js-fileSize");
    var dom_lastWriteDate = dom_menu.querySelector(".js-lastWriteDate");
    var dom_lastWriteTime = dom_menu.querySelector(".js-lastWriteTime");
    var dom_box_gaplessMode = dom_menu.querySelector(".js-box-gaplessMode");
    var dom_box_indentation = dom_menu.querySelector(".js-box-indentation");
    var dom_box_fixedWidth = dom_menu.querySelector(".js-box-fixedWidth");
    var dom_box_waterfall = dom_menu.querySelector(".js-box-waterfall");
    var dom_box_align = dom_menu.querySelector(".js-box-align");
    var arFile = [];
    var imgMaxCount = 100;
    var pageNow = 1;
    var isVisible = false;
    var svgIndentation = "";
    var temp_scrollTop = -1;
    var temp_arFile = [];
    var temp_dirPath = "";
    var temp_pageNow = -1;
    var temp_fileSortType = "";
    var temp_hasScrolled = false;
    var temp_scrollWidth = 0;
    var temp_scrollHeight = 0;
    let temp_columns = -1;
    const limiter = new RequestLimiter(3);
    this.visible = visible;
    this.pageNext = pageNext;
    this.pagePrev = pagePrev;
    this.load = load;
    this.load2 = load2;
    this.setColumns = setColumns;
    this.saveCurrentState = saveCurrentState;
    this.updateFileWatcher = updateFileWatcher;
    this.setImgMaxCount = setImgMaxCount;
    this.incrColumns = incrColumns;
    this.decColumns = decColumns;
    this.incrFixedWidth = incrFixedWidth;
    this.decFixedWidth = decFixedWidth;
    this.setFocus = () => {
      dom_bulkViewContent.tabIndex = 0;
      dom_bulkViewContent.focus();
    };
    initEvent();
    function initEvent() {
      initGroupRadio(dom_columns);
      new ResizeObserver(Lib.debounce(() => {
        updateSize();
      }, 30)).observe(dom_bulkView);
      new TiefseeScroll().initGeneral(dom_bulkView, "y");
      dom_bulkView.addEventListener("wheel", () => {
        temp_hasScrolled = true;
      });
      dom_bulkView.addEventListener("touchmove", () => {
        temp_hasScrolled = true;
      });
      dom_bulkView.querySelectorAll(".bulkView-pagination-prev").forEach((dom) => {
        dom.addEventListener("click", () => {
          pagePrev();
        });
      });
      dom_bulkView.querySelectorAll(".bulkView-pagination-next").forEach((dom) => {
        dom.addEventListener("click", () => {
          pageNext();
        });
      });
      dom_bulkView.querySelectorAll(".bulkView-pagination-select").forEach((dom) => {
        dom.addEventListener("input", () => {
          let val = Number.parseInt(dom.value);
          showPage(val);
        });
      });
      let arDomCheckbox = [
        dom_columns,
        dom_gaplessMode,
        dom_fixedWidth,
        dom_align,
        dom_indentation,
        dom_waterfall,
        dom_number,
        dom_fileName,
        dom_imageSize,
        dom_fileSize,
        dom_lastWriteDate,
        dom_lastWriteTime
      ];
      arDomCheckbox.forEach((dom) => {
        dom.addEventListener("input", (e) => {
          apply();
          if (dom === dom_indentation) {
            let columns = Number.parseInt(getGroupRadioVal(dom_columns));
            if (columns === 2) {
              load(pageNow);
            }
          }
        });
      });
      dom_columns.addEventListener("click", (e) => {
        let columns = Number.parseInt(getGroupRadioVal(dom_columns));
        setColumns(columns);
      });
      dom_bulkView.addEventListener("wheel", (e) => {
        let deltaY = e.deltaY;
        let sc = "";
        if (deltaY > 0) {
          if (e.ctrlKey) {
            sc = M.config.settings.mouse.bulkViewScrollDownCtrl;
          } else if (e.shiftKey) {
            sc = M.config.settings.mouse.bulkViewScrollDownShift;
          } else if (e.altKey) {
            sc = M.config.settings.mouse.bulkViewScrollDownAlt;
          }
        }
        if (deltaY < 0) {
          if (e.ctrlKey) {
            sc = M.config.settings.mouse.bulkViewScrollUpCtrl;
          } else if (e.shiftKey) {
            sc = M.config.settings.mouse.bulkViewScrollUpShift;
          } else if (e.altKey) {
            sc = M.config.settings.mouse.bulkViewScrollUpAlt;
          }
        }
        if (sc !== "") {
          M.script.run(sc, { x: e.offsetX, y: e.offsetY });
          e.preventDefault();
        }
      }, false);
    }
    function initSetting() {
      setGroupRadioVal(dom_columns, M.config.settings.bulkView.columns.toString());
      temp_columns = M.config.settings.bulkView.columns;
      dom_gaplessMode.value = M.config.settings.bulkView.gaplessMode;
      dom_fixedWidth.value = M.config.settings.bulkView.fixedWidth;
      dom_align.value = M.config.settings.bulkView.align;
      dom_indentation.value = M.config.settings.bulkView.indentation;
      dom_waterfall.value = M.config.settings.bulkView.waterfall;
      dom_number.checked = M.config.settings.bulkView.show.number;
      dom_fileName.checked = M.config.settings.bulkView.show.fileName;
      dom_imageSize.checked = M.config.settings.bulkView.show.imageSize;
      dom_fileSize.checked = M.config.settings.bulkView.show.fileSize;
      dom_lastWriteDate.checked = M.config.settings.bulkView.show.lastWriteDate;
      dom_lastWriteTime.checked = M.config.settings.bulkView.show.lastWriteTime;
      apply();
      if (svgIndentation === "" && baseWindow.appInfo !== void 0) {
        svgIndentation = Lib.Combine([baseWindow.appInfo.appDirPath, "\\www\\img\\indentation.svg"]);
      }
    }
    function apply() {
      let columns = M.config.settings.bulkView.columns = Number.parseInt(getGroupRadioVal(dom_columns));
      let gaplessMode = M.config.settings.bulkView.gaplessMode = dom_gaplessMode.value;
      let fixedWidth = M.config.settings.bulkView.fixedWidth = dom_fixedWidth.value;
      let align = M.config.settings.bulkView.align = dom_align.value;
      let indentation = M.config.settings.bulkView.indentation = dom_indentation.value;
      let waterfall = M.config.settings.bulkView.waterfall = dom_waterfall.value;
      dom_bulkViewContent.setAttribute("waterfall", waterfall);
      dom_bulkViewContent.setAttribute("columns", columns.toString());
      dom_bulkViewContent.setAttribute("align", align);
      if (columns === 1 || columns === 2) {
        dom_bulkViewContent.setAttribute("fixedWidth", fixedWidth);
      } else {
        dom_bulkViewContent.setAttribute("fixedWidth", "");
      }
      dom_bulkViewContent.setAttribute("gaplessMode", gaplessMode);
      updateColumns(columns);
      let number = M.config.settings.bulkView.show.number = dom_number.checked;
      let fileName = M.config.settings.bulkView.show.fileName = dom_fileName.checked;
      let imageSize = M.config.settings.bulkView.show.imageSize = dom_imageSize.checked;
      let fileSize = M.config.settings.bulkView.show.fileSize = dom_fileSize.checked;
      let lastWriteDate = M.config.settings.bulkView.show.lastWriteDate = dom_lastWriteDate.checked;
      let lastWriteTime = M.config.settings.bulkView.show.lastWriteTime = dom_lastWriteTime.checked;
      let arShow = [];
      if (number) {
        arShow.push("number");
      }
      if (fileName) {
        arShow.push("fileName");
      }
      if (imageSize) {
        arShow.push("imageSize");
      }
      if (fileSize) {
        arShow.push("fileSize");
      }
      if (lastWriteDate) {
        arShow.push("lastWriteDate");
      }
      if (lastWriteTime) {
        arShow.push("lastWriteTime");
      }
      dom_bulkViewContent.setAttribute("show", arShow.join(","));
      if (columns === 1 || columns === 2) {
        dom_box_gaplessMode.style.display = "block";
      } else {
        dom_box_gaplessMode.style.display = "none";
      }
      if (columns === 1 || columns === 2) {
        dom_box_waterfall.style.display = "none";
      } else {
        dom_box_waterfall.style.display = "block";
      }
      if (columns === 1 || columns === 2) {
        dom_box_fixedWidth.style.display = "block";
      } else {
        dom_box_fixedWidth.style.display = "none";
      }
      if (columns === 2) {
        dom_box_align.style.display = "block";
      } else {
        dom_box_align.style.display = "none";
      }
      if (columns === 2) {
        dom_box_indentation.style.display = "block";
      } else {
        dom_box_indentation.style.display = "none";
      }
    }
    function getFixedWidth() {
      return M.config.settings.bulkView.fixedWidth;
    }
    function setFixedWidth(n) {
      if (n === getFixedWidth()) {
        return;
      }
      dom_fixedWidth.value = n;
      dom_fixedWidth.dispatchEvent(new Event("input"));
    }
    function getIndentation() {
      return M.config.settings.bulkView.indentation;
    }
    function getWaterfall() {
      return M.config.settings.bulkView.waterfall;
    }
    function getColumns() {
      return M.config.settings.bulkView.columns;
    }
    function setColumns(columns) {
      if (columns < 1) {
        columns = 1;
      }
      if (columns > 8) {
        columns = 8;
      }
      if (columns === getColumns()) {
        return;
      }
      setGroupRadioVal(dom_columns, columns.toString());
      apply();
      let indentation = dom_indentation.value;
      if (indentation === "on") {
        if (temp_columns === 2 || columns === 2) {
          load(pageNow);
        }
      }
      temp_columns = columns;
    }
    function updateColumns(n) {
      if (n === void 0) {
        n = M.config.settings.bulkView.columns;
      }
      if (n < 1) {
        n = 1;
      }
      if (n > 8) {
        n = 8;
      }
      setGroupRadioVal(dom_columns, n.toString());
      dom_bulkView.setAttribute("columns", n.toString());
      updateSize();
    }
    var updateSizeThrottle = new Throttle(50);
    function updateSize(donItem) {
      if (isVisible === false) {
        return;
      }
      updateSizeThrottle.run = async () => {
        if (isVisible === false) {
          return;
        }
        if (document.body.offsetWidth * window.devicePixelRatio < 200) {
          return;
        }
        var containerPadding = 5;
        let columns = getColumns();
        let bulkViewWidth = dom_bulkViewContent.offsetWidth;
        let itemWidth = Math.floor(bulkViewWidth / columns);
        let arItme;
        if (donItem === void 0) {
          arItme = dom_bulkViewContent.querySelectorAll(".bulkView-item");
        } else {
          arItme = [donItem];
        }
        if (getWaterfall() === "off" || getWaterfall() === "vertical" || columns <= 2) {
          for (let i = 0; i < arItme.length; i++) {
            const dom = arItme[i];
            const domImg = dom.querySelector(".bulkView-img");
            dom.style.width = `calc( ${100 / columns}% )`;
            if (dom.getAttribute("data-width") !== null) {
              if (columns > 2) {
                dom.style.minHeight = itemWidth / 2 + "px";
              } else {
                dom.style.minHeight = "";
              }
              let imgWidth = Number.parseInt(dom.getAttribute("data-width") ?? "1");
              let imgHeight = Number.parseInt(dom.getAttribute("data-height") ?? "1");
              let ratio = imgHeight / imgWidth;
              let newImgWidth = itemWidth - 10;
              let newImgHeight = newImgWidth * ratio;
              let maxH = itemWidth;
              if (columns === 1 || columns === 2) {
                domImg.style.width = "";
                domImg.style.height = "";
              } else {
                if (columns === 3) {
                  maxH = itemWidth * 3;
                } else {
                  maxH = itemWidth * 2;
                }
                if (newImgHeight > maxH) {
                  domImg.style.width = "";
                  domImg.style.height = maxH + "px";
                } else {
                  domImg.style.width = "100%";
                  domImg.style.height = "";
                }
              }
            }
          }
          dom_bulkViewContent.style.height = "";
        }
        if (getWaterfall() === "vertical" && columns >= 3) {
          if (arItme.length === 1) {
            arItme = dom_bulkViewContent.querySelectorAll(".bulkView-item");
          }
          let arTop = new Array(columns).fill(0);
          for (let i = 0; i < arItme.length; i++) {
            const dom = arItme[i];
            let minTop = arTop[0];
            let minTopFlag = 0;
            for (let i2 = 0; i2 < arTop.length; i2++) {
              if (minTop > arTop[i2]) {
                minTopFlag = i2;
                minTop = arTop[i2];
              }
            }
            let h = dom.offsetHeight;
            let left = minTopFlag * itemWidth;
            let top = arTop[minTopFlag];
            dom.style.left = left + "px";
            dom.style.top = top + "px";
            arTop[minTopFlag] += h;
          }
          let sumHeight = Math.max.apply(null, arTop);
          dom_bulkViewContent.style.height = sumHeight + "px";
        }
        if (getWaterfall() === "horizontal" && columns >= 3) {
          if (arItme.length === 1) {
            arItme = dom_bulkViewContent.querySelectorAll(".bulkView-item");
          }
          let isEnd = false;
          let len = Math.floor(arItme.length / columns) + 1;
          for (let i = 0; i < len; i++) {
            let images = [];
            let isRun = true;
            for (let j = i * columns; j < i * columns + columns; j++) {
              if (j >= arItme.length) {
                isEnd = true;
                break;
              }
              const item = arItme[j];
              if (item.getAttribute("data-width") === null) {
                isRun = false;
                break;
              } else {
                images.push([
                  Number.parseInt(item.getAttribute("data-width") ?? "1"),
                  Number.parseInt(item.getAttribute("data-height") ?? "1")
                ]);
              }
            }
            if (isRun === false || images.length === 0) {
              break;
            }
            let containerWidth = bulkViewWidth - 1;
            if (isEnd) {
              containerWidth = bulkViewWidth / columns * (arItme.length % columns) - 1;
            }
            let aspectRatios = images.map((size) => size[0] / size[1]);
            let totalAspectRatio = aspectRatios.reduce((a, b) => a + b);
            let imageHeights = aspectRatios.map((ratio) => (containerWidth - containerPadding * images.length * 2) / totalAspectRatio);
            let divWidths = imageHeights.map((height, index) => height * aspectRatios[index] + containerPadding * 2);
            for (let j = 0; j < divWidths.length; j++) {
              const dom = arItme[i * columns + j];
              const domImg = dom.querySelector(".bulkView-img");
              const divWidth = divWidths[j];
              const imgWidth = divWidths[j] - containerPadding * 2;
              const imgHeight = imageHeights[j];
              dom.style.width = divWidth + "px";
              domImg.style.width = imgWidth + "px";
              domImg.style.height = imgHeight + "px";
              dom.style.minHeight = "";
            }
          }
          dom_bulkViewContent.style.height = "";
        }
      };
    }
    function visible(val) {
      isVisible = val;
      if (val === true) {
        initSetting();
        dom_bulkView.style.display = "flex";
      } else {
        dom_bulkView.style.display = "none";
      }
    }
    function saveCurrentState() {
      isVisible = false;
      temp_scrollTop = dom_bulkView.scrollTop;
      temp_scrollWidth = dom_bulkViewContent.scrollWidth;
      temp_scrollHeight = dom_bulkViewContent.scrollHeight;
      temp_arFile = arFile;
      if (temp_arFile[0] === svgIndentation) {
        temp_arFile.shift();
      }
      temp_dirPath = getDirPath();
      temp_fileSortType = M.fileSort.getSortType() + M.fileSort.getOrderbyType();
      temp_pageNow = pageNow;
    }
    async function load2() {
      M.toolbarBack.visible(true);
      M.toolbarBack.setEvent(() => {
        M.script.bulkView.close();
      });
      temp_hasScrolled = false;
      function arraysEqual(a, b) {
        if (a === b)
          return true;
        if (a == null || b == null)
          return false;
        if (a.length !== b.length)
          return false;
        for (var i = 0; i < a.length; ++i) {
          if (a[i] !== b[i])
            return false;
        }
        return true;
      }
      function scrollToLastPosition(time) {
        if (Math.abs(dom_bulkViewContent.scrollWidth - temp_scrollWidth) < 100) {
          dom_bulkViewContent.style.minHeight = temp_scrollHeight + "px";
          setTimeout(() => {
            dom_bulkViewContent.style.minHeight = "";
            temp_scrollTop = -1;
          }, time);
        }
        if (temp_scrollTop === -1) {
          return;
        }
        dom_bulkView.scrollTop = temp_scrollTop;
        for (let i = 1; i <= 10; i++) {
          setTimeout(() => {
            if (temp_scrollTop === -1) {
              return;
            }
            if (temp_hasScrolled === false && temp_pageNow === pageNow) {
              dom_bulkView.scrollTop = temp_scrollTop;
            }
          }, time / 10 * i);
        }
      }
      arFile = Array.from(M.fileLoad.getWaitingFile());
      if (temp_dirPath === getDirPath() && arraysEqual(arFile, temp_arFile)) {
        if (getIndentation() === "on" && getColumns() === 2) {
          arFile.unshift(svgIndentation);
        }
      } else if (temp_dirPath === getDirPath()) {
        let fileSortType = M.fileSort.getSortType() + M.fileSort.getOrderbyType();
        if (temp_fileSortType === fileSortType) {
          scrollToLastPosition(800);
          await load(pageNow);
        } else {
          dom_bulkView.scrollTop = 0;
          await load();
        }
      } else {
        dom_bulkView.scrollTop = 0;
        await load();
      }
      temp_dirPath = getDirPath();
    }
    async function load(page = 0) {
      arFile = Array.from(M.fileLoad.getWaitingFile());
      if (arFile === void 0) {
        return;
      }
      if (getIndentation() === "on" && getColumns() === 2) {
        arFile.unshift(svgIndentation);
      }
      showPage(page);
    }
    var showPageThrottle = new Throttle(50);
    async function showPage(_page) {
      if (_page === void 0) {
        _page = pageNow;
      }
      if (_page !== void 0) {
        pageNow = _page;
      }
      pageNow = _page;
      if (pageNow < 1) {
        pageNow = 1;
      }
      let pageMax = Math.ceil(arFile.length / imgMaxCount);
      if (pageNow >= pageMax) {
        pageNow = pageMax;
      }
      updatePagination();
      showPageThrottle.run = async () => {
        dom_bulkView.scrollTop = 0;
        dom_bulkViewContent.innerHTML = "";
        let temp = pageNow + getDirPath();
        let start = (pageNow - 1) * imgMaxCount;
        while (true) {
          if (start >= pageNow * imgMaxCount) {
            break;
          }
          let n = 10;
          if (start + n > pageNow * imgMaxCount) {
            n = pageNow * imgMaxCount - start;
          }
          let end = start + n;
          let newArr = arFile.slice(start, end);
          let retAr = await WebAPI.getFileInfo2List(newArr);
          if (temp !== pageNow + getDirPath()) {
            return;
          }
          for (let j = 0; j < retAr.length; j++) {
            const item = retAr[j];
            let domItem = newItem(item);
            dom_bulkViewContent.appendChild(domItem);
          }
          start += n;
        }
        updateSize();
      };
    }
    function updateItemNumber() {
      let arDom = dom_bulkView.querySelectorAll(".bulkView-item");
      for (let i = 0; i < arDom.length; i++) {
        const domItem = arDom[i];
        let domItemPath = domItem.getAttribute("data-path");
        if (domItemPath === null) {
          continue;
        }
        let n = arFile.indexOf(domItemPath) + 1;
        if (getIndentation() === "on" && getColumns() === 2) {
          n = n - 1;
        }
        let domNumber = domItem.querySelector(".bulkView-number");
        if (domNumber !== null) {
          domNumber.innerHTML = n.toString();
        } else {
          domItem.setAttribute("data-number", n.toString());
        }
      }
    }
    var queueUpdateFileWatcher = Promise.resolve();
    function updateFileWatcher(fileWatcherData) {
      let newAr = Array.from(M.fileLoad.getWaitingFile());
      let dirPath = getDirPath();
      queueUpdateFileWatcher = queueUpdateFileWatcher.then(async () => {
        if (isVisible === false) {
          return;
        }
        if (dirPath !== getDirPath()) {
          return;
        }
        let deleteIndex = -1;
        if (fileWatcherData.ChangeType === "deleted") {
          if (arFile.length > 0 && arFile[0] === svgIndentation) {
            arFile.shift();
          }
          for (let i = 0; i < arFile.length; i++) {
            if (arFile[i] != newAr[i]) {
              deleteIndex = i;
              break;
            }
          }
        }
        if (getIndentation() === "on" && getColumns() === 2) {
          newAr.unshift(svgIndentation);
          if (deleteIndex !== -1) {
            deleteIndex += 1;
          }
        }
        arFile = newAr;
        if (fileWatcherData.ChangeType === "created") {
          if (pageNow < 1) {
            pageNow = 1;
          }
          let index = arFile.indexOf(fileWatcherData.FullPath);
          if (index === -1) {
            return;
          }
          let items = dom_bulkView.querySelectorAll(".bulkView-item");
          let isEnd = false;
          let whenInsertingFile = M.config.settings.other.whenInsertingFile;
          if (whenInsertingFile === "end") {
            isEnd = true;
          } else if (whenInsertingFile === "auto" && M.fileSort.getOrderbyType() === "asc") {
            isEnd = true;
          }
          if (isEnd) {
            if ((pageNow - 1) * imgMaxCount < index + 1 && index < pageNow * imgMaxCount) {
              let newItemDom = await pathToItem(fileWatcherData.FullPath);
              if (items.length !== 0) {
                let thirdItem = items[items.length - 1];
                thirdItem.insertAdjacentElement("afterend", newItemDom);
              } else {
                dom_bulkViewContent.appendChild(newItemDom);
              }
            }
          } else {
            if (pageNow === 1) {
              let newItemDom = await pathToItem(fileWatcherData.FullPath);
              if (items.length !== 0) {
                let thirdItem;
                if (getIndentation() === "on" && getColumns() === 2) {
                  thirdItem = items[1];
                } else {
                  thirdItem = items[0];
                }
                thirdItem.insertAdjacentElement("beforebegin", newItemDom);
              } else {
                dom_bulkViewContent.appendChild(newItemDom);
              }
            } else {
              let path = arFile[(pageNow - 1) * imgMaxCount];
              let newItemDom = await pathToItem(path);
              if (items.length !== 0) {
                let thirdItem = items[0];
                thirdItem.insertAdjacentElement("beforebegin", newItemDom);
              } else {
                dom_bulkViewContent.appendChild(newItemDom);
              }
            }
            items = dom_bulkView.querySelectorAll(".bulkView-item");
            if (items.length > imgMaxCount) {
              let removeCount = items.length - imgMaxCount;
              for (let i = items.length - 1; i >= items.length - removeCount; i--) {
                items[i].remove();
              }
            }
          }
          updateItemNumber();
          updatePagination();
        } else if (fileWatcherData.ChangeType === "deleted") {
          if (deleteIndex === -1) {
            return;
          }
          let pageMax = Math.ceil(arFile.length / imgMaxCount);
          if (pageNow > pageMax) {
            pageNow = pageMax;
            showPage();
            return;
          }
          if (deleteIndex + 1 > pageNow * imgMaxCount) {
            updatePagination();
          } else if (deleteIndex < (pageNow - 1) * imgMaxCount) {
            let arDom = dom_bulkView.querySelectorAll(".bulkView-item");
            if (arDom.length > 0) {
              arDom[0].remove();
            }
            if (pageNow < pageMax) {
              let newItemDom = await pathToItem(arFile[pageNow * imgMaxCount - 1]);
              let items = dom_bulkView.querySelectorAll(".bulkView-item");
              let thirdItem = items[items.length - 1];
              thirdItem.insertAdjacentElement("afterend", newItemDom);
            }
            updateItemNumber();
            updatePagination();
          } else {
            let isDelete = false;
            let domItem;
            let arDom = dom_bulkView.querySelectorAll(".bulkView-item");
            for (let i = 0; i < arDom.length; i++) {
              domItem = arDom[i];
              let domItemPath = domItem.getAttribute("data-path");
              if (domItemPath === fileWatcherData.FullPath) {
                isDelete = true;
                break;
              }
            }
            if (isDelete) {
              if (pageNow * imgMaxCount - 1 < arFile.length) {
                let newItemDom = await pathToItem(arFile[pageNow * imgMaxCount - 1]);
                let items = dom_bulkView.querySelectorAll(".bulkView-item");
                let thirdItem = items[items.length - 1];
                thirdItem.insertAdjacentElement("afterend", newItemDom);
              }
              domItem?.remove();
              updateItemNumber();
            }
            updatePagination();
          }
        } else if (fileWatcherData.ChangeType === "renamed") {
          let domItem;
          let arDom = dom_bulkView.querySelectorAll(".bulkView-item");
          for (let i = 0; i < arDom.length; i++) {
            const dom = arDom[i];
            let domItemPath = dom.getAttribute("data-path");
            if (domItemPath === fileWatcherData.OldFullPath) {
              domItem = dom;
              break;
            }
          }
          if (domItem !== void 0) {
            let newItemDom = await pathToItem(fileWatcherData.FullPath);
            domItem.insertAdjacentElement("afterend", newItemDom);
            domItem.remove();
            updateItemNumber();
          } else {
            return;
          }
        } else if (fileWatcherData.ChangeType === "changed") {
          let domItem;
          let arDom = dom_bulkView.querySelectorAll(".bulkView-item");
          for (let i = 0; i < arDom.length; i++) {
            let dom = arDom[i];
            let domItemPath = dom.getAttribute("data-path");
            if (domItemPath === fileWatcherData.FullPath) {
              domItem = dom;
              break;
            }
          }
          if (domItem !== void 0) {
            let dataReload = domItem.getAttribute("data-reload");
            if (dataReload === "true") {
              return;
            }
            let domCenter = domItem.querySelector(".bulkView-center");
            if (domCenter === null) {
              return;
            }
            let div = Lib.newDom(`<div class="bulkView-reload">${SvgList["tool-rotateCw.svg"]}</div>`);
            domCenter.appendChild(div);
            domItem.setAttribute("data-reload", "true");
          } else {
            return;
          }
        }
        updateSize();
      });
    }
    async function pathToItem(path) {
      let retAr = await WebAPI.getFileInfo2List([path]);
      let newItemDom = newItem(retAr[0]);
      return newItemDom;
    }
    function updatePagination() {
      let pageMax = Math.ceil(arFile.length / imgMaxCount);
      dom_bulkView.querySelectorAll(".bulkView-pagination-select").forEach((dom) => {
        let html = "";
        for (let i = 0; i < pageMax; i++) {
          let n = i + 1;
          let start = i * imgMaxCount + 1;
          let end = (i + 1) * imgMaxCount;
          if (end >= arFile.length) {
            end = arFile.length;
          }
          if (getIndentation() === "on" && getColumns() === 2) {
            start -= 1;
            end -= 1;
          }
          html += `<option value="${n}">${n}\u3000(${start}~${end})</option>`;
        }
        dom.innerHTML = html;
        dom.value = pageNow.toString();
      });
      dom_bulkView.querySelectorAll(".bulkView-pagination-prev").forEach((dom) => {
        if (pageNow === 1) {
          dom.setAttribute("freeze", "true");
        } else {
          dom.setAttribute("freeze", "");
        }
      });
      dom_bulkView.querySelectorAll(".bulkView-pagination-next").forEach((dom) => {
        if (pageNow === pageMax) {
          dom.setAttribute("freeze", "true");
        } else {
          dom.setAttribute("freeze", "");
        }
      });
      dom_bulkView.querySelectorAll(".bulkView-pagination").forEach((dom) => {
        if (pageMax !== 1) {
          dom.setAttribute("active", "true");
        } else {
          dom.setAttribute("active", "");
        }
      });
    }
    function newItem(fileInfo2) {
      let n = arFile.indexOf(fileInfo2.Path) + 1;
      if (getIndentation() === "on" && getColumns() === 2) {
        n -= 1;
      }
      let temp = pageNow + getDirPath();
      let size = Math.floor(dom_bulkViewContent.offsetWidth / getColumns());
      let div = Lib.newDom(`
                <div class="bulkView-item">
                    <div class="bulkView-center bulkView-loading">
                        <img class="bulkView-img">
                    </div>
                </div>
            `);
      if (n !== 0) {
        div.setAttribute("data-path", fileInfo2.Path);
      }
      div.style.width = size + "px";
      div.style.minHeight = size + "px";
      updateSize(div);
      setTimeout(async () => {
        if (fileInfo2.Path.length > 255) {
          fileInfo2.Path = await WV_Path.GetShortPath(fileInfo2.Path);
        }
        let imgData = await M.script.img.getImgData(fileInfo2);
        let width = imgData.width;
        let height = imgData.height;
        let arUrl = imgData.arUrl;
        if (temp !== pageNow + getDirPath()) {
          return;
        }
        let dataNumber = div.getAttribute("data-number");
        if (dataNumber !== null) {
          div.removeAttribute("data-number");
          n = Number(dataNumber);
        }
        let fileName = Lib.GetFileName(fileInfo2.FullPath);
        let LastWriteTimeUtc = fileInfo2.LastWriteTimeUtc;
        let LastWriteTime = new Date(LastWriteTimeUtc).format("yyyy-MM-dd hh:mm:ss");
        let writeDate = new Date(LastWriteTimeUtc).format("yyyy-MM-dd");
        let writeTime = new Date(LastWriteTimeUtc).format("hh:mm:ss");
        let fileSize = Lib.getFileLength(fileInfo2.Lenght);
        div.innerHTML = `
                <div class="bulkView-header">
                    <div class="bulkView-number">${n}</div>
                    <div class="bulkView-fileName">${fileName}</div>
                </div>
                <div class="bulkView-header2">
                    <div class="bulkView-tag bulkView-imageSize">${width},${height}</div>
                    <div class="bulkView-tag bulkView-fileSize">${fileSize}</div>
                    <div class="bulkView-tag bulkView-lastWriteDate">${writeDate}</div>
                    <div class="bulkView-tag bulkView-lastWriteTime">${writeTime}</div>
                </div>
                <div class="bulkView-center">
                    <img class="bulkView-img">
                </div>`;
        div.setAttribute("data-width", width.toString());
        div.setAttribute("data-height", height.toString());
        div.style.width = size + "px";
        div.style.minHeight = size + "px";
        updateSize(div);
        div.addEventListener("click", async () => {
          if (div.getAttribute("data-reload") === "true") {
            let newItemDom = await pathToItem(fileInfo2.Path);
            div.insertAdjacentElement("afterend", newItemDom);
            div.remove();
            updateItemNumber();
          } else if (n !== 0) {
            M.fileLoad.setIsBulkViewSub(true);
            let index = arFile.indexOf(fileInfo2.FullPath);
            if (arFile.length > 0 && arFile[0] === svgIndentation) {
              index -= 1;
            }
            await M.script.bulkView.close(index);
            M.toolbarBack.visible(true);
            M.toolbarBack.setEvent(() => {
              M.script.bulkView.show();
            });
          }
        });
        let dom_img = div.querySelector(".bulkView-img");
        let dom_center = div.querySelector(".bulkView-center");
        let dom_header = div.querySelector(".bulkView-header");
        let dom_header2 = div.querySelector(".bulkView-header2");
        let title = `${M.i18n.t("bulkView.imageSize")}\uFF1A${width} x ${height}
${M.i18n.t("bulkView.fileSize")}\uFF1A${fileSize}
${M.i18n.t("bulkView.lastWriteDate")}\uFF1A${LastWriteTime}`;
        dom_header.setAttribute("title", title);
        dom_header2.setAttribute("title", title);
        if (dom_img.onerror === null) {
          dom_img.onerror = () => {
            dom_img.src = "./img/error.svg";
          };
        }
        new ResizeObserver(Lib.debounce(() => {
          if (isVisible === false) {
            return;
          }
          let ret = arUrl[0];
          let boxWidth = dom_center.offsetWidth;
          if (boxWidth <= 10) {
            return;
          }
          if (getFixedWidth() !== "off") {
            let columns = getColumns();
            if (columns === 1 || columns === 2) {
              boxWidth = boxWidth * Number.parseInt(getFixedWidth()) / 100;
            }
          }
          let nowScale = boxWidth / width;
          for (let i = arUrl.length - 1; i >= 0; i--) {
            const item = arUrl[i];
            if (item.scale >= nowScale) {
              ret = item;
              break;
            }
          }
          if (dom_img.getAttribute("src") !== ret.url) {
            limiter.addRequest(dom_img, ret.url);
          }
          updateSize();
        }, 300)).observe(div);
      }, 0);
      return div;
    }
    function pageNext() {
      let page = pageNow;
      page += 1;
      let pageMax = Math.ceil(arFile.length / imgMaxCount);
      if (page >= pageMax) {
        page = pageMax;
      }
      if (page !== pageNow) {
        pageNow = page;
        showPage();
      }
    }
    function pagePrev() {
      let page = pageNow;
      page -= 1;
      if (page <= 1) {
        page = 1;
      }
      if (page !== pageNow) {
        pageNow = page;
        showPage();
      }
    }
    function setImgMaxCount(n) {
      n = Math.floor(n);
      if (n < 1) {
        n = 1;
      }
      if (isVisible && n !== imgMaxCount) {
        imgMaxCount = n;
        load();
      }
      if (isVisible === false && n !== imgMaxCount) {
        imgMaxCount = n;
        temp_dirPath = "";
      } else {
        imgMaxCount = n;
      }
    }
    function incrColumns() {
      setColumns(getColumns() + 1);
    }
    function decColumns() {
      setColumns(getColumns() - 1);
    }
    function incrFixedWidth() {
      let n = Number(getFixedWidth());
      if (isNaN(n)) {
        n = 40;
      }
      n += 10;
      if (n < 40) {
        n = 40;
      }
      if (n > 100) {
        n = 100;
      }
      setFixedWidth(n.toString());
    }
    function decFixedWidth() {
      let n = Number(getFixedWidth());
      if (isNaN(n)) {
        n = 40;
      }
      n -= 10;
      if (n < 40) {
        n = 40;
      }
      if (n > 100) {
        n = 100;
      }
      setFixedWidth(n.toString());
    }
    function getDirPath() {
      return M.fileLoad.getDirPath();
    }
    function initGroupRadio(dom) {
      dom.addEventListener("click", (e) => {
        let domActive2 = e.target;
        if (domActive2 === null) {
          return;
        }
        let value2 = domActive2.getAttribute("value");
        if (value2 === null) {
          value2 = "";
        }
        setGroupRadioVal(dom, value2);
      });
      let domActive = dom.querySelector("[active=true]");
      if (domActive === null) {
        return "";
      }
      let value = domActive.getAttribute("value");
      if (value === null) {
        value = "";
      }
      return value;
    }
    function getGroupRadioVal(dom) {
      let domActive = dom.querySelector("[active=true]");
      if (domActive === null) {
        return "";
      }
      let value = domActive.getAttribute("value");
      if (value === null) {
        value = "";
      }
      return value;
    }
    function setGroupRadioVal(dom, value) {
      let domActive = dom.querySelector(`[value="${value}"]`);
      if (domActive === null) {
        return;
      }
      let arDom = dom.querySelectorAll("div");
      for (let i = 0; i < arDom.length; i++) {
        arDom[i].setAttribute("active", "");
      }
      domActive.setAttribute("active", "true");
    }
  }
}
class RequestLimiter {
  constructor(maxRequests) {
    this.queue = [];
    this.inProgress = 0;
    this.maxRequests = maxRequests;
  }
  addRequest(img, url) {
    if (!document.body.contains(img)) {
      return;
    }
    const index = this.queue.findIndex(([i, u]) => i === img && u === url);
    if (index !== -1) {
      return;
    }
    const index2 = this.queue.findIndex(([i, u]) => i === img && u !== url);
    if (index2 !== -1) {
      this.queue.splice(index2, 1);
    }
    this.queue.push([img, url]);
    this.processQueue();
  }
  processQueue() {
    while (this.inProgress < this.maxRequests && this.queue.length > 0) {
      this.inProgress++;
      const [img, url] = this.queue.shift();
      this.loadImage(img, url).then(() => {
        this.inProgress--;
        this.processQueue();
      });
    }
  }
  loadImage(img, url) {
    return new Promise((resolve) => {
      if (!document.body.contains(img)) {
        resolve();
        return;
      }
      img.addEventListener("load", () => resolve(), { once: true });
      img.addEventListener("error", () => resolve(), { once: true });
      img.src = url;
    });
  }
}
