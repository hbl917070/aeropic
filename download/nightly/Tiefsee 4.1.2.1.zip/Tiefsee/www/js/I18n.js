class I18n {
  constructor() {
    this.getData = getData;
    this.setData = setData;
    this.pushData = pushData;
    this.t = get;
    this.tSpan = tSpan;
    this.get = get;
    this.setAll = setAll;
    this.initNone = initNone;
    this.getDefaultLang = getDefaultLang;
    this.setDefaultLang = setDefaultLang;
    this.getLang = getLang;
    this.setLang = setLang;
    this.getEventRun = getEventRun;
    this.setEventRun = setEventRun;
    var lang = "";
    var defaultLang = "en";
    var eventRun = (lang2) => {
    };
    if (window.localStorage.getItem("i18n") !== null) {
      let s = window.localStorage.getItem("i18n");
      if (s != null) {
        lang = s;
      }
    }
    if (window.localStorage.getItem("i18n_DefaultLang") !== null) {
      let s = window.localStorage.getItem("i18n_DefaultLang");
      if (s != null) {
        defaultLang = s;
      }
    }
    function setEventRun(action) {
      eventRun = action;
    }
    function getEventRun() {
      return eventRun;
    }
    function getDefaultLang() {
      return defaultLang;
    }
    function setDefaultLang(type) {
      defaultLang = type;
      window.localStorage.setItem("i18n_DefaultLang", type);
    }
    function getData() {
      return data;
    }
    function setData(json) {
      data = json;
    }
    function pushData(json) {
      mergeJSON(data, json);
      data = json;
    }
    function getLang() {
      return lang;
    }
    function setLang(type) {
      lang = type;
      window.localStorage.setItem("i18n", type);
      setAll();
    }
    function applyValue(str, value) {
      if (value === void 0 || value.length === 0) {
        return str;
      }
      let arkay = Object.keys(value);
      for (let i = 0; i < arkay.length; i++) {
        const k = arkay[i];
        const v = value[k];
        str = str.replace(new RegExp("{[ ]*" + k + "[ ]*}", "g"), v);
      }
      return str;
    }
    function get(key, value, type) {
      if (key === null) {
        return "";
      }
      let arkey = key.split(".");
      let d = data;
      for (let i = 0; i < arkey.length; i++) {
        let k = arkey[i];
        if (d.hasOwnProperty(k)) {
          d = d[k];
        }
      }
      if (type === void 0) {
        type = lang;
      }
      if (typeof d === "string") {
        return get(d.toString(), value, type);
      } else if (d.hasOwnProperty(type) && d[type] !== null) {
        return applyValue(d[type], value);
      } else if (d.hasOwnProperty(defaultLang)) {
        return applyValue(d[defaultLang], value);
      }
      if (key !== "") {
        console.log(`i18n missing: "${key}"`);
      }
      return arkey[arkey.length - 1];
    }
    function tSpan(key, value, type) {
      if (key == null) {
        return `<span></span>`;
      }
      let t = key.replace(/["]/g, `\\"`);
      return `<span i18n="${t}">${get(key, value, type)}</span>`;
    }
    function setAll(type = void 0) {
      if (type === void 0) {
        type = lang;
      }
      var ar_i18n = document.querySelectorAll("[i18n]");
      for (let i = 0; i < ar_i18n.length; i++) {
        const item = ar_i18n[i];
        let key = item.getAttribute("i18n");
        let val = item.getAttribute("i18n-v");
        let t = "";
        if (val !== null) {
          t = get(key, JSON.parse(val), type);
        } else {
          t = get(key, {}, type);
        }
        updateDom(item, t);
      }
      eventRun(type);
    }
    function initNone() {
      var ar_i18n = document.querySelectorAll("[i18n]");
      for (let i = 0; i < ar_i18n.length; i++) {
        const item = ar_i18n[i];
        updateDom(item, "");
      }
    }
    function updateDom(dom, t) {
      if (dom.getAttribute("i18n") === "") {
        return;
      } else if (dom.getAttribute("placeholder") !== null) {
        dom.setAttribute("placeholder", t);
      } else if (dom.tagName == "TD" && dom.getAttribute("data-th") !== null) {
        dom.setAttribute("data-th", t);
      } else if (dom.tagName == "OPTGROUP") {
        dom.setAttribute("label", t);
      } else if (dom.getAttribute("title") !== null) {
        dom.setAttribute("title", t);
      } else {
        dom.innerHTML = t;
      }
    }
    function mergeJSON(minor, main) {
      for (var key in minor) {
        if (main[key] === void 0) {
          main[key] = minor[key];
          continue;
        }
        if (isJSON(minor[key])) {
          arguments.callee(minor[key], main[key]);
        }
      }
    }
    function isJSON(target) {
      return typeof target == "object" && target.constructor == Object;
    }
    var data = {};
  }
}
