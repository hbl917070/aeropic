Tiefsee 4.1.2.1

Copyright (C) 2023 hbl917070

https://github.com/hbl917070/Tiefsee4

----------------------------------------------------

The Tiefsee project is open source under the MIT license.
However, the extensions that are installed separately are not part of the Tiefsee project.
They all have their own licenses!

Tiefsee 的原始碼以 MIT 授權形式開源，
但另外安裝那些的擴充套件，並不屬於 Tiefsee 專案的一部分，
他們都有各自的授權條款！