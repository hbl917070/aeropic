const _Lib = class {
  static addEventDblclick(dom, func, dealy = 400) {
    var clickTimeout = -1;
    var _x = 0;
    var _y = 0;
    dom.addEventListener("mousedown", async (e) => {
      if (e.button !== 0) {
        return;
      }
      if (clickTimeout !== -1) {
        clearTimeout(clickTimeout);
        clickTimeout = -1;
        if (Math.abs(_x - e.offsetX) < 4 && Math.abs(_y - e.offsetY) < 4) {
          func(e);
        }
      } else {
        _x = e.offsetX;
        _y = e.offsetY;
        clickTimeout = setTimeout(() => {
          clickTimeout = -1;
        }, dealy);
      }
    });
  }
  static IsAnimation(fileInfo2) {
    let hex = fileInfo2.HexValue;
    if (_Lib.GetExtension(fileInfo2.Path) === ".svg") {
      return true;
    }
    if (hex.indexOf("47 49 46 38") === 0) {
      return true;
    }
    if (hex.indexOf("89 50 4E 47 0D 0A 1A 0A") === 0) {
      if (hex.indexOf("08 61 63 54") > 10) {
        return true;
      }
    }
    if (hex.indexOf("57 45 42 50 56 50 38 58 0A") > 0) {
      return true;
    }
    return false;
  }
  static GetFileType(fileInfo2) {
    let fileExt = _Lib.GetExtension(fileInfo2.FullPath);
    fileExt = fileExt.replace(".", "").toLocaleLowerCase();
    let hex = fileInfo2.HexValue;
    if (hex.indexOf("FF D8 FF") === 0) {
      return "jpg";
    }
    if (hex.indexOf("42 4D") === 0 && hex.length > 30 && hex.substring(18, 29) === "00 00 00 00") {
      return "bmp";
    }
    if (hex.indexOf("47 49 46 38") === 0) {
      return "gif";
    }
    if (hex.indexOf("89 50 4E 47 0D 0A 1A 0A") === 0) {
      if (hex.indexOf("08 61 63 54") > 10) {
        return "apng";
      } else {
        return "png";
      }
    }
    if (hex.indexOf("57 45 42 50 56 50 38 58 0A") > 0) {
      return "webp";
    }
    if (hex.indexOf("57 45 42 50 56 50 38") > 0) {
      return "webp";
    }
    if (hex.indexOf("6D 69 6D 65 74 79 70 65 61 70 70 6C 69 63 61 74 69 6F 6E 2F 76 6E 64 2E 61 64 6F 62 65 2E 73 70 61 72 6B 6C 65 72 2E 70 72 6F 6A 65 63 74 2B 64 63 78 75 63 66 50 4B") > 0) {
      return "xd";
    }
    if (hex.indexOf("25 50 44 46") === 0) {
      if (fileExt === "ai") {
        return "ai";
      }
      return "pdf";
    }
    if (hex.indexOf("4C 00 00 00 01 14 02 00") === 0) {
      return "lnk";
    }
    if (hex.indexOf("66 74 79 70 69 73 6F") === 12) {
      return "mp4";
    }
    if (hex.indexOf("66 74 79 70 6D 70 34") === 12) {
      return "mp4";
    }
    if (hex.indexOf("66 74 79 70 6D 6D 70 34") === 12) {
      return "mp4";
    }
    if (hex.indexOf("66 74 79 70 4D 34 56") === 12) {
      return "mp4";
    }
    if (hex.indexOf("66 74 79 70 61 76 69 66") === 12) {
      return "avif";
    }
    if (hex.indexOf("1A 45 DF A3") === 0) {
      if (hex.indexOf("77 65 62 6D 42 87") > 0) {
        return "webm";
      }
    }
    if (hex.indexOf("4F 67 67 53") === 0) {
      return "ogv";
    }
    if (hex.indexOf("38 42 50 53") === 0) {
      return "psd";
    }
    return fileExt;
  }
  static getFileLength(len) {
    if (len / 1024 < 1) {
      return len.toFixed(1) + " B";
    } else if (len / (1024 * 1024) < 1) {
      return (len / 1024).toFixed(1) + " KB";
    } else if (len / (1024 * 1024 * 1024) < 1) {
      return (len / (1024 * 1024)).toFixed(1) + " MB";
    }
    return (len / (1024 * 1024 * 1024)).toFixed(1) + " GB";
  }
  static URLToPath(path) {
    if (path.indexOf("file:///") === 0) {
      path = path.substring(8);
    } else if (path.indexOf("file://") === 0) {
      path = path.substring(5);
    }
    path = decodeURIComponent(path).replace(/[/]/g, "\\");
    return path;
  }
  static pathToURL(path) {
    return "file:///" + encodeURIComponent(path).replace(/[%]3A/g, ":").replace(/[%]2F/g, "/").replace(/[%]5C/g, "/");
  }
  static escape(htmlStr) {
    if (htmlStr === void 0 || htmlStr === null) {
      return "";
    }
    return htmlStr.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  static isTxtSelect() {
    let selection = window.getSelection();
    if (selection === null) {
      return false;
    }
    let isElect = selection.toString() !== "";
    return isElect;
  }
  static isTextFocused() {
    let dom = document.activeElement;
    if (dom === null) {
      return false;
    }
    let tag = dom.tagName;
    if (tag === "TEXTAREA") {
      return true;
    }
    if (tag === "INPUT" && dom.getAttribute("type") == "text") {
      return true;
    }
    return false;
  }
  static isScrollbarVisible(element, type = "Y") {
    if (type === "y" || type === "Y") {
      return element.scrollHeight > element.clientHeight;
    } else {
      return element.scrollWidth > element.clientWidth;
    }
  }
  static getBrowserLang() {
    let browserLang = navigator.language.toLowerCase();
    if (browserLang == "zh" || browserLang.indexOf("zh-") === 0) {
      return "zh-TW";
    }
    if (browserLang.indexOf("ja") === 0) {
      return "ja";
    }
    return "en";
  }
  static newDom(html) {
    var template = document.createElement("template");
    template.innerHTML = html.trim();
    return template.content.firstChild;
  }
  static async sendGet(type, url) {
    if (type === "text") {
      let txt = "";
      await fetch(url, {
        "method": "get"
      }).then((response) => {
        return response.text();
      }).then((html) => {
        txt = html;
      }).catch((err) => {
        console.log("error: ", err);
      });
      return txt;
    }
    if (type === "json") {
      let json = {};
      await fetch(url, {
        "method": "get"
      }).then((response) => {
        return response.json();
      }).then((html) => {
        json = html;
      }).catch((err) => {
        console.log("error: ", err);
      });
      return json;
    }
    if (type === "base64") {
      let base64 = await new Promise((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.onload = function() {
          var reader = new FileReader();
          reader.onloadend = function() {
            let d = reader.result;
            if (typeof d === "string") {
              resolve(d);
            } else {
              resolve("");
            }
          };
          reader.readAsDataURL(xhr.response);
        };
        xhr.open("GET", url);
        xhr.responseType = "blob";
        xhr.send();
      });
      return base64;
    }
  }
  static async sleep(ms) {
    await new Promise((resolve, reject) => {
      setTimeout(function() {
        resolve(0);
      }, ms);
    });
  }
  static toNumber(t) {
    if (typeof t === "number") {
      return t;
    }
    if (typeof t === "string") {
      return Number(t.replace("px", ""));
    }
    return 0;
  }
  static debounce(func, delay = 250) {
    let timer = null;
    return function(...args) {
      let context = this;
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(() => {
        func.apply(context, args);
      }, delay);
    };
  }
  static getRadio(queryName) {
    return $(`${queryName}:checked`).val() + "";
  }
  static setRadio(queryName, value) {
    $(`${queryName}[value="${value}"]`).prop("checked", true);
  }
};
let Lib = _Lib;
Lib.GetDirectoryName = (path) => {
  path = path.replace(/[/]/ig, "\\");
  let count = path.split("\\").length - 1;
  if (count === 0) {
    return null;
  }
  if (path.length <= 2) {
    return null;
  }
  if (path.substring(0, 2) === "\\\\") {
    if (count <= 3) {
      return null;
    }
    if (count === 4) {
      if (path.lastIndexOf("\\") === path.length - 1) {
        return null;
      }
    }
  } else {
    if (count === 1) {
      if (path.lastIndexOf("\\") === path.length - 1) {
        return null;
      }
    }
  }
  let name = path.substring(0, path.lastIndexOf("\\"));
  count = name.split("\\").length - 1;
  if (count === 0) {
    name = name + "\\";
  }
  return name;
};
Lib.GetFileName = (path) => {
  path = path.replace(/[/]/ig, "\\");
  let name = path.substring(path.lastIndexOf("\\") + 1);
  return name;
};
Lib.GetExtension = (path) => {
  path = path.replace(/[/]/ig, "\\");
  let name = path.substring(path.lastIndexOf("\\") + 1);
  let index = name.lastIndexOf(".");
  if (index === -1) {
    return "";
  }
  return "." + name.substring(index + 1).toLocaleLowerCase();
};
Lib.Combine = (arPath) => {
  if (arPath.length === 0) {
    return "";
  }
  if (arPath.length === 1) {
    return arPath[0];
  }
  let sum = arPath[0];
  sum = sum.replace(/[\\]+$/, "");
  sum += "\\";
  for (let i = 1; i < arPath.length; i++) {
    let item = arPath[i];
    item = item.replace(/^([\\])+/, "");
    item = item.replace(/[\\]+$/, "");
    sum += item;
    if (i != arPath.length - 1) {
      sum += "\\";
    }
  }
  return sum;
};
Date.prototype.format = function(format) {
  const o = {
    "M+": this.getMonth() + 1,
    "d+": this.getDate(),
    "h+": this.getHours(),
    "m+": this.getMinutes(),
    "s+": this.getSeconds(),
    "q+": Math.floor((this.getMonth() + 3) / 3),
    "S": this.getMilliseconds()
  };
  format = format.replace(/(y+)/, (match) => {
    return (this.getFullYear() + "").substring(4 - match.length);
  });
  for (const k in o) {
    format = format.replace(new RegExp("(" + k + ")"), (match) => {
      return match.length == 1 ? o[k].toString() : ("00" + o[k]).substring(("" + o[k]).length);
    });
  }
  return format;
};
class Throttle {
  constructor(_timeout = 50) {
    this.run = async () => {
    };
    this.timeout = 50;
    this.timeout = _timeout;
    this.timer();
  }
  async timer() {
    let _func = this.run;
    this.run = async () => {
    };
    await _func();
    setTimeout(() => {
      this.timer();
    }, this.timeout);
  }
}
