class FileLoad {
  constructor(M) {
    var groupType = "img";
    var fileLoadType;
    var arFile = [];
    var flagFile;
    var isLoadFileFinish = true;
    var isBulkView = false;
    var isBulkViewSub = false;
    var temp_reloadFilePath = "";
    var dirPathNow = "";
    var arDir = {};
    var arDirKey = [];
    var flagDir;
    var atLoadingDirParent = "";
    var atLoadingGroupType = "";
    var atLoadingExt = "";
    this.getWaitingFile = () => {
      return arFile;
    };
    this.setWaitingFile = (ar) => {
      arFile = ar;
    };
    this.getFlagFile = () => {
      return flagFile;
    };
    this.setFlagFile = (n) => {
      flagFile = n;
    };
    this.showDir = showDir;
    this.prevDir = prevDir;
    this.nextDir = nextDir;
    this.getWaitingDir = () => {
      return arDir;
    };
    this.setWaitingDir = (ar) => {
      arDir = ar;
      arDirKey = Object.keys(arDir);
    };
    this.getWaitingDirKey = () => {
      return arDirKey;
    };
    this.getFlagDir = () => {
      return flagDir;
    };
    this.setFlagDir = (n) => {
      flagDir = n;
    };
    this.updateFlagDir = updateFlagDir;
    this.getDirPath = getDirPath;
    this.reloadDirPanel = reloadDirPanel;
    this.loadDropFile = loadDropFile;
    this.loadFile = loadFile;
    this.loadFiles = loadFiles;
    this.reloadFilePanel = reloadFilePanel;
    this.nextFile = nextFile;
    this.prevFile = prevFile;
    this.showFile = showFile;
    this.getFilePath = getFilePath;
    this.getFileShortPath = getFileShortPath;
    this.getGroupType = getGroupType;
    this.setGroupType = setGroupType;
    this.getFileLoadType = getFileLoadType;
    this.showDeleteFileMsg = showDeleteFileMsg;
    this.showDeleteDirMsg = showDeleteDirMsg;
    this.showRenameFileMsg = showRenameFileMsg;
    this.showRenameDirMsg = showRenameDirMsg;
    this.updateTitle = updateTitle;
    this.enableBulkView = enableBulkView;
    this.getIsBulkView = function() {
      return isBulkView;
    };
    this.setIsBulkViewSub = function(val) {
      isBulkViewSub = val;
    };
    this.fileExtToGroupType = fileExtToGroupType;
    function reloadDirPanel() {
      atLoadingDirParent = "";
      loadDir(getDirPath());
    }
    function getDirPath() {
      return dirPathNow;
    }
    async function updateFlagDir(_dirPath) {
      if (_dirPath === void 0) {
        return;
      }
      flagDir = 0;
      for (let i = 0; i < arDirKey.length; i++) {
        const path = arDirKey[i];
        if (path === _dirPath) {
          flagDir = i;
          return;
        }
      }
      if (arDirKey.length === 0) {
        return;
      }
      await initDirList(dirPathNow);
      await M.dirSort.sort();
      M.mainDirList.init();
      for (let i = 0; i < arDirKey.length; i++) {
        const path = arDirKey[i];
        if (path === _dirPath) {
          flagDir = i;
          return;
        }
      }
    }
    async function isUpdateDirList(_dirPath) {
      let dirParent = Lib.GetDirectoryName(_dirPath);
      if (dirParent === null) {
        dirParent = _dirPath;
      }
      dirParent = dirParent + atLoadingGroupType;
      if (atLoadingDirParent === dirParent) {
        return false;
      }
      atLoadingDirParent = dirParent;
      return true;
    }
    async function initDirList(_dirPath) {
      let arExt = [];
      let ar = M.config.allowFileType(atLoadingGroupType);
      for (let i = 0; i < ar.length; i++) {
        arExt.push(ar[i]["ext"]);
      }
      if (atLoadingExt !== void 0 && atLoadingExt !== "") {
        let ext = atLoadingExt.replace(".", "");
        if (arExt.indexOf(ext) === -1) {
          arExt.push(ext);
        }
      }
      let maxCount = M.config.settings.advanced.dirListMaxCount;
      let json = await WebAPI.Directory.getSiblingDir(dirPathNow, arExt, maxCount);
      if (dirPathNow !== _dirPath) {
        return;
      }
      arDir = json;
      arDirKey = Object.keys(arDir);
    }
    function clearDir() {
      arDir = {};
      arDirKey = Object.keys(arDir);
      M.mainDirList.init();
    }
    var showDirThrottle = new Throttle(5);
    async function showDir(_flag) {
      if (groupType === GroupType.none || groupType === GroupType.welcome) {
        return;
      }
      if (_flag !== void 0) {
        flagDir = _flag;
      }
      if (flagDir < 0) {
        flagDir = 0;
      }
      if (flagDir >= arDirKey.length) {
        flagDir = arDirKey.length - 1;
      }
      if (arDirKey.length === 0) {
        showDirThrottle.run = async () => {
        };
        return;
      }
      let path = arDirKey[flagDir];
      if (await WV_Directory.Exists(path) === false) {
        delete arDir[path];
        arDirKey = Object.keys(arDir);
        showDir(_flag);
        M.mainDirList.init();
        return;
      }
      await updateFlagDir(path);
      M.mainDirList.select();
      M.mainDirList.updateLocation();
      showDirThrottle.run = async () => {
        await loadFile(path, atLoadingGroupType);
      };
    }
    async function nextDir() {
      flagDir += 1;
      if (flagDir >= arDirKey.length) {
        flagDir = 0;
      }
      showDir();
    }
    async function prevDir() {
      flagDir -= 1;
      if (flagDir < 0) {
        flagDir = arDirKey.length - 1;
      }
      showDir();
    }
    async function loadDir(_dirPath) {
      dirPathNow = _dirPath;
      if (await isUpdateDirList(_dirPath)) {
        await initDirList(_dirPath);
        let dirParentPath = Lib.GetDirectoryName(_dirPath);
        if (dirParentPath === null) {
          dirParentPath = _dirPath;
        }
        await WV_System.NewFileWatcher("dirList", dirParentPath);
        M.dirSort.readSortType(dirParentPath);
        M.dirSort.updateMenu();
        await M.dirSort.sort(_dirPath);
        await updateFlagDir(_dirPath);
        M.mainDirList.init();
        M.mainDirList.setStartLocation();
      } else {
        await updateFlagDir(_dirPath);
        M.mainDirList.select();
        M.mainDirList.updateLocation();
      }
    }
    async function loadDropFile(files) {
      let _dropPath = await baseWindow.getDropPath();
      if (_dropPath === "") {
        return;
      }
      M.msgbox.closeAll();
      M.menu.close();
      if (files.length > 1) {
        let dirPath = Lib.GetDirectoryName(_dropPath);
        if (dirPath === null) {
          return;
        }
        if (dirPath !== null) {
          await loadFiles(dirPath, files);
        }
      } else {
        await loadFile(_dropPath);
      }
    }
    async function loadFiles(dirPath, arName = []) {
      await WV_System.NewFileWatcher("fileList", "");
      dirPath = await WV_Path.GetFullPath(dirPath);
      dirPathNow = dirPath;
      fileLoadType = FileLoadType.userDefined;
      arFile = await WebAPI.Directory.getFiles2(dirPath, arName);
      let path = arFile[0];
      let fileInfo2 = await WebAPI.getFileInfo2(path);
      atLoadingGroupType = fileToGroupType(fileInfo2);
      atLoadingExt = Lib.GetExtension(path);
      M.fileSort.readSortType(dirPath);
      M.fileSort.updateMenu();
      arFile = await M.fileSort.sort(arFile);
      flagFile = arFile.indexOf(path);
      M.mainFileList.setHide(false);
      M.mainFileList.init();
      M.mainFileList.setStartLocation();
      await showFile();
      loadDir(dirPath);
    }
    async function loadFile(path, _dirGroupType, noLoad = false) {
      if (isLoadFileFinish === false) {
        console.log("loadFile\u8655\u7406\u4E2D");
        return;
      }
      isLoadFileFinish = false;
      fileLoadType = FileLoadType.dir;
      let fileInfo2 = await WebAPI.getFileInfo2(path);
      path = fileInfo2.Path;
      arFile = [];
      let isFile = true;
      if (fileInfo2.Type === "dir") {
        isFile = false;
        dirPathNow = path;
        arFile = await WebAPI.Directory.getFiles(path, "*.*");
        await WV_System.NewFileWatcher("fileList", dirPathNow);
        M.fileSort.readSortType(path);
        M.fileSort.updateMenu();
        arFile = await M.fileSort.sort(arFile);
        if (_dirGroupType === void 0) {
          groupType = GroupType.img;
          atLoadingExt = void 0;
        } else {
          groupType = _dirGroupType;
        }
        atLoadingGroupType = groupType;
        let _arFile = await filter(atLoadingExt);
        if (_arFile.length !== 0) {
          arFile = _arFile;
        } else {
          filterOfficeTemp(arFile);
          fileLoadType = FileLoadType.userDefined;
        }
      } else if (fileInfo2.Type === "file") {
        let _dirPath = Lib.GetDirectoryName(path);
        if (_dirPath === null) {
          return;
        }
        dirPathNow = _dirPath;
        groupType = fileToGroupType(fileInfo2);
        atLoadingGroupType = groupType;
        atLoadingExt = Lib.GetExtension(path);
        await WV_System.NewFileWatcher("fileList", dirPathNow);
        arFile = [path];
        flagFile = 0;
        if (isBulkView === false && noLoad === false) {
          await showFileUpdataImg(fileInfo2);
          M.mainExif.init(fileInfo2, true);
        }
        arFile = await WebAPI.Directory.getFiles(dirPathNow, "*.*");
        arFile = await filter(Lib.GetExtension(path));
        if (arFile.indexOf(path) === -1) {
          arFile.splice(0, 0, path);
        }
        M.fileSort.readSortType(dirPathNow);
        M.fileSort.updateMenu();
        arFile = await M.fileSort.sort(arFile);
      } else {
        M.fileShow.openWelcome();
        return;
      }
      flagFile = arFile.indexOf(path);
      isLoadFileFinish = true;
      M.mainFileList.setHide(false);
      M.mainFileList.init();
      M.mainFileList.setStartLocation();
      if (noLoad === false) {
        if (isBulkView) {
          await showFile();
        } else if (isFile) {
          await showFileUpdataUI();
        } else {
          await showFile();
        }
        loadDir(dirPathNow);
      }
    }
    function getFilePath() {
      let p = arFile[flagFile];
      return p;
    }
    function reloadFilePanel() {
      if (fileLoadType === FileLoadType.dir) {
        loadFile(getFilePath(), atLoadingExt, true);
      } else {
        M.mainFileList.init();
        M.mainFileList.setStartLocation();
      }
    }
    async function getFileShortPath(path) {
      if (path === void 0) {
        path = getFilePath();
      }
      if (path.length > 255) {
        path = await WV_Path.GetShortPath(path);
      }
      return path;
    }
    function getFileLoadType() {
      return fileLoadType;
    }
    function getGroupType() {
      return groupType;
    }
    function setGroupType(type) {
      groupType = type;
    }
    function enableBulkView(val) {
      isBulkView = val;
    }
    var showFileThrottle = new Throttle(5);
    async function showFile(_flag) {
      if (isBulkView === false && isBulkViewSub === false) {
        M.toolbarBack.visible(false);
      }
      isBulkViewSub = false;
      if (isLoadFileFinish === false) {
        console.log("loadFile\u8655\u7406\u4E2D");
        return;
      }
      if (arFile.length === 0) {
        Toast.show(M.i18n.t("msg.imageNotFound"), 1e3 * 3);
        M.fileShow.openWelcome();
        showFileThrottle.run = async () => {
          atLoadingDirParent = "";
          arDir = {};
          arDirKey = [];
        };
        return;
      }
      if (_flag !== void 0 || _flag === -1) {
        flagFile = _flag;
      }
      if (flagFile < 0) {
        flagFile = 0;
      }
      if (flagFile >= arFile.length) {
        flagFile = arFile.length - 1;
      }
      let path = getFilePath();
      let fileInfo2 = await WebAPI.getFileInfo2(path);
      if (fileInfo2.Type !== "none") {
        M.mainExif.init(fileInfo2);
        await showFileUpdataUI();
      }
      await showFileUpdataImg(fileInfo2);
    }
    async function showFileUpdataUI() {
      updateTitle();
      M.mainFileList.select();
      M.mainFileList.updateLocation();
    }
    async function showFileUpdataImg(fileInfo2) {
      if (fileInfo2.Type === "none") {
        arFile.splice(flagFile, 1);
        M.mainFileList.init();
        showFile(flagFile);
        showFileThrottle.run = async () => {
        };
        return;
      }
      updateTitle();
      if (fileLoadType === FileLoadType.userDefined) {
        groupType = fileToGroupType(fileInfo2);
      }
      showFileThrottle.run = async () => {
        if (isBulkView) {
          await M.fileShow.openBulkView();
        } else {
          if (fileInfo2.Path.length > 255) {
            fileInfo2.Path = await WV_Path.GetShortPath(fileInfo2.Path);
          }
          if (groupType === GroupType.img || groupType === GroupType.unknown) {
            await M.fileShow.openImage(fileInfo2);
          }
          if (groupType === GroupType.video) {
            await M.fileShow.openVideo(fileInfo2);
          }
          if (groupType === GroupType.pdf) {
            await M.fileShow.openPdf(fileInfo2);
          }
          if (groupType === GroupType.txt) {
            await M.fileShow.openTxt(fileInfo2);
          }
        }
      };
    }
    async function nextFile() {
      if (isLoadFileFinish === false) {
        console.log("loadFile\u8655\u7406\u4E2D");
        return;
      }
      if (groupType === GroupType.none || groupType === GroupType.welcome) {
        return;
      }
      flagFile += 1;
      if (flagFile >= arFile.length) {
        flagFile = 0;
      }
      showFile();
    }
    async function prevFile() {
      if (isLoadFileFinish === false) {
        console.log("loadFile\u8655\u7406\u4E2D");
        return;
      }
      if (groupType === GroupType.none || groupType === GroupType.welcome) {
        return;
      }
      flagFile -= 1;
      if (flagFile < 0) {
        flagFile = arFile.length - 1;
      }
      showFile();
    }
    function updateTitle() {
      if (isBulkView) {
        let filePath = getFilePath();
        if (filePath === void 0) {
          return;
        }
        let title = Lib.GetDirectoryName(filePath) ?? "";
        title = Lib.GetFileName(title);
        baseWindow.setTitle(title);
      } else {
        let filePath = getFilePath();
        if (filePath === void 0) {
          return;
        }
        let title = `\u300C${flagFile + 1}/${arFile.length}\u300D ${Lib.GetFileName(filePath)}`;
        baseWindow.setTitle(title);
      }
    }
    function fileToGroupType(fileInfo2) {
      let fileExt = Lib.GetFileType(fileInfo2);
      return fileExtToGroupType(fileExt);
    }
    function fileExtToGroupType(fileExt) {
      for (var type in GroupType) {
        let allowFileType = M.config.allowFileType(type);
        for (let j = 0; j < allowFileType.length; j++) {
          const fileType = allowFileType[j];
          if (fileExt == fileType["ext"]) {
            return type;
          }
        }
      }
      return GroupType.unknown;
    }
    async function filter(extraExt) {
      let ar = [];
      for (let i = 0; i < arFile.length; i++) {
        let path = arFile[i];
        let fileExt = Lib.GetExtension(path).toLocaleLowerCase();
        let allowFileType = M.config.allowFileType(groupType);
        for (let j = 0; j < allowFileType.length; j++) {
          const fileType = allowFileType[j];
          if (fileExt == "." + fileType["ext"]) {
            ar.push(path);
            break;
          }
        }
      }
      if (groupType === GroupType.pdf) {
        filterOfficeTemp(ar);
      }
      if (ar.length === 0) {
        if (extraExt !== void 0) {
          let fileExt = extraExt.toLocaleLowerCase();
          for (let i = 0; i < arFile.length; i++) {
            let path = arFile[i];
            if (fileExt == Lib.GetExtension(path).toLocaleLowerCase()) {
              ar.push(path);
            }
          }
        }
      }
      return ar;
    }
    function filterOfficeTemp(ar) {
      let arOfficeExt = [".doc", ".docx", ".ppt", ".pptx"];
      for (let i = ar.length - 1; i >= 0; i--) {
        let path = ar[i];
        let fileExt = Lib.GetExtension(path).toLocaleLowerCase();
        let fileName = Lib.GetFileName(path);
        if (arOfficeExt.indexOf(fileExt) !== -1) {
          if (fileName.substring(0, 2) === "~$") {
            ar.splice(i, 1);
          }
        }
      }
    }
    function showReloadFileMsg(changeType, fileType) {
      if (M.msgbox.isShow()) {
        return;
      }
      let path = getFilePath();
      if (path === temp_reloadFilePath) {
        return;
      }
      M.msgbox.show({
        txt: M.i18n.t("msg.reloadFile"),
        funcYes: async (dom, inputTxt) => {
          M.msgbox.close(dom);
          if (fileType === "file") {
            showFile();
          } else {
            showDir();
          }
        },
        funcClose: async (dom) => {
          M.msgbox.close(dom);
          temp_reloadFilePath = path;
        }
      });
    }
    async function showDeleteFileMsg(type, path) {
      if (groupType === GroupType.none || groupType === GroupType.welcome) {
        return;
      }
      let _type;
      if (type === "delete") {
        _type = "2";
      } else {
        _type = "1";
      }
      if (path === void 0) {
        path = getFilePath();
      }
      async function runDelete(value) {
        if (path === void 0) {
          return;
        }
        let err = "";
        if (value == "1") {
          err = await WV_File.MoveToRecycle(path);
        }
        if (value == "2") {
          err = await WV_File.Delete(path);
        }
        if (err !== "") {
          M.msgbox.show({ txt: M.i18n.t("msg.fileDeletionFailed") + "<br>" + err });
        } else {
          if (path === getFilePath() && isBulkView === false) {
            let index = arFile.indexOf(path);
            if (index !== -1) {
              arFile.splice(index, 1);
              M.mainFileList.init();
              await showFile(index);
            }
          }
          if (fileLoadType === FileLoadType.userDefined) {
            let fwd = {
              Key: "fileList",
              FullPath: path,
              OldFullPath: "",
              ChangeType: "deleted",
              FileType: "file"
            };
            baseWindow.onFileWatcher([fwd]);
          }
          if (value == "1") {
            Toast.show(M.i18n.t("msg.fileToRecycleBinCompleted"), 1e3 * 3);
          } else {
            Toast.show(M.i18n.t("msg.fileToPermanentlyDeleteCompleted"), 1e3 * 3);
          }
        }
      }
      if (M.config.settings.other.fileDeletingShowCheckMsg) {
        M.msgbox.show({
          type: "radio",
          txt: `
                        <div class="msgbox-title">${M.i18n.t("msg.deleteFile")}</div>
                        <div style="word-break:break-all;">${Lib.GetFileName(path)}</div>
                    `,
          arRadio: [
            { value: "1", name: M.i18n.t("msg.fileToRecycleBin") },
            { value: "2", name: M.i18n.t("msg.fileToPermanentlyDelete") }
          ],
          radioValue: _type,
          funcYes: async (dom, value) => {
            M.msgbox.close(dom);
            await runDelete(value);
          }
        });
      } else {
        await runDelete(_type);
      }
    }
    async function showDeleteDirMsg(type, path) {
      if (groupType === GroupType.none || groupType === GroupType.welcome) {
        return;
      }
      let _type;
      if (type === "delete") {
        _type = "2";
      } else {
        _type = "1";
      }
      if (path === void 0) {
        path = getDirPath();
      }
      async function runDelete(value) {
        if (path === void 0) {
          return;
        }
        let err = "";
        if (value == "1") {
          err = await WV_Directory.MoveToRecycle(path);
        }
        if (value == "2") {
          err = await WV_Directory.Delete(path);
        }
        if (err !== "") {
          M.msgbox.show({ txt: M.i18n.t("msg.fileDeletionFailed") + "<br>" + err });
        } else {
          if (path === getDirPath()) {
            await showDir();
          } else {
            delete arDir[path];
            arDirKey = Object.keys(arDir);
            M.mainDirList.init();
          }
          if (value == "1") {
            Toast.show(M.i18n.t("msg.fileToRecycleBinCompleted"), 1e3 * 3);
          } else {
            Toast.show(M.i18n.t("msg.fileToPermanentlyDeleteCompleted"), 1e3 * 3);
          }
        }
      }
      if (M.config.settings.other.fileDeletingShowCheckMsg) {
        M.msgbox.show({
          type: "radio",
          txt: `
                        <div class="msgbox-title">${M.i18n.t("msg.deleteDir")}</div>
                        <div style="word-break:break-all;">${Lib.GetFileName(path)}</div>
                    `,
          arRadio: [
            { value: "1", name: M.i18n.t("msg.fileToRecycleBin") },
            { value: "2", name: M.i18n.t("msg.fileToPermanentlyDelete") }
          ],
          radioValue: _type,
          funcYes: async (dom, value) => {
            M.msgbox.close(dom);
            await runDelete(value);
          }
        });
      } else {
        await runDelete(_type);
      }
    }
    async function showRenameFileMsg(path) {
      if (groupType === GroupType.none || groupType === GroupType.welcome) {
        return;
      }
      if (path === void 0) {
        path = getFilePath();
      }
      let fileName = Lib.GetFileName(path);
      let msg = M.msgbox.show({
        txt: `<div class="msgbox-title">${M.i18n.t("msg.renameFile")}</div>`,
        type: "text",
        inputTxt: fileName,
        funcYes: async (dom, inputTxt) => {
          if (path === void 0) {
            return;
          }
          if (inputTxt.trim() === "") {
            M.msgbox.show({ txt: M.i18n.t("msg.nameIsEmpty") });
            return;
          }
          if (inputTxt.search(/[\\]|[/]|[:]|[*]|[?]|["]|[<]|[>]|[|]/) !== -1) {
            M.msgbox.show({ txt: M.i18n.t("msg.nameContainsUnavailableChar") + '<br>\\ / : * ? " < > |' });
            return;
          }
          if (fileName === inputTxt) {
            M.msgbox.close(dom);
            return;
          }
          let dirPath = Lib.GetDirectoryName(path);
          if (dirPath === null) {
            M.msgbox.show({ txt: M.i18n.t("msg.renamingFailure") + M.i18n.t("msg.wrongPath") });
            return;
          }
          let newName = Lib.Combine([dirPath, inputTxt]);
          let err = await WV_File.Move(path, newName);
          if (err != "") {
            M.msgbox.show({ txt: M.i18n.t("msg.renamingFailure") + "<br>" + err });
            return;
          }
          if (path === getFilePath() && isBulkView === false) {
            arFile[flagFile] = newName;
            M.mainFileList.init();
            showFile();
          }
          if (fileLoadType === FileLoadType.userDefined) {
            let fwd = {
              Key: "fileList",
              FullPath: newName,
              OldFullPath: path,
              ChangeType: "renamed",
              FileType: "file"
            };
            baseWindow.onFileWatcher([fwd]);
          }
          M.msgbox.close(dom);
        }
      });
      const len = fileName.length - Lib.GetExtension(path).length;
      msg.domInput.setSelectionRange(0, len);
    }
    async function showRenameDirMsg(path) {
      if (groupType === GroupType.none || groupType === GroupType.welcome) {
        return;
      }
      if (path === void 0) {
        path = getDirPath();
      }
      let fileName = Lib.GetFileName(path);
      let msg = M.msgbox.show({
        txt: `<div class="msgbox-title">${M.i18n.t("msg.renameDir")}</div>`,
        type: "text",
        inputTxt: fileName,
        funcYes: async (dom, inputTxt) => {
          if (path === void 0) {
            return;
          }
          if (inputTxt.trim() === "") {
            M.msgbox.show({ txt: M.i18n.t("msg.nameIsEmpty") });
            return;
          }
          if (inputTxt.search(/[\\]|[/]|[:]|[*]|[?]|["]|[<]|[>]|[|]/) !== -1) {
            M.msgbox.show({ txt: M.i18n.t("msg.nameContainsUnavailableChar") + '<br>\\ / : * ? " < > |' });
            return;
          }
          if (fileName == inputTxt) {
            M.msgbox.close(dom);
            return;
          }
          let dirPath = Lib.GetDirectoryName(path);
          if (dirPath === null) {
            M.msgbox.show({ txt: M.i18n.t("msg.renamingFailure") + M.i18n.t("msg.wrongPath") });
            return;
          }
          let newName = Lib.Combine([dirPath, inputTxt]);
          let err = await WV_Directory.Move(path, newName);
          if (err !== "") {
            M.msgbox.show({ txt: M.i18n.t("msg.renamingFailure") + "<br>" + err });
            return;
          }
          let isReload = path === getDirPath();
          arDir = changeKey(arDir, path, newName);
          arDirKey = Object.keys(arDir);
          M.mainDirList.init();
          if (isReload) {
            let p = getFilePath();
            p = p.replace(path, newName);
            loadFile(p);
          }
          M.msgbox.close(dom);
        }
      });
      const len = fileName.length;
      msg.domInput.setSelectionRange(0, len);
    }
    function changeKey(arDir2, oldKey, newKey) {
      const keys = Object.keys(arDir2);
      const index = keys.indexOf(oldKey);
      const newArDir = {};
      for (let i = 0; i < keys.length; i++) {
        if (i === index) {
          newArDir[newKey] = arDir2[oldKey];
        } else {
          newArDir[keys[i]] = arDir2[keys[i]];
        }
      }
      return newArDir;
    }
    baseWindow.fileWatcherEvents.push((arData) => {
      arData.forEach(async (data) => {
        if (data.Key !== "dirList") {
          return;
        }
        if (data.FileType === "file") {
          return;
        }
        if (data.ChangeType === "deleted") {
          let flag = arDirKey.indexOf(data.FullPath);
          if (flag !== -1) {
            let path = arDirKey[flag];
            let p = getDirPath();
            delete arDir[path];
            arDirKey = Object.keys(arDir);
            flagDir = arDirKey.indexOf(p);
            M.mainDirList.init();
            if (data.FullPath === getDirPath()) {
              showReloadFileMsg("delete", "dir");
            }
          } else {
            return;
          }
        } else if (data.ChangeType === "renamed") {
          let flag = arDirKey.indexOf(data.OldFullPath);
          if (flag !== -1) {
            arFile[flag] = data.FullPath;
            arDir = changeKey(arDir, data.OldFullPath, data.FullPath);
            arDirKey = Object.keys(arDir);
            M.mainDirList.init();
            if (data.OldFullPath === getDirPath()) {
              if (isBulkView) {
                showReloadFileMsg("reload", "dir");
              } else {
                let p = getFilePath();
                p = p.replace(data.OldFullPath, data.FullPath);
                loadFile(p);
              }
            }
          } else {
          }
        } else if (data.ChangeType === "changed") {
        } else if (data.ChangeType === "created") {
        }
      });
    });
    baseWindow.fileWatcherEvents.push((arData) => {
      if (isBulkView) {
        return;
      }
      let isMainFileListInit = false;
      let isUpdateTitle = false;
      let isShowReloadFileMsgDelete = false;
      let isShowReloadFileMsgReload = false;
      let isShowFile = false;
      arData.forEach(async (data) => {
        if (data.Key !== "fileList") {
          return;
        }
        if (data.ChangeType === "deleted") {
          if (data.FullPath === getFilePath()) {
            isShowReloadFileMsgDelete = true;
          } else {
            let flag = arFile.indexOf(data.FullPath);
            if (flag !== -1) {
              let p = getFilePath();
              arFile.splice(flag, 1);
              flagFile = arFile.indexOf(p);
              isMainFileListInit = true;
              isUpdateTitle = true;
            } else {
              return;
            }
          }
        } else if (data.ChangeType === "renamed") {
          if (data.FileType === "dir") {
            return;
          }
          let flag = arFile.indexOf(data.OldFullPath);
          if (flag !== -1) {
            if (data.OldFullPath === getFilePath()) {
              arFile[flag] = data.FullPath;
              isUpdateTitle = true;
              isShowFile = true;
            } else {
              arFile[flag] = data.FullPath;
            }
            isMainFileListInit = true;
          } else {
            data.ChangeType = "created";
          }
        } else if (data.ChangeType === "changed") {
          if (groupType === GroupType.img && data.FullPath === getFilePath()) {
            isShowReloadFileMsgReload = true;
          } else {
            return;
          }
        }
        if (data.ChangeType === "created") {
          if (data.FileType !== "file") {
            return;
          }
          if (arFile.indexOf(data.FullPath) !== -1) {
            return;
          }
          let fileExt = Lib.GetExtension(data.FullPath).replace(".", "");
          let gt = fileExtToGroupType(fileExt);
          if (groupType === gt) {
            let isEnd = false;
            let whenInsertingFile = M.config.settings.other.whenInsertingFile;
            if (whenInsertingFile === "end") {
              isEnd = true;
            } else if (whenInsertingFile === "auto" && M.fileSort.getOrderbyType() === "asc") {
              isEnd = true;
            }
            if (isEnd) {
              arFile.push(data.FullPath);
            } else {
              let p = getFilePath();
              arFile.unshift(data.FullPath);
              flagFile = arFile.indexOf(p);
            }
            isMainFileListInit = true;
            isUpdateTitle = true;
          } else {
            return;
          }
        }
      });
      if (isMainFileListInit) {
        M.mainFileList.init();
      }
      if (isUpdateTitle) {
        updateTitle();
      }
      if (isShowReloadFileMsgDelete) {
        showReloadFileMsg("delete", "file");
      } else if (isShowReloadFileMsgReload) {
        showReloadFileMsg("reload", "file");
      } else if (isShowFile) {
        showFile();
      }
    });
    baseWindow.fileWatcherEvents.push((arData) => {
      if (isBulkView === false) {
        return;
      }
      arData.forEach(async (data) => {
        if (data.Key !== "fileList") {
          return;
        }
        if (data.ChangeType === "deleted") {
          let flag = arFile.indexOf(data.FullPath);
          if (flag !== -1) {
            arFile.splice(flag, 1);
          } else {
            return;
          }
        } else if (data.ChangeType === "renamed") {
          if (data.FileType === "dir") {
            return;
          }
          let flag = arFile.indexOf(data.OldFullPath);
          if (flag !== -1) {
            arFile[flag] = data.FullPath;
          } else {
            data.ChangeType = "created";
          }
        } else if (data.ChangeType === "changed") {
        }
        if (data.ChangeType === "created") {
          if (data.FileType !== "file") {
            return;
          }
          if (arFile.indexOf(data.FullPath) !== -1) {
            return;
          }
          let fileExt = Lib.GetExtension(data.FullPath).replace(".", "");
          let gt = fileExtToGroupType(fileExt);
          if (groupType === gt) {
            let isEnd = false;
            let whenInsertingFile = M.config.settings.other.whenInsertingFile;
            if (whenInsertingFile === "end") {
              isEnd = true;
            } else if (whenInsertingFile === "auto" && M.fileSort.getOrderbyType() === "asc") {
              isEnd = true;
            }
            if (isEnd) {
              arFile.push(data.FullPath);
            } else {
              arFile.unshift(data.FullPath);
            }
          } else {
            return;
          }
        }
        await M.bulkView.updateFileWatcher(data);
      });
    });
  }
}
var FileLoadType = /* @__PURE__ */ ((FileLoadType2) => {
  FileLoadType2[FileLoadType2["dir"] = 0] = "dir";
  FileLoadType2[FileLoadType2["userDefined"] = 1] = "userDefined";
  return FileLoadType2;
})(FileLoadType || {});
