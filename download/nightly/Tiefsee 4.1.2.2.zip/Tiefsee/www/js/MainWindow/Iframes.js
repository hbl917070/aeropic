class Iframes {
  constructor(M) {
    var monacoEditor = new MonacoEditor(M);
    var pDFTronWebviewer = new PDFTronWebviewer(M);
    var cherryMarkdown = new CherryMarkdown(M);
    var textview = new Textview(M);
    var pdfview = new Pdfview(M);
    var welcomeview = new Welcomeview(M);
    this.monacoEditor = monacoEditor;
    this.pDFTronWebviewer = pDFTronWebviewer;
    this.cherryMarkdown = cherryMarkdown;
    this.textView = textview;
    this.pdfview = pdfview;
    this.welcomeview = welcomeview;
    this.getText = getText;
    this.setTheme = setTheme;
    window.addEventListener("message", async (e) => {
      if (e.origin !== "file://") {
        console.error("\u932F\u8AA4\u7684\u8ACB\u6C42\u4F86\u6E90\uFF1A" + e.origin);
        return;
      }
      let type = e.data.type;
      let data = e.data.data;
      if (type === "getText") {
        _txt = data;
      }
      if (type === "openUrl") {
        WV_RunApp.OpenUrl(data);
      }
      if (type === "openFile") {
        let exePath = await WV_Window.GetAppPath();
        let filePath = Lib.URLToPath(data);
        if (await WV_File.Exists(filePath)) {
          WV_RunApp.ProcessStart(exePath, `"${filePath}"`, true, false);
        } else {
          M.msgbox.show({ txt: M.i18n.t("msg.notFound") + "<br>" + filePath });
        }
      }
      if (type === "loadDropFile") {
        await M.fileLoad.loadDropFile(data);
      }
      if (type === "saveText") {
        await M.script.file.save();
      }
    });
    var _txt = null;
    async function getText() {
      let groupType = M.fileShow.getGroupType();
      if (groupType === GroupType.txt) {
        _txt = textview.getText();
      } else if (groupType === GroupType.monacoEditor) {
        monacoEditor.getText();
      } else if (groupType === GroupType.md) {
        cherryMarkdown.getText();
      } else {
        return "";
      }
      for (let i = 0; i < 2e3; i++) {
        if (_txt !== null) {
          break;
        }
        await Lib.sleep(10);
      }
      let txt = _txt;
      _txt = null;
      return txt;
    }
    function setTheme() {
      let strTheme = JSON.stringify(M.config.settings.theme);
      window.localStorage.setItem("settings.theme", strTheme);
      let groupType = M.fileShow.getGroupType();
      if (groupType === GroupType.txt) {
      }
      if (groupType === GroupType.monacoEditor) {
        monacoEditor.setTheme();
      }
      if (groupType === GroupType.md) {
        cherryMarkdown.setTheme();
      }
      if (groupType === GroupType.office) {
        pDFTronWebviewer.setTheme();
      }
    }
  }
}
class PDFTronWebviewer {
  constructor(M) {
    var dom_pdftronWebviewer = document.querySelector("#mView-pdftronWebviewer");
    var isInitPDFTronWebviewer = false;
    this.visible = visible;
    this.loadFile = loadFile;
    this.loadNone = loadNone;
    this.setTheme = setTheme;
    window.addEventListener("message", (e) => {
      if (e.origin !== "file://") {
        console.error("\u932F\u8AA4\u7684\u8ACB\u6C42\u4F86\u6E90\uFF1A" + e.origin);
        return;
      }
      let type = e.data.type;
      let data = e.data.data;
      if (type === "PDFTronWebviewer.initFinish") {
        isInitPDFTronWebviewer = true;
      }
    });
    function visible(val) {
      if (val === true) {
        dom_pdftronWebviewer.style.display = "block";
      } else {
        dom_pdftronWebviewer.style.display = "none";
      }
    }
    async function loadFile(path) {
      if (dom_pdftronWebviewer.src == "") {
        let appInfoJson = encodeURIComponent(JSON.stringify(baseWindow.appInfo));
        dom_pdftronWebviewer.src = `./iframe/PDFTronWebviewer.html?appInfo=${appInfoJson}&lang=${M.script.window.getLang()}`;
      }
      for (let i = 0; i < 2e3; i++) {
        if (isInitPDFTronWebviewer === true) {
          break;
        }
        await Lib.sleep(10);
      }
      let json = {
        type: "loadFile",
        data: path
      };
      dom_pdftronWebviewer.contentWindow?.postMessage(json, "*");
    }
    function loadNone() {
      if (isInitPDFTronWebviewer === false) {
        return;
      }
      let json = {
        type: "loadNone",
        data: ""
      };
      postMsg(json);
    }
    function setTheme() {
      let json = {
        type: "setTheme",
        data: null
      };
      postMsg(json);
    }
    function postMsg(json) {
      if (isInitPDFTronWebviewer) {
        dom_pdftronWebviewer.contentWindow?.postMessage(json, "*");
      }
    }
  }
}
class MonacoEditor {
  constructor(M) {
    var dom_monacoEditor = document.querySelector("#mView-monacoEditor");
    var isInitMonacoEditor = false;
    this.visible = visible;
    this.loadFile = loadFile;
    this.loadTxt = loadTxt;
    this.loadNone = loadNone;
    this.setReadonly = setReadonly;
    this.getText = getText;
    this.setTheme = setTheme;
    window.addEventListener("message", (e) => {
      if (e.origin !== "file://") {
        console.error("\u932F\u8AA4\u7684\u8ACB\u6C42\u4F86\u6E90\uFF1A" + e.origin);
        return;
      }
      let type = e.data.type;
      let data = e.data.data;
      if (type === "MonacoEditor.initFinish") {
        isInitMonacoEditor = true;
      }
    });
    function visible(val) {
      if (val === true) {
        dom_monacoEditor.style.display = "block";
      } else {
        dom_monacoEditor.style.display = "none";
      }
    }
    async function awaitInit() {
      if (dom_monacoEditor.src == "") {
        let appInfoJson = encodeURIComponent(JSON.stringify(baseWindow.appInfo));
        dom_monacoEditor.src = `./iframe/MonacoEditor.html?appInfo=${appInfoJson}&lang=${M.script.window.getLang()}`;
      }
      for (let i = 0; i < 2e3; i++) {
        if (isInitMonacoEditor === true) {
          break;
        }
        await Lib.sleep(10);
      }
    }
    async function loadFile(txt, path) {
      await awaitInit();
      let json = {
        type: "loadFile",
        data: {
          txt,
          path
        }
      };
      postMsg(json);
    }
    async function loadTxt(text, fileType) {
      await awaitInit();
      let json = {
        type: "loadTxt",
        data: {
          txt: text,
          fileType
        }
      };
      postMsg(json);
    }
    async function setReadonly(val) {
      await awaitInit();
      let json = {
        type: "setReadonly",
        data: {
          val
        }
      };
      postMsg(json);
    }
    function loadNone() {
      let json = {
        type: "loadNone",
        data: null
      };
      postMsg(json);
    }
    function getText() {
      let json = {
        type: "getText",
        data: null
      };
      postMsg(json);
    }
    function setTheme() {
      let json = {
        type: "setTheme",
        data: null
      };
      postMsg(json);
    }
    function postMsg(json) {
      if (isInitMonacoEditor) {
        dom_monacoEditor.contentWindow?.postMessage(json, "*");
      }
    }
  }
}
class CherryMarkdown {
  constructor(M) {
    var dom_iframe = document.querySelector("#mView-cherryMarkdown");
    var isInitCherryMarkdown = false;
    this.visible = visible;
    this.loadFile = loadFile;
    this.loadTxt = loadTxt;
    this.loadNone = loadNone;
    this.setReadonly = setReadonly;
    this.getText = getText;
    this.setTheme = setTheme;
    window.addEventListener("message", (e) => {
      if (e.origin !== "file://") {
        console.error("\u932F\u8AA4\u7684\u8ACB\u6C42\u4F86\u6E90\uFF1A" + e.origin);
        return;
      }
      let type = e.data.type;
      let data = e.data.data;
      if (type === "CherryMarkdown.initFinish") {
        isInitCherryMarkdown = true;
      }
    });
    function visible(val) {
      if (val === true) {
        dom_iframe.style.display = "block";
      } else {
        dom_iframe.style.display = "none";
      }
    }
    async function awaitInit() {
      if (dom_iframe.src == "") {
        let appInfoJson = encodeURIComponent(JSON.stringify(baseWindow.appInfo));
        dom_iframe.src = `./iframe/CherryMarkdown.html?appInfo=${appInfoJson}&lang=${M.script.window.getLang()}`;
      }
      for (let i = 0; i < 2e3; i++) {
        if (isInitCherryMarkdown === true) {
          break;
        }
        await Lib.sleep(10);
      }
    }
    async function loadFile(txt, dir) {
      await awaitInit();
      let json = {
        type: "loadFile",
        data: {
          txt,
          dir
        }
      };
      postMsg(json);
    }
    async function loadTxt(txt) {
      await awaitInit();
      let json = {
        type: "loadTxt",
        data: {
          txt
        }
      };
      postMsg(json);
    }
    async function setReadonly(val) {
      await awaitInit();
      let json = {
        type: "setReadonly",
        data: {
          val
        }
      };
      postMsg(json);
    }
    function loadNone() {
      let json = {
        type: "loadNone",
        data: null
      };
      postMsg(json);
    }
    function getText() {
      let json = {
        type: "getText",
        data: null
      };
      postMsg(json);
    }
    function setTheme() {
      let json = {
        type: "setTheme",
        data: null
      };
      postMsg(json);
    }
    function postMsg(json) {
      if (isInitCherryMarkdown) {
        dom_iframe.contentWindow?.postMessage(json, "*");
      }
    }
  }
}
class Textview {
  constructor(M) {
    var dom_text = document.querySelector("#mView-txt");
    this.visible = visible;
    this.loadTxt = loadText;
    this.loadNone = loadNone;
    this.setReadonly = setReadonly;
    this.getText = getText;
    dom_text.addEventListener("keydown", (e) => {
      if (isReadonly === false) {
        return;
      }
      if (e.code == "KeyC" && e.ctrlKey === true) {
      } else if (e.code == "KeyA" && e.ctrlKey === true) {
      } else {
        e.preventDefault();
      }
    });
    function visible(val) {
      if (val === true) {
        dom_text.style.display = "block";
      } else {
        dom_text.style.display = "none";
      }
    }
    async function loadText(text) {
      dom_text.scrollTo(0, 0);
      dom_text.value = text;
    }
    var isReadonly = false;
    async function setReadonly(val) {
      isReadonly = val;
      if (val) {
        dom_text.setAttribute("readonly", "readonly");
      } else {
        dom_text.removeAttribute("readonly");
      }
    }
    function loadNone() {
      loadText("");
    }
    function getText() {
      return dom_text.value;
    }
  }
}
class Pdfview {
  constructor(M) {
    var dom_iframe = document.querySelector("#mView-pdf");
    this.visible = visible;
    this.loadFile = loadFile;
    this.loadNone = loadNone;
    function visible(val) {
      if (val === true) {
        dom_iframe.style.display = "block";
      } else {
        dom_iframe.style.display = "none";
      }
    }
    async function loadFile(fileInfo2) {
      let _url = WebAPI.getPdf(fileInfo2);
      dom_iframe.setAttribute("src", _url);
    }
    function loadNone() {
      dom_iframe.setAttribute("src", "");
    }
  }
}
class Welcomeview {
  constructor(M) {
    var dom_welcomeview = document.querySelector("#mView-welcome");
    this.visible = visible;
    this.dom = dom_welcomeview;
    function visible(val) {
      if (val === true) {
        dom_welcomeview.style.display = "flex";
      } else {
        dom_welcomeview.style.display = "none";
      }
    }
  }
}
