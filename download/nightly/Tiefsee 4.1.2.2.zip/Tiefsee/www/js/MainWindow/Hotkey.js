class Hotkey {
  constructor(M) {
    window.addEventListener("keydown", async (e) => {
      if (e.code == "F5") {
        return;
      }
      if (e.code == "F12") {
        return;
      }
      if (M.menu.getIsShow()) {
        if (e.code == "Escape") {
          M.menu.close();
          return;
        }
        if (Lib.isTextFocused()) {
          return;
        }
      }
      if (M.msgbox.isShow()) {
        if (e.code == "Escape") {
          M.msgbox.closeNow();
          e.preventDefault();
        }
        if (e.code == "Enter" || e.code == "NumpadEnter") {
          M.msgbox.clickYes();
          e.preventDefault();
        }
        return;
      }
      if (M.toolbarBack.getVisible()) {
        if (e.code == "Escape" || e.code == "Backspace") {
          M.toolbarBack.runEvent();
          e.preventDefault();
          return;
        }
      }
      if (M.fullScreen.getEnabled()) {
        if (e.code == "Escape") {
          M.fullScreen.setEnabled(false);
          e.preventDefault();
          return;
        }
      }
      if (e.code === "F11") {
        M.fullScreen.setEnabled();
        return;
      }
      if (M.fileLoad.getIsBulkView()) {
        if (e.key === "Alt") {
          e.preventDefault();
        }
        M.bulkView.setFocus();
        if (e.code === "ArrowRight") {
          M.script.bulkView.pageNext();
        }
        if (e.code === "ArrowLeft") {
          M.script.bulkView.pagePrev();
        }
        if (e.code === "Comma") {
          M.script.fileLoad.prevDir();
        }
        if (e.code === "Period") {
          M.script.fileLoad.nextDir();
        }
        if (e.code == "Escape") {
          M.script.bulkView.close();
        }
        if (e.code === "F2") {
          M.script.fileLoad.showRenameMsg();
        }
        if (e.code === "KeyO") {
          M.script.open.revealInFileExplorer();
        }
        if (e.code === "KeyM") {
          M.script.open.systemContextMenu();
        }
        if (e.code === "Space" && M.getIsQuickLook()) {
          e.preventDefault();
        }
        for (let i = 1; i <= 8; i++) {
          if (e.key == i.toString()) {
            M.script.bulkView.setColumns(i);
          }
        }
        return;
      }
      if (M.fileShow.getGroupType() == GroupType.txt) {
        if (Lib.isTextFocused()) {
          if (e.code === "KeyS" && e.ctrlKey) {
            M.script.file.save();
          }
          return;
        }
      }
      let allow = e.code === "KeyC" && e.ctrlKey || e.code === "KeyD" && e.ctrlKey;
      if (allow === false) {
        e.preventDefault();
      }
      if (e.code === "KeyC" && e.ctrlKey) {
        if (Lib.isTxtSelect() === false) {
          M.script.copy.copyImage();
        }
      }
      if (e.code === "ArrowRight") {
        M.script.fileLoad.nextFile();
      }
      if (e.code === "ArrowLeft") {
        M.script.fileLoad.prevFile();
      }
      if (e.code === "ArrowUp") {
        M.script.img.move("up");
      }
      if (e.code === "ArrowDown") {
        M.script.img.move("down");
      }
      if (e.code === "Escape") {
        baseWindow.close();
      }
      if (e.code === "KeyR") {
        M.script.img.degForward();
      }
      if (e.code === "KeyF") {
        M.script.img.zoomToFit();
      }
      if (e.code === "KeyH") {
        M.script.img.mirrorHorizontal();
      }
      if (e.code === "KeyV") {
        M.script.img.mirrorVertica();
      }
      if (e.code === "ShiftRight") {
        M.script.img.zoomIn();
      }
      if (e.code === "ControlRight") {
        M.script.img.zoomOut();
      }
      if (e.code === "F2") {
        M.script.fileLoad.showRenameMsg();
      }
      if (e.code === "Delete") {
        M.script.fileLoad.showDeleteFileMsg();
      }
      if (e.code === "KeyO") {
        M.script.open.revealInFileExplorer();
      }
      if (e.code === "KeyM") {
        M.script.open.systemContextMenu();
      }
      if (e.code === "Comma") {
        M.script.fileLoad.prevDir();
      }
      if (e.code === "Period") {
        M.script.fileLoad.nextDir();
      }
      if (e.code === "Home") {
        M.script.fileLoad.firstFile();
      }
      if (e.code === "End") {
        M.script.fileLoad.lastFile();
      }
      if (e.code === "KeyB") {
        M.script.bulkView.show();
      }
    });
  }
}
