class Script {
  constructor(M) {
    this.M = M;
    this.img = new ScriptImg(M);
    this.fileLoad = new ScriptFileLoad(M);
    this.fileShow = new ScriptFileShow(M);
    this.file = new ScriptFile(M);
    this.menu = new ScriptMenu(M);
    this.open = new ScriptOpen(M);
    this.copy = new ScriptCopy(M);
    this.setting = new ScriptSetting(M);
    this.window = new ScriptWindow(M);
    this.bulkView = new ScriptBulkView(M);
  }
  async run(s, option) {
    if (option === void 0) {
      option = {};
    }
    if (s === "imageFitWindowOrImageOriginal") {
      this.img.fitWindowOrImageOriginal();
    } else if (s === "imageFitWindow") {
      this.img.zoomToFit();
    } else if (s === "imageOriginal") {
      this.img.zoomTo100(option.x, option.y);
    } else if (s === "imageZoomIn") {
      this.img.zoomIn(option.x, option.y);
    } else if (s === "imageZoomOut") {
      this.img.zoomOut(option.x, option.y);
    } else if (s === "imageRotateCw") {
      this.img.degForward(option.x, option.y);
    } else if (s === "imageRotateCcw") {
      this.img.degReverse(option.x, option.y);
    } else if (s === "imageFlipHorizontal") {
      this.img.mirrorHorizontal(option.x, option.y);
    } else if (s === "imageFlipVertical") {
      this.img.mirrorVertica(option.x, option.y);
    } else if (s === "imageInitialRotation") {
      this.img.transformRefresh();
    } else if (s === "imageMoveUp") {
      this.img.move("up");
    } else if (s === "imageMoveDown") {
      this.img.move("down");
    } else if (s === "imageMoveLeft") {
      this.img.move("left");
    } else if (s === "imageMoveRight") {
      this.img.move("right");
    } else if (s === "imageMoveUpOrPrevFile") {
      if (this.M.fileShow.tiefseeview.getIsOverflowY()) {
        this.img.move("up");
      } else {
        this.fileLoad.prevFile();
      }
    } else if (s === "imageMoveDownOrNextFile") {
      if (this.M.fileShow.tiefseeview.getIsOverflowY()) {
        this.img.move("down");
      } else {
        this.fileLoad.nextFile();
      }
    } else if (s === "imageMoveLeftOrPrevFile") {
      if (this.M.fileShow.tiefseeview.getIsOverflowX()) {
        this.img.move("left");
      } else {
        this.fileLoad.prevFile();
      }
    } else if (s === "imageMoveLeftOrNextFile") {
      if (this.M.fileShow.tiefseeview.getIsOverflowX()) {
        this.img.move("left");
      } else {
        this.fileLoad.nextFile();
      }
    } else if (s === "imageMoveRightOrPrevFile") {
      if (this.M.fileShow.tiefseeview.getIsOverflowX()) {
        this.img.move("right");
      } else {
        this.fileLoad.prevFile();
      }
    } else if (s === "imageMoveRightOrNextFile") {
      if (this.M.fileShow.tiefseeview.getIsOverflowX()) {
        this.img.move("right");
      } else {
        this.fileLoad.nextFile();
      }
    } else if (s === "newWindow") {
      await this.open.openNewWindow();
    } else if (s === "prevFile") {
      this.fileLoad.prevFile();
    } else if (s === "nextFile") {
      this.fileLoad.nextFile();
    } else if (s === "prevDir") {
      this.fileLoad.prevDir();
    } else if (s === "nextDir") {
      this.fileLoad.nextDir();
    } else if (s === "firstFile") {
      this.fileLoad.firstFile();
    } else if (s === "lastFile") {
      this.fileLoad.lastFile();
    } else if (s === "firstDir") {
      this.fileLoad.firstDir();
    } else if (s === "lastDir") {
      this.fileLoad.lastDir();
    } else if (s === "revealInFileExplorer") {
      this.open.revealInFileExplorer();
    } else if (s === "systemContextMenu") {
      this.open.systemContextMenu();
    } else if (s === "renameFile") {
      this.fileLoad.showRenameMsg();
    } else if (s === "openWith") {
      this.open.openWith();
    } else if (s === "fileToRecycleBin") {
      this.fileLoad.showDeleteMsg("moveToRecycle");
    } else if (s === "fileToPermanentlyDelete") {
      this.fileLoad.showDeleteMsg("delete");
    } else if (s === "copyFile") {
      this.copy.copyFile();
    } else if (s === "copyFileName") {
      this.copy.copyName();
    } else if (s === "copyFilePath") {
      this.copy.copyPath();
    } else if (s === "copyImage") {
      this.copy.copyImage();
    } else if (s === "copyImageBase64") {
      this.copy.copyImageBase64();
    } else if (s === "copyText") {
      this.copy.copyText();
    } else if (s === "maximizeWindow") {
      this.window.maximizeWindow();
    } else if (s === "topmost") {
      this.window.enabledTopmost();
    } else if (s === "fullScreen") {
      this.window.enabledFullScreen();
    } else if (s === "showToolbar") {
      this.window.enabledMainToolbar();
    } else if (s === "showFilePanel") {
      this.window.enabledMainFileList();
    } else if (s === "showDirectoryPanel") {
      this.window.enabledMainDirList();
    } else if (s === "showInformationPanel") {
      this.window.enabledMainExif();
    } else if (s === "prevPage") {
      this.M.bulkView.pagePrev();
    } else if (s === "nextPage") {
      this.M.bulkView.pageNext();
    } else if (s === "incrColumns") {
      this.M.bulkView.incrColumns();
    } else if (s === "decColumns") {
      this.M.bulkView.decColumns();
    } else if (s === "incrFixedWidth") {
      this.M.bulkView.incrFixedWidth();
    } else if (s === "decFixedWidth") {
      this.M.bulkView.decFixedWidth();
    }
  }
}
class ScriptImg {
  constructor(_M) {
    this.M = _M;
  }
  isImg() {
    if (this.M.fileLoad.getGroupType() === GroupType.img) {
      return true;
    }
    if (this.M.fileLoad.getGroupType() === GroupType.imgs) {
      return true;
    }
    if (this.M.fileLoad.getGroupType() === GroupType.video) {
      return true;
    }
    if (this.M.fileLoad.getGroupType() === GroupType.unknown) {
      return true;
    }
    return false;
  }
  zoomToFit() {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.zoomFull(TiefseeviewZoomType["fitWindow"]);
  }
  zoomTo100(x, y) {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.zoomFull(TiefseeviewZoomType["imageOriginal"], void 0, x, y);
  }
  fitWindowOrImageOriginal() {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.zoomFull(TiefseeviewZoomType["fitWindowOrImageOriginal"]);
  }
  degForward(x, y) {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.setDegForward(x, y);
  }
  degReverse(x, y) {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.setDegReverse(x, y);
  }
  mirrorHorizontal(x, y) {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.setMirrorHorizontal(!this.M.fileShow.tiefseeview.getMirrorHorizontal(), x, y);
  }
  mirrorVertica(x, y) {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.setMirrorVertica(!this.M.fileShow.tiefseeview.getMirrorVertica(), x, y);
  }
  transformRefresh() {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.transformRefresh(true);
  }
  zoomIn(x, y) {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.zoomIn(x, y);
  }
  zoomOut(x, y) {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.zoomOut(x, y);
  }
  move(type, distance) {
    if (this.isImg() === false) {
      return;
    }
    this.M.fileShow.tiefseeview.move(type, distance);
  }
  async getImgData(fileInfo2) {
    let fileTime = `LastWriteTimeUtc=${fileInfo2.LastWriteTimeUtc}`;
    let fileType = Lib.GetFileType(fileInfo2);
    let configItem = this.M.config.getAllowFileTypeItem(GroupType.img, fileType);
    if (configItem === null) {
      configItem = { ext: "", type: "vips", vipsType: "magick" };
    }
    let configType = configItem.type;
    let vipsType = configItem.vipsType;
    let arUrl = [];
    let width = -1;
    let height = -1;
    let isAnimation = Lib.IsAnimation(fileInfo2);
    if (isAnimation) {
      let imgInitInfo = await WebAPI.Img.webInit(fileInfo2);
      if (imgInitInfo.code == "1") {
        width = imgInitInfo.width;
        height = imgInitInfo.height;
        arUrl.push({ scale: 1, url: imgInitInfo.path });
      }
    } else if (configType === "vips") {
      let imgInitInfo = await WebAPI.Img.vipsInit(vipsType, fileInfo2);
      if (imgInitInfo.code == "1") {
        width = imgInitInfo.width;
        height = imgInitInfo.height;
        let ratio = Number(this.M.config.settings.image.tiefseeviewBigimgscaleRatio);
        if (isNaN(ratio)) {
          ratio = 0.8;
        }
        if (ratio > 0.95) {
          ratio = 0.95;
        }
        if (ratio < 0.5) {
          ratio = 0.5;
        }
        arUrl.push({ scale: 1, url: Lib.pathToURL(imgInitInfo.path) + `?${fileTime}` });
        for (let i = 1; i <= 30; i++) {
          let scale = Number(Math.pow(ratio, i).toFixed(3));
          if (imgInitInfo.width * scale < 200 || imgInitInfo.height * scale < 200) {
            break;
          }
          let imgU = WebAPI.Img.vipsResize(scale, fileInfo2);
          arUrl.push({ scale, url: imgU });
        }
      }
    } else {
      let url = await WebAPI.Img.getUrl(configType, fileInfo2);
      let imgInitInfo = await WebAPI.Img.webInit(url);
      if (imgInitInfo.code == "1") {
        width = imgInitInfo.width;
        height = imgInitInfo.height;
        arUrl.push({ scale: 1, url: imgInitInfo.path });
      }
    }
    if (width === -1) {
      let url = await WebAPI.Img.getUrl("icon", fileInfo2);
      width = 256;
      height = 256;
      arUrl.push({ scale: 1, url });
    }
    return {
      fileType,
      isAnimation,
      width,
      height,
      configItem,
      arUrl
    };
  }
  async preloadImg(_url) {
    let img = document.createElement("img");
    let p = await new Promise((resolve, reject) => {
      img.addEventListener("load", (e) => {
        resolve(true);
      });
      img.addEventListener("error", (e) => {
        resolve(false);
      });
      img.src = _url;
    });
    img.src = "";
    img = null;
    return p;
  }
  urlToCanvas(url) {
    let domImg = document.createElement("img");
    domImg.src = url;
    let domCan = document.createElement("canvas");
    domCan.width = domImg.width;
    domCan.height = domImg.height;
    let context0 = domCan.getContext("2d");
    context0?.drawImage(domImg, 0, 0, domImg.width, domImg.height);
    return domCan;
  }
  getCanvasZoom(img, zoom, quality) {
    let width = Math.floor(img.width * zoom);
    let height = Math.floor(img.height * zoom);
    let cs = document.createElement("canvas");
    cs.width = width;
    cs.height = height;
    let context0 = cs.getContext("2d");
    context0.imageSmoothingQuality = quality;
    context0.drawImage(img, 0, 0, width, height);
    return cs;
  }
  async getCanvasBlob(can, zoom, quality, type = "png", q = 0.8) {
    if (can === null) {
      return null;
    }
    if (zoom < 1) {
      can = this.getCanvasZoom(can, zoom, quality);
    }
    let blob = null;
    await new Promise((resolve, reject) => {
      if (can === null) {
        return null;
      }
      let outputType = "image/png";
      if (type === "webp") {
        outputType = "image/webp";
      }
      if (type === "jpg" || type === "jpeg") {
        outputType = "image/jpeg";
        let cc = document.createElement("canvas");
        cc.width = can.width;
        cc.height = can.height;
        let context = cc.getContext("2d");
        context.fillStyle = "#FFFFFF";
        context.fillRect(0, 0, can.width, can.height);
        context.drawImage(can, 0, 0, can.width, can.height);
        can = cc;
      }
      can.toBlob((b) => {
        blob = b;
        resolve(true);
      }, outputType, q);
    });
    return blob;
  }
  async blobToBase64(blob) {
    return new Promise((resolve, _) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.readAsDataURL(blob);
    });
  }
}
class ScriptFileLoad {
  constructor(_M) {
    this.M = _M;
  }
  firstFile() {
    this.M.fileLoad.showFile(0);
  }
  lastFile() {
    this.M.fileLoad.showFile(this.M.fileLoad.getWaitingFile().length - 1);
  }
  prevFile() {
    this.M.fileLoad.prevFile();
  }
  nextFile() {
    this.M.fileLoad.nextFile();
  }
  prevDir() {
    this.M.fileLoad.prevDir();
  }
  nextDir() {
    this.M.fileLoad.nextDir();
  }
  firstDir() {
    this.M.fileLoad.showDir(0);
  }
  lastDir() {
    this.M.fileLoad.showDir(this.M.fileLoad.getWaitingDirKey().length - 1);
  }
  showDeleteMsg(type) {
    if (this.M.fileLoad.getIsBulkView()) {
      this.showDeleteDirMsg(type);
    } else {
      this.showDeleteFileMsg(type);
    }
  }
  showDeleteFileMsg(type, path) {
    this.M.fileLoad.showDeleteFileMsg(type, path);
  }
  showDeleteDirMsg(type, path) {
    this.M.fileLoad.showDeleteDirMsg(type, path);
  }
  async showRenameMsg(path) {
    if (path === void 0) {
      if (this.M.fileLoad.getIsBulkView()) {
        this.showRenameDirMsg(path);
      } else {
        this.showRenameFileMsg(path);
      }
    } else {
      if (await WV_Directory.Exists(path)) {
        this.showRenameDirMsg(path);
      }
      if (await WV_File.Exists(path)) {
        this.showRenameFileMsg(path);
      }
    }
  }
  showRenameFileMsg(path) {
    this.M.fileLoad.showRenameFileMsg(path);
  }
  showRenameDirMsg(path) {
    this.M.fileLoad.showRenameDirMsg(path);
  }
  reloadFilePanel() {
    this.M.fileLoad.reloadFilePanel();
  }
  reloadDirPanel() {
    this.M.fileLoad.reloadDirPanel();
  }
}
class ScriptFileShow {
  constructor(_M) {
    this.M = _M;
  }
}
class ScriptFile {
  constructor(_M) {
    this.M = _M;
  }
  dragDropFile(path) {
    setTimeout(async () => {
      if (path === void 0) {
        if (this.M.fileLoad.getIsBulkView()) {
          path = this.M.fileLoad.getDirPath();
        } else {
          path = this.M.fileLoad.getFilePath();
        }
      }
      if (path.length > 255) {
        path = await WV_Path.GetShortPath(path);
      }
      WV_File.DragDropFile(path);
    }, 50);
  }
  async showContextMenu(path) {
    if (path === void 0) {
      if (this.M.fileLoad.getIsBulkView()) {
        path = this.M.fileLoad.getDirPath();
      } else {
        path = this.M.fileLoad.getFilePath();
      }
    }
    WV_File.ShowContextMenu(path, true);
  }
  async save(btn) {
    let t = await this.M.fileShow.iframes.getText();
    let path = this.M.fileLoad.getFilePath();
    this.M.msgbox.closeAll();
    if (t == null) {
      Toast.show(this.M.i18n.t("msg.saveFailed"), 1e3 * 3);
      return;
    }
    try {
      await WV_File.SetText(path, t);
      Toast.show(this.M.i18n.t("msg.saveComplete"), 1e3 * 3);
    } catch (e) {
      Toast.show(this.M.i18n.t("msg.saveFailed") + ":\n" + e, 1e3 * 3);
    }
  }
}
class ScriptMenu {
  constructor(_M) {
    this.M = _M;
  }
  close() {
    this.M.menu.close();
  }
  showMenuFile(btn, path, type) {
    let domMenu = document.getElementById("menu-file");
    let domOpenFileBox = domMenu.querySelector(".js-openFileBox");
    if (path !== void 0) {
      domMenu.setAttribute("data-path", path);
      domOpenFileBox.style.display = "none";
      if (type === "dir") {
        domMenu.setAttribute("showType", GroupType.bulkView);
      } else {
        let fileExt = Lib.GetExtension(path).replace(".", "");
        let showType = this.M.fileLoad.fileExtToGroupType(fileExt);
        domMenu.setAttribute("showType", showType);
      }
    } else {
      domMenu.setAttribute("data-path", "");
      domMenu.setAttribute("showType", "");
      domOpenFileBox.style.display = "";
    }
    if (btn === void 0) {
      this.M.menu.openAtOrigin(domMenu, 0, 0);
    } else {
      this.M.menu.openAtButton(domMenu, btn, "menuActive");
    }
  }
  showMenuCopy(btn, path, type) {
    let domMenu = document.getElementById("menu-copy");
    let domMenuCopyText = domMenu.querySelector(".js-copyText");
    let showType = "";
    let fileExt = "";
    if (path !== void 0) {
      domMenu.setAttribute("data-path", path);
      if (type === "dir") {
        domMenu.setAttribute("showType", GroupType.bulkView);
      } else {
        fileExt = Lib.GetExtension(path).replace(".", "");
        showType = this.M.fileLoad.fileExtToGroupType(fileExt);
        domMenu.setAttribute("showType", showType);
      }
    } else {
      fileExt = Lib.GetExtension(this.M.fileLoad.getFilePath()).replace(".", "");
      showType = this.M.fileLoad.fileExtToGroupType(fileExt);
      domMenu.setAttribute("showType", "");
      domMenu.setAttribute("data-path", "");
    }
    if (fileExt === "svg" || showType === GroupType.txt) {
      domMenuCopyText.style.display = "";
    } else {
      domMenuCopyText.style.display = "none";
    }
    if (btn === void 0) {
      this.M.menu.openAtOrigin(domMenu, 0, 0);
    } else {
      this.M.menu.openAtButton(domMenu, btn, "menuActive");
    }
  }
  showLayout(btn) {
    this.M.mainMenu.updateMenuLayoutCheckState();
    let dom = document.getElementById("menu-layout");
    if (btn === void 0) {
      this.M.menu.openAtOrigin(dom, 0, 0);
    } else {
      this.M.menu.openAtButton(dom, btn, "menuActive");
    }
  }
  showMenuRotation(btn) {
    if (btn === void 0) {
      this.M.menu.openAtOrigin(document.getElementById("menu-rotate"), 0, 0);
    } else {
      this.M.menu.openAtButton(document.getElementById("menu-rotate"), btn, "menuActive");
    }
  }
  showMenuImageSearch(btn, path) {
    let domMenu = document.getElementById("menu-imgSearch");
    if (path !== void 0) {
      domMenu.setAttribute("data-path", path);
    } else {
      domMenu.setAttribute("data-path", "");
    }
    if (btn === void 0) {
      this.M.menu.openAtOrigin(domMenu, 0, 0);
    } else {
      this.M.menu.openAtButton(domMenu, btn, "menuActive");
    }
  }
  showMenuSort(btn, type) {
    let domMenu = document.querySelector("#menu-sort");
    let domMenuFilebox = domMenu.querySelector(".js-filebox");
    let domMenuDirbox = domMenu.querySelector(".js-dirbox");
    if (type === "file") {
      domMenuFilebox.style.display = "";
      domMenuDirbox.style.display = "none";
    } else if (type === "dir") {
      domMenuFilebox.style.display = "none";
      domMenuDirbox.style.display = "";
    } else {
      domMenuFilebox.style.display = "";
      domMenuDirbox.style.display = "";
    }
    if (btn === void 0) {
      this.M.menu.openAtOrigin(domMenu, 0, 0);
    } else {
      this.M.menu.openAtButton(domMenu, btn, "menuActive");
    }
  }
  showMenuBulkView(btn) {
    if (btn === void 0) {
      this.M.menu.openAtOrigin(document.getElementById("menu-bulkView"), 0, 0);
    } else {
      this.M.menu.openAtButton(document.getElementById("menu-bulkView"), btn, "menuActive");
    }
  }
  showRightMenuImage(x, y) {
    let dom = document.getElementById("menu-rightMenuImage");
    if (x !== void 0 && y !== void 0) {
      this.M.menu.openAtPoint(dom, x, y);
    } else {
      this.M.menu.openAtMouse(dom, 0, -85);
    }
    this.M.mainMenu.updateRightMenuImageZoomRatioTxt();
  }
  showRightMenuWelcome(x, y) {
    let dom = document.getElementById("menu-rightMenuWelcome");
    if (x !== void 0 && y !== void 0) {
      this.M.menu.openAtPoint(dom, x, y);
    } else {
      this.M.menu.openAtMouse(dom, 0, 0);
    }
  }
  showRightMenuBulkView(e, x, y) {
    let dom = e.target;
    let path = null;
    if (dom !== null) {
      while (true) {
        if (dom.classList.contains("bulkView-item")) {
          path = dom.getAttribute("data-path");
          break;
        }
        if (dom === document.body) {
          break;
        }
        dom = dom.parentNode;
      }
    }
    let domMenu = document.querySelector("#menu-rightMenuBulkView");
    let domFileBox = document.querySelector("#menu-fileBox");
    let domFileName = domFileBox.querySelector(".js-fileName");
    if (path !== null) {
      domFileBox.style.display = "";
      domMenu.appendChild(domFileBox);
      domFileBox.setAttribute("data-path", path);
      domFileName.value = Lib.GetFileName(path);
    } else {
      domFileBox.style.display = "none";
    }
    if (x !== void 0 && y !== void 0) {
      this.M.menu.openAtPoint(domMenu, x, y);
    } else {
      this.M.menu.openAtMouse(domMenu, 0, 0);
    }
  }
  showRightMenuFilePanel(e) {
    let dom = e.target;
    let path = null;
    while (true) {
      if (dom.classList.contains("fileList-item")) {
        path = dom.getAttribute("data-path");
        break;
      }
      if (dom === document.body) {
        break;
      }
      dom = dom.parentNode;
    }
    let domMenu = document.querySelector("#menu-rightMenuFilePanel");
    let domFileBox = document.querySelector("#menu-fileBox");
    let domFileName = domFileBox.querySelector(".js-fileName");
    if (path !== null) {
      domFileBox.style.display = "";
      domMenu.appendChild(domFileBox);
      domFileBox.setAttribute("data-path", path);
      domFileName.value = Lib.GetFileName(path);
    } else {
      domFileBox.style.display = "none";
    }
    this.M.menu.openAtMouse(domMenu, 0, 0);
  }
  showRightMenuDirPanel(e) {
    let dom = e.target;
    let path = null;
    while (true) {
      if (dom.classList.contains("dirList-item")) {
        path = dom.getAttribute("data-path");
        break;
      }
      if (dom === document.body) {
        break;
      }
      dom = dom.parentNode;
    }
    let domMenu = document.querySelector("#menu-rightMenuDirPanel");
    let domFileBox = document.querySelector("#menu-dirBox");
    let domFileName = domFileBox.querySelector(".js-fileName");
    if (path !== null) {
      domFileBox.style.display = "";
      domMenu.appendChild(domFileBox);
      domFileBox.setAttribute("data-path", path);
      domFileName.value = Lib.GetFileName(path);
    } else {
      domFileBox.style.display = "none";
    }
    this.M.menu.openAtMouse(domMenu, 0, 0);
  }
  showRightMenuDefault() {
    let dom = document.getElementById("menu-rightMenuDefault");
    this.M.menu.openAtMouse(dom, 0, -55);
  }
  showRightMenuTextbox(x, y) {
    let domInput = document.activeElement;
    if (domInput === null) {
      return false;
    }
    let isReadonly = domInput.getAttribute("readonly") != null;
    var dom_cut = document.getElementById("menuitem-text-cut");
    var dom_paste = document.getElementById("menuitem-text-paste");
    if (isReadonly) {
      dom_cut.style.display = "none";
      dom_paste.style.display = "none";
    } else {
      dom_cut.style.display = "flex";
      dom_paste.style.display = "flex";
    }
    var dom = document.getElementById("menu-text");
    if (x !== void 0 && y !== void 0) {
      this.M.menu.openAtPoint(dom, x, y);
    } else {
      this.M.menu.openAtMouse(dom, 0, 0);
    }
  }
  showRightMenuTxt(x, y) {
    var dom = document.getElementById("menu-txt");
    if (x !== void 0 && y !== void 0) {
      this.M.menu.openAtPoint(dom, x, y);
    } else {
      this.M.menu.openAtMouse(dom, 0, 0);
    }
  }
}
class ScriptOpen {
  constructor(_M) {
    this.M = _M;
  }
  async openFile() {
    let arFile = await WV_File.OpenFileDialog(true, "All files (*.*)|*.*", this.M.i18n.get("menu.openFile"));
    if (arFile.length === 0) {
      return;
    }
    if (arFile.length === 1) {
      this.M.fileLoad.loadFile(arFile[0]);
    }
    if (arFile.length > 1) {
      let arName = [];
      for (let i = 0; i < arFile.length; i++) {
        arName.push(Lib.GetFileName(arFile[i]));
      }
      let dirPath = Lib.GetDirectoryName(arFile[0]);
      if (dirPath == null) {
        return;
      }
      this.M.fileLoad.loadFiles(dirPath, arName);
    }
  }
  async openNewWindow(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getFilePath();
    }
    let exePath = await WV_Window.GetAppPath();
    await this.M.saveSetting();
    WV_RunApp.ProcessStart(exePath, `"${path}"`, true, false);
  }
  async revealInFileExplorer(path) {
    if (path === void 0) {
      if (this.M.fileLoad.getIsBulkView()) {
        path = this.M.fileLoad.getDirPath();
        if (await WV_Directory.Exists(path) === false) {
          return;
        }
      } else {
        path = this.M.fileLoad.getFilePath();
        if (await WV_File.Exists(path) === false) {
          return;
        }
      }
    }
    if (path.length > 255) {
      path = await WV_Path.GetShortPath(path);
    }
    WV_File.ShowOnExplorer(path);
  }
  async systemContextMenu(path) {
    if (path === void 0) {
      if (this.M.fileLoad.getIsBulkView()) {
        path = this.M.fileLoad.getDirPath();
        if (await WV_Directory.Exists(path) === false) {
          return;
        }
      } else {
        path = this.M.fileLoad.getFilePath();
        if (await WV_File.Exists(path) === false) {
          return;
        }
      }
    }
    if (path.length > 255) {
      path = await WV_Path.GetShortPath(path);
    }
    WV_File.ShowContextMenu(path, true);
  }
  async print(path) {
    if (path === void 0) {
      path = await this.M.fileLoad.getFileShortPath();
    }
    WV_File.PrintFile(path);
  }
  async setAsDesktop(path) {
    if (path === void 0) {
      path = await this.M.fileLoad.getFileShortPath();
    }
    if (await WV_File.Exists(path) === false) {
      return;
    }
    WV_System.SetWallpaper(path);
  }
  async openWith(path) {
    if (path === void 0) {
      path = await this.M.fileLoad.getFileShortPath();
    }
    if (await WV_File.Exists(path) === false) {
      return;
    }
    WV_RunApp.ShowMenu(path);
  }
}
class ScriptCopy {
  constructor(_M) {
    this.M = _M;
  }
  async copyFile(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getFilePath();
    }
    if (await WV_File.Exists(path) === false) {
      return;
    }
    await WV_System.SetClipboard_File(path);
    Toast.show(this.M.i18n.t("msg.copyFile"), 1e3 * 3);
  }
  async copyName(path) {
    if (this.M.fileLoad.getIsBulkView()) {
      await this.copyDirName(path);
    } else {
      await this.copyFileName(path);
    }
  }
  async copyFileName(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getFilePath();
    }
    let name = Lib.GetFileName(path);
    await WV_System.SetClipboard_Txt(name);
    Toast.show(this.M.i18n.t("msg.copyFileName"), 1e3 * 3);
  }
  async copyDirName(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getDirPath();
    }
    let name = Lib.GetFileName(path);
    await WV_System.SetClipboard_Txt(name);
    Toast.show(this.M.i18n.t("msg.copyDirName"), 1e3 * 3);
  }
  async copyPath(path) {
    if (this.M.fileLoad.getIsBulkView()) {
      await this.copyFilePath(path);
    } else {
      await this.copyDirPath(path);
    }
  }
  async copyFilePath(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getFilePath();
    }
    await WV_System.SetClipboard_Txt(path);
    Toast.show(this.M.i18n.t("msg.copyFilePath"), 1e3 * 3);
  }
  async copyDirPath(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getDirPath();
    }
    await WV_System.SetClipboard_Txt(path);
    Toast.show(this.M.i18n.t("msg.copyDirPath"), 1e3 * 3);
  }
  async copyImage(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getFilePath();
    }
    let fileInfo2 = await WebAPI.getFileInfo2(path);
    if (fileInfo2.Type === "none") {
      return;
    }
    let imgType = Lib.GetFileType(fileInfo2);
    if (this.M.fileLoad.getIsBulkView() === false && this.M.fileLoad.getFilePath() === path && this.M.fileLoad.getGroupType() === GroupType.video) {
      let base64 = await this.M.fileShow.tiefseeview.getCanvasBase64(1, "medium");
      await WV_System.SetClipboard_Base64ToImage(base64, false);
    } else if (imgType === "jpg") {
      await WV_System.SetClipboard_FileToImage(path, false);
    } else if (imgType === "png" || imgType === "gif" || imgType === "bmp") {
      await WV_System.SetClipboard_FileToImage(path, true);
    } else {
      let imgData = await this.M.script.img.getImgData(fileInfo2);
      let imtUrl = imgData.arUrl[0].url;
      let p = await this.M.script.img.preloadImg(imtUrl);
      if (p === false) {
        console.log(" \u8907\u88FD\u5F71\u50CF\u5931\u6557\u3002\u7121\u6CD5\u8F09\u5165\u5716\u7247");
        return null;
      }
      let canvas = await this.M.script.img.urlToCanvas(imtUrl);
      let blob = await this.M.script.img.getCanvasBlob(canvas, 1, "medium", "png");
      if (blob === null) {
        return;
      }
      let base64 = await this.M.script.img.blobToBase64(blob);
      if (typeof base64 !== "string") {
        return;
      }
      await WV_System.SetClipboard_Base64ToImage(base64, true);
    }
    let msg = this.M.i18n.t("msg.copyImage");
    Toast.show(msg, 1e3 * 3);
  }
  async copyImageBase64(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getFilePath();
    }
    let fileInfo2 = await WebAPI.getFileInfo2(path);
    if (fileInfo2.Type === "none") {
      return;
    }
    let imgType = Lib.GetFileType(fileInfo2);
    if (this.M.fileLoad.getIsBulkView() === false && this.M.fileLoad.getFilePath() === path && this.M.fileLoad.getGroupType() === GroupType.video) {
      let base64 = await this.M.fileShow.tiefseeview.getCanvasBase64(1, "medium");
      await WV_System.SetClipboard_Txt(base64);
    } else if (imgType === "svg") {
      let base64 = await Lib.sendGet("base64", path);
      await WV_System.SetClipboard_Txt(base64);
    } else {
      let imgData = await this.M.script.img.getImgData(fileInfo2);
      let imtUrl = imgData.arUrl[0].url;
      let p = await this.M.script.img.preloadImg(imtUrl);
      if (p === false) {
        console.log(" \u8907\u88FD\u5F71\u50CFBase64 \u5931\u6557\u3002\u7121\u6CD5\u8F09\u5165\u5716\u7247");
        return null;
      }
      let canvas = await this.M.script.img.urlToCanvas(imtUrl);
      let blob = await this.M.script.img.getCanvasBlob(canvas, 1, "medium", "png");
      if (blob === null) {
        return;
      }
      let base64 = await this.M.script.img.blobToBase64(blob);
      if (typeof base64 !== "string") {
        return;
      }
      await WV_System.SetClipboard_Txt(base64);
    }
    Toast.show(this.M.i18n.t("msg.copyIamgeBase64"), 1e3 * 3);
  }
  async copyTextBase64(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getFilePath();
    }
    if (await WV_File.Exists(path) === false) {
      return;
    }
    let base64 = await Lib.sendGet("base64", path);
    await WV_System.SetClipboard_Txt(base64);
    Toast.show(this.M.i18n.t("msg.copyBase64"), 1e3 * 3);
  }
  async copyText(path) {
    if (path === void 0) {
      path = this.M.fileLoad.getFilePath();
    }
    if (await WV_File.Exists(path) === false) {
      return;
    }
    await WV_System.SetClipboard_FileToTxt(path);
    Toast.show(this.M.i18n.t("msg.copyText"), 1e3 * 3);
  }
}
class ScriptSetting {
  constructor(_M) {
    this.temp_setting = null;
    this.M = _M;
  }
  async showSetting(toPage = "", toDom = "") {
    if (this.temp_setting != null) {
      if (await this.temp_setting.Visible === true) {
        this.temp_setting.WindowState = 0;
        return;
      }
    }
    let domLoading = document.querySelector("#loadingSetting");
    if (domLoading.getAttribute("active") == "true") {
      return;
    } else {
      domLoading.setAttribute("active", "true");
      setTimeout(() => {
        domLoading.setAttribute("active", "");
      }, 1e3);
    }
    await this.M.saveSetting();
    this.temp_setting = await baseWindow.newWindow(`SettingWindow.html?toPage=${toPage}&toDom=${toDom}`);
  }
}
class ScriptWindow {
  constructor(_M) {
    this.domLoading = document.querySelector("#loadingWindow");
    this.btnTopmost = document.querySelector("#menu-layout .js-topmost");
    this.btnMainToolbar = document.querySelector("#menu-layout .js-mainToolbar");
    this.btnMainDirList = document.querySelector("#menu-layout .js-mainDirList");
    this.btnMainFileList = document.querySelector("#menu-layout .js-mainFileList");
    this.btnMainExif = document.querySelector("#menu-layout .js-mainExif");
    this.btnFullScreen = document.querySelector("#menu-layout .js-fullScreen");
    this.isTopmost = false;
    this.M = _M;
  }
  getLang() {
    let lang = this.M.config.settings.other.lang;
    if (lang === "") {
      lang = Lib.getBrowserLang();
    }
    return lang;
  }
  enabledLoading(val) {
    if (val) {
      this.domLoading.style.display = "flex";
    } else {
      this.domLoading.style.display = "none";
    }
  }
  enabledFullScreen(val) {
    this.M.fullScreen.setEnabled(val);
  }
  enabledTopmost(val) {
    if (val === void 0) {
      val = !this.isTopmost;
    }
    this.isTopmost = val;
    baseWindow.topMost = val;
    this.M.mainMenu.setMenuLayoutCheckState(this.btnTopmost, val);
    WV_Window.TopMost = val;
  }
  enabledMainToolbar(val) {
    if (val === void 0) {
      val = !this.M.config.settings.layout.mainToolbarEnabled;
    }
    this.M.mainMenu.setMenuLayoutCheckState(this.btnMainToolbar, val);
    this.M.mainToolbar.setEnabled(val);
  }
  enabledMainDirList(val) {
    if (val === void 0) {
      val = !this.M.config.settings.layout.dirListEnabled;
    }
    this.M.mainMenu.setMenuLayoutCheckState(this.btnMainDirList, val);
    this.M.mainDirList.setEnabled(val);
  }
  enabledMainFileList(val) {
    if (val === void 0) {
      val = !this.M.config.settings.layout.fileListEnabled;
    }
    this.M.mainMenu.setMenuLayoutCheckState(this.btnMainFileList, val);
    this.M.mainFileList.setEnabled(val);
  }
  enabledMainExif(val) {
    if (val === void 0) {
      val = !this.M.config.settings.layout.mainExifEnabled;
    }
    this.M.mainMenu.setMenuLayoutCheckState(this.btnMainExif, val);
    this.M.mainExif.setEnabled(val);
  }
  maximizeWindow(val) {
    if (val === void 0) {
      let WindowState = baseWindow.windowState;
      val = WindowState === "Maximized" && this.M.fullScreen.getEnabled() === false;
      val = !val;
    }
    if (val) {
      setTimeout(() => {
        baseWindow.maximized();
      }, 50);
    } else {
      baseWindow.normal();
    }
  }
}
class ScriptBulkView {
  constructor(_M) {
    this.M = _M;
  }
  show() {
    if (this.M.fileLoad.getIsBulkView() === true) {
      return;
    }
    if (this.M.fileLoad.getGroupType() === GroupType.welcome) {
      return;
    }
    if (this.M.fileLoad.getGroupType() === GroupType.none) {
      return;
    }
    this.M.fileLoad.enableBulkView(true);
    this.M.fileLoad.showFile();
  }
  async close(_flag) {
    if (this.M.fileLoad.getIsBulkView() === false) {
      return;
    }
    this.M.bulkView.saveCurrentState();
    this.M.fileLoad.enableBulkView(false);
    await this.M.fileLoad.showFile(_flag);
    await Lib.sleep(10);
    this.M.mainFileList.setStartLocation();
  }
  pageNext() {
    if (this.M.fileLoad.getIsBulkView() === false) {
      return;
    }
    this.M.bulkView.pageNext();
  }
  pagePrev() {
    if (this.M.fileLoad.getIsBulkView() === false) {
      return;
    }
    this.M.bulkView.pagePrev();
  }
  setColumns(val) {
    if (this.M.fileLoad.getIsBulkView() === false) {
      return;
    }
    this.M.bulkView.setColumns(val);
  }
}
