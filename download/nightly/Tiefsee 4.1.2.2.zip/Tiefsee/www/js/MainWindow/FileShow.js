class FileShow {
  constructor(M) {
    var dom_imgview = document.querySelector("#mView-tiefseeview");
    var tiefseeview = new Tiefseeview(dom_imgview);
    var iframes = new Iframes(M);
    var isLoaded = true;
    var _groupType = GroupType.none;
    this.openImage = openImage;
    this.openVideo = openVideo;
    this.openPdf = openPdf;
    this.openTxt = openTxt;
    this.openWelcome = openWelcome;
    this.openNone = openNone;
    this.openBulkView = openBulkView;
    this.getIsLoaded = getIsLoaded;
    this.getGroupType = getGroupType;
    this.dom_imgview = dom_imgview;
    this.tiefseeview = tiefseeview;
    this.iframes = iframes;
    function getGroupType() {
      return _groupType;
    }
    function setShowType(groupType) {
      _groupType = groupType;
      document.body.setAttribute("showType", groupType);
      let arToolbarGroup = document.querySelectorAll(".main-toolbar-group");
      for (let i = 0; i < arToolbarGroup.length; i++) {
        const item = arToolbarGroup[i];
        item.setAttribute("active", "");
      }
      if (groupType === GroupType.none || groupType === GroupType.welcome) {
        M.mainFileList.setHide(true);
        M.mainDirList.setHide(true);
        M.mainExif.setHide(true);
        M.largeBtn.setHide(true);
      } else if (groupType === GroupType.img || groupType === GroupType.imgs || groupType === GroupType.video) {
        M.mainFileList.setHide(false);
        M.mainDirList.setHide(false);
        M.mainExif.setHide(false);
        M.largeBtn.setHide(false);
      } else if (groupType === GroupType.bulkView) {
        M.mainFileList.setHide(true);
        M.mainDirList.setHide(false);
        M.mainExif.setHide(true);
        M.largeBtn.setHide(true);
      } else {
        M.mainFileList.setHide(false);
        M.mainDirList.setHide(false);
        M.mainExif.setHide(false);
        M.largeBtn.setHide(true);
      }
      if (groupType === GroupType.none) {
        setShowToolbar(GroupType.none);
      }
      if (groupType === GroupType.welcome) {
        setShowToolbar(GroupType.welcome);
        iframes.welcomeview.visible(true);
      } else {
        iframes.welcomeview.visible(false);
      }
      if (groupType === GroupType.img || groupType === GroupType.video) {
        setShowToolbar(GroupType.img);
        dom_imgview.style.display = "block";
      } else {
        dom_imgview.style.display = "none";
        tiefseeview.loadNone();
      }
      if (groupType === GroupType.bulkView) {
        setShowToolbar(GroupType.bulkView);
        M.bulkView.visible(true);
      } else {
        M.bulkView.visible(false);
      }
      if (groupType === GroupType.imgs) {
      }
      if (groupType === GroupType.txt) {
        setShowToolbar(GroupType.txt);
        iframes.textView.visible(true);
      } else {
        iframes.textView.visible(false);
        iframes.textView.loadNone();
      }
      if (groupType === GroupType.monacoEditor) {
        setShowToolbar(GroupType.txt);
        iframes.monacoEditor.visible(true);
      } else {
        iframes.monacoEditor.visible(false);
        iframes.monacoEditor.loadNone();
      }
      if (groupType === GroupType.pdf) {
        setShowToolbar(GroupType.pdf);
        iframes.pdfview.visible(true);
      } else {
        iframes.pdfview.visible(false);
      }
      if (groupType === GroupType.office) {
        setShowToolbar(GroupType.pdf);
        iframes.pDFTronWebviewer.visible(true);
      } else {
        iframes.pDFTronWebviewer.loadNone();
        iframes.pDFTronWebviewer.visible(false);
      }
      if (groupType === GroupType.md) {
        setShowToolbar(GroupType.txt);
        iframes.cherryMarkdown.visible(true);
      } else {
        iframes.cherryMarkdown.visible(false);
        iframes.cherryMarkdown.loadNone();
      }
    }
    function getToolbarDom(type) {
      return M.dom_toolbar.querySelector(`.main-toolbar-group[data-name="${type}"]`);
    }
    function setShowToolbar(type) {
      let arToolbarGroup = document.querySelectorAll(".main-toolbar-group");
      for (let i = 0; i < arToolbarGroup.length; i++) {
        const item = arToolbarGroup[i];
        item.setAttribute("active", "");
      }
      getToolbarDom(type)?.setAttribute("active", "true");
    }
    function getIsLoaded() {
      return isLoaded;
    }
    async function openImage(fileInfo2) {
      isLoaded = false;
      setShowType(GroupType.img);
      let imgurl = fileInfo2.Path;
      tiefseeview.setLoading(true, 200);
      let imgData = await M.script.img.getImgData(fileInfo2);
      let width = imgData.width;
      let height = imgData.height;
      let arUrl = imgData.arUrl;
      let isAnimation = imgData.isAnimation;
      if (isAnimation) {
        imgurl = await WebAPI.Img.getUrl("web", fileInfo2);
        await tiefseeview.loadImg(imgurl);
      } else {
        let _zoomVal = M.config.settings.image.tiefseeviewZoomValue;
        let _zoomType = TiefseeviewZoomType[M.config.settings.image.tiefseeviewZoomType];
        if (_zoomType === void 0) {
          _zoomType = TiefseeviewZoomType["fitWindowOrImageOriginal"];
        }
        await tiefseeview.loadBigimgscale(arUrl, width, height, _zoomType, _zoomVal);
      }
      initTiefseeview(fileInfo2);
      isLoaded = true;
    }
    async function openVideo(fileInfo2) {
      isLoaded = false;
      let _path = fileInfo2.Path;
      setShowType(GroupType.video);
      let imgurl = _path;
      if (M.fileLoad.getGroupType() === GroupType.unknown) {
        imgurl = await WV_Image.GetFileIcon(_path, 256);
      } else {
        imgurl = await WebAPI.Img.getUrl("web", fileInfo2);
      }
      tiefseeview.setLoading(true, 200);
      await tiefseeview.preloadImg(imgurl);
      await tiefseeview.loadVideo(imgurl);
      initTiefseeview(fileInfo2);
      isLoaded = true;
    }
    async function initTiefseeview(fileInfo2) {
      tiefseeview.setLoading(false);
      await tiefseeview.transformRefresh(false);
      tiefseeview.setEventChangeZoom((ratio) => {
        let txt = (ratio * 100).toFixed(0) + "%";
        let dom_btnScale = M.dom_toolbar.querySelector(`[data-name="btnScale"]`);
        if (dom_btnScale !== null) {
          dom_btnScale.innerHTML = txt;
        }
        M.mainMenu.updateRightMenuImageZoomRatioTxt(txt);
      });
      let _zoomType = TiefseeviewZoomType[M.config.settings.image.tiefseeviewZoomType];
      let _zoomVal = M.config.settings.image.tiefseeviewZoomValue;
      let _alignType = TiefseeviewAlignType[M.config.settings.image.tiefseeviewAlignType];
      if (_zoomType === void 0) {
        _zoomType = TiefseeviewZoomType["fitWindowOrImageOriginal"];
      }
      if (_alignType === void 0) {
        _alignType = TiefseeviewAlignType["center"];
      }
      tiefseeview.zoomFull(_zoomType, _zoomVal);
      tiefseeview.setAlign(_alignType);
      let dom_size = getToolbarDom(GroupType.img)?.querySelector(`[data-name="infoSize"]`);
      if (dom_size != null) {
        dom_size.innerHTML = `${tiefseeview.getOriginalWidth()}<br>${tiefseeview.getOriginalHeight()}`;
      }
      let dom_type = getToolbarDom(GroupType.img)?.querySelector(`[data-name="infoType"]`);
      if (dom_type != null) {
        let fileType = Lib.GetFileType(fileInfo2);
        let fileLength = Lib.getFileLength(fileInfo2.Lenght);
        dom_type.innerHTML = `${fileType}<br>${fileLength}`;
      }
      let dom_writeTime = getToolbarDom(GroupType.img)?.querySelector(`[data-name="infoWriteTime"]`);
      if (dom_writeTime != null) {
        let timeUtc = fileInfo2.LastWriteTimeUtc;
        let time = new Date(timeUtc).format("yyyy-MM-dd<br>hh:mm:ss");
        dom_writeTime.innerHTML = time;
      }
    }
    async function openPdf(fileInfo2) {
      let _path = fileInfo2.Path;
      let fileType = Lib.GetFileType(fileInfo2);
      let configItem = M.config.getAllowFileTypeItem(GroupType.pdf, fileType);
      if (configItem == void 0) {
        configItem = { ext: "", type: "pdf" };
      }
      let configType = configItem.type;
      if (configType == "pdf") {
        setShowType(GroupType.pdf);
        iframes.pdfview.loadFile(fileInfo2);
      }
      if (configType == "PDFTronWebviewer") {
        setShowType(GroupType.office);
        iframes.setTheme();
        await iframes.pDFTronWebviewer.loadFile(_path);
      }
      let dom_type = getToolbarDom(GroupType.pdf)?.querySelector(`[data-name="infoType"]`);
      if (dom_type != null) {
        let fileType2 = Lib.GetFileType(fileInfo2).toLocaleUpperCase();
        let fileLength = Lib.getFileLength(fileInfo2.Lenght);
        dom_type.innerHTML = `${fileType2}<br>${fileLength}`;
      }
      let dom_writeTime = getToolbarDom(GroupType.pdf)?.querySelector(`[data-name="infoWriteTime"]`);
      if (dom_writeTime != null) {
        let timeUtc = fileInfo2.LastWriteTimeUtc;
        let time = new Date(timeUtc).format("yyyy-MM-dd<br>hh:mm:ss");
        dom_writeTime.innerHTML = time;
      }
    }
    async function openTxt(fileInfo2) {
      let _path = fileInfo2.Path;
      let fileType = Lib.GetFileType(fileInfo2);
      let configItem = M.config.getAllowFileTypeItem(GroupType.txt, fileType);
      if (configItem == void 0) {
        configItem = { ext: "", type: "auto" };
      }
      let configType = configItem.type;
      if (baseWindow.appInfo === void 0) {
        return;
      }
      let txt = await WebAPI.getText(_path);
      if (configType === "md") {
        setShowType(GroupType.md);
        iframes.setTheme();
        let dir = Lib.GetDirectoryName(_path);
        dir = Lib.pathToURL(dir) + "/";
        await iframes.cherryMarkdown.setReadonly(M.getIsQuickLook());
        await iframes.cherryMarkdown.loadFile(txt, dir);
      } else if (baseWindow.appInfo.plugin.MonacoEditor) {
        setShowType(GroupType.monacoEditor);
        iframes.setTheme();
        if (configType == "auto") {
          await iframes.monacoEditor.loadFile(txt, _path);
        } else {
          await iframes.monacoEditor.loadTxt(txt, configType);
        }
        await iframes.monacoEditor.setReadonly(M.getIsQuickLook());
      } else {
        setShowType(GroupType.txt);
        iframes.setTheme();
        iframes.textView.setReadonly(M.getIsQuickLook());
        iframes.textView.loadTxt(txt);
      }
      let dom_type = getToolbarDom(GroupType.txt)?.querySelector(`[data-name="infoType"]`);
      if (dom_type != null) {
        let fileType2 = Lib.GetFileType(fileInfo2).toLocaleUpperCase();
        let fileLength = Lib.getFileLength(fileInfo2.Lenght);
        dom_type.innerHTML = `${fileType2}<br>${fileLength}`;
      }
      let dom_writeTime = getToolbarDom(GroupType.txt)?.querySelector(`[data-name="infoWriteTime"]`);
      if (dom_writeTime != null) {
        let timeUtc = fileInfo2.LastWriteTimeUtc;
        let time = new Date(timeUtc).format("yyyy-MM-dd<br>hh:mm:ss");
        dom_writeTime.innerHTML = time;
      }
    }
    async function openWelcome() {
      baseWindow.setTitle("Tiefsee 4");
      M.fileLoad.setGroupType(GroupType.welcome);
      setShowType(GroupType.welcome);
    }
    function openNone() {
      baseWindow.setTitle("Tiefsee 4");
      M.fileLoad.setGroupType(GroupType.none);
      setShowType(GroupType.none);
      tiefseeview.zoomFull(TiefseeviewZoomType["imageOriginal"]);
      let dom_size = getToolbarDom(GroupType.img)?.querySelector(`[data-name="infoSize"]`);
      let dom_type = getToolbarDom(GroupType.img)?.querySelector(`[data-name="infoType"]`);
      let dom_writeTime = getToolbarDom(GroupType.img)?.querySelector(`[data-name="infoWriteTime"]`);
      if (dom_size) {
        dom_size.innerHTML = "";
      }
      if (dom_type) {
        dom_type.innerHTML = "";
      }
      if (dom_writeTime) {
        dom_writeTime.innerHTML = "";
      }
    }
    async function openBulkView() {
      setShowType(GroupType.bulkView);
      let dir = M.fileLoad.getDirPath();
      let fileInfo2 = await WebAPI.getFileInfo2(dir);
      let dom_writeTime = getToolbarDom(GroupType.bulkView)?.querySelector(`[data-name="infoWriteTime"]`);
      if (dom_writeTime != null) {
        let timeUtc = fileInfo2.LastWriteTimeUtc;
        let time = new Date(timeUtc).format("yyyy-MM-dd<br>hh:mm:ss");
        dom_writeTime.innerHTML = time;
      }
      await M.bulkView.load2();
    }
  }
}
