class LargeBtn {
  constructor(M) {
    var dom_largeBtnLeft = document.getElementById("largeBtnLeft");
    var dom_largeBtnRight = document.getElementById("largeBtnRight");
    this.dom_largeBtnLeft = dom_largeBtnLeft;
    this.dom_largeBtnRight = dom_largeBtnRight;
    this.setShowType = setShowType;
    this.setHide = setHide;
    dom_largeBtnLeft.addEventListener("click", function(e) {
      M.script.fileLoad.prevFile();
    });
    dom_largeBtnRight.addEventListener("click", function(e) {
      M.script.fileLoad.nextFile();
    });
    function setShowType(type) {
      if (type == "leftRight") {
        dom_largeBtnLeft.setAttribute("data-style", "leftRight-L");
        dom_largeBtnRight.setAttribute("data-style", "leftRight-R");
      } else if (type == "leftRight2") {
        dom_largeBtnLeft.setAttribute("data-style", "leftRight2-L");
        dom_largeBtnRight.setAttribute("data-style", "leftRight2-R");
      } else if (type == "bottom") {
        dom_largeBtnLeft.setAttribute("data-style", "bottom-L");
        dom_largeBtnRight.setAttribute("data-style", "bottom-R");
      } else {
        dom_largeBtnLeft.setAttribute("data-style", "none-L");
        dom_largeBtnRight.setAttribute("data-style", "none-R");
      }
    }
    function setHide(val) {
      if (val) {
        dom_largeBtnLeft.setAttribute("hide", "true");
        dom_largeBtnRight.setAttribute("hide", "true");
      } else {
        dom_largeBtnLeft.setAttribute("hide", "");
        dom_largeBtnRight.setAttribute("hide", "");
      }
    }
  }
}
