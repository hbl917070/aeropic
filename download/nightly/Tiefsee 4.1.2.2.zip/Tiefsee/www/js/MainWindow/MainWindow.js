var baseWindow;
var mainWindow;
document.addEventListener("DOMContentLoaded", async () => {
  mainWindow = new MainWindow();
});
class MainWindow {
  constructor() {
    baseWindow = new BaseWindow();
    this.quickLookUp = quickLookUp;
    var dom_toolbar = document.getElementById("main-toolbar");
    var dom_mainL = document.getElementById("main-L");
    var dom_mainR = document.getElementById("main-R");
    var btn_layout = document.querySelector(".titlebar-toolbar-layout");
    let firstRun = true;
    let startType = 0;
    var isQuickLook = false;
    this.dom_toolbar = dom_toolbar;
    this.dom_mainL = dom_mainL;
    this.dom_mainR = dom_mainR;
    var config = this.config = new Config(baseWindow);
    var i18n = this.i18n = new I18n();
    i18n.pushData(langData);
    var msgbox = this.msgbox = new Msgbox(i18n);
    var fileLoad = this.fileLoad = new FileLoad(this);
    var fileShow = this.fileShow = new FileShow(this);
    var fileSort = this.fileSort = new FileSort(this);
    var dirSort = this.dirSort = new DirSort(this);
    var mainFileList = this.mainFileList = new MainFileList(this);
    var mainDirList = this.mainDirList = new MainDirList(this);
    var imgSearch = this.imgSearch = new ImgSearch(this);
    var mainExif = this.mainExif = new MainExif(this);
    var mainToolbar = this.mainToolbar = new MainToolbar(this);
    var menu = this.menu = new Menu(this);
    var mainMenu = this.mainMenu = new MainMenu(this);
    var largeBtn = this.largeBtn = new LargeBtn(this);
    var script = this.script = new Script(this);
    var bulkView = this.bulkView = new BulkView(this);
    var toolbarBack = this.toolbarBack = new ToolbarBack();
    var fullScreen = this.fullScreen = new FullScreen(this);
    this.applySetting = applySetting;
    this.saveSetting = saveSetting;
    this.getIsQuickLook = getIsQuickLook;
    this.updateDomVisibility = updateDomVisibility;
    new Hotkey(this);
    init();
    async function init() {
      fileShow.openNone();
      WV_Window.SetMinimumSize(250 * window.devicePixelRatio, 250 * window.devicePixelRatio);
      fileShow.tiefseeview.setMargin(0, 10, 10, 0);
      baseWindow.sizeChangeEvents.push(async () => {
        if (baseWindow.windowState === "Normal") {
          config.settings.position.width = baseWindow.width;
          config.settings.position.height = baseWindow.height;
        }
      });
      baseWindow.closingEvents.push(async () => {
        if (getIsQuickLook() === false) {
          if (script.setting.temp_setting != null) {
            if (await script.setting.temp_setting.Visible === true) {
              await script.setting.temp_setting.RunJs("setting.saveData();");
              await Lib.sleep(30);
            }
          }
          WV_System.DeleteTemp(100, 300, 100);
          await saveSetting();
          return true;
        } else {
          quickLookUp();
          return false;
        }
      });
      async function initIcon() {
        let path = Lib.Combine([await WV_Window.GetAppDirPath(), "www\\img\\logo.ico"]);
        WV_Window.SetIcon(path);
      }
      initIcon();
      btn_layout.addEventListener("click", function(e) {
        script.menu.showLayout(btn_layout);
      });
      document.addEventListener("contextmenu", function(e) {
        e.preventDefault();
      });
      fileShow.dom_imgview.addEventListener("mousedown", async (e) => {
        if (fileShow.tiefseeview.getIsOverflowX() === false && fileShow.tiefseeview.getIsOverflowY() === false) {
          if (e.button === 0) {
            let WindowState = baseWindow.windowState;
            if (WindowState === "Normal") {
              WV_Window.WindowDrag("move");
            }
          }
        }
        window.focus();
      });
      Lib.addEventDblclick(dom_toolbar, async (e) => {
        let _dom = e.target;
        if (_dom) {
          if (_dom.classList.contains("js-noDrag")) {
            return;
          }
        }
        let WindowState = baseWindow.windowState;
        if (WindowState === "Maximized" && fullScreen.getEnabled() === false) {
          baseWindow.normal();
        } else {
          setTimeout(() => {
            baseWindow.maximized();
          }, 50);
        }
      });
      Lib.addEventDblclick(fileShow.iframes.welcomeview.dom, async () => {
        let WindowState = baseWindow.windowState;
        if (WindowState === "Maximized" && fullScreen.getEnabled() === false) {
          baseWindow.normal();
        } else {
          setTimeout(() => {
            baseWindow.maximized();
          }, 50);
        }
      });
      dom_toolbar.addEventListener("mousedown", async (e) => {
        if (fullScreen.getEnabled() === true) {
          return;
        }
        let _dom = e.target;
        if (_dom) {
          if (_dom.classList.contains("js-noDrag")) {
            return;
          }
        }
        if (e.button === 0) {
          await WV_Window.WindowDrag("move");
        }
      });
      dom_toolbar.addEventListener("touchstart", async (e) => {
        if (fullScreen.getEnabled() === true) {
          return;
        }
        let _dom = e.target;
        if (_dom) {
          if (_dom.classList.contains("js-noDrag")) {
            return;
          }
        }
        let isShowScroll = dom_toolbar.scrollWidth > dom_toolbar.clientWidth;
        if (isShowScroll === false) {
          baseWindow.touchDrop.start(dom_toolbar, e, "move");
        }
      });
      dom_toolbar.addEventListener("wheel", (e) => {
        let scrollLeft = dom_toolbar.scrollLeft;
        let deltaY = e.deltaY;
        if (deltaY > 0) {
          dom_toolbar.scroll(scrollLeft + 20, 0);
        }
        if (deltaY < 0) {
          dom_toolbar.scroll(scrollLeft - 20, 0);
        }
      }, false);
      new TiefseeScroll().initGeneral(dom_toolbar, "x");
      fileShow.iframes.welcomeview.dom.addEventListener("mousedown", async (e) => {
        let _dom = e.target;
        if (_dom) {
          if (_dom.classList.contains("js-noDrag")) {
            return;
          }
        }
        e.preventDefault();
        if (e.button === 0) {
          let WindowState = baseWindow.windowState;
          if (WindowState === "Normal") {
            WV_Window.WindowDrag("move");
          }
        }
      });
      fileShow.dom_imgview.addEventListener("mousedown", (e) => {
        let sc = "";
        let type = e.button;
        if (type === 1) {
          sc = config.settings.mouse.scrollWheelButton;
        }
        if (type === 3) {
          sc = config.settings.mouse.mouseButton4;
        }
        if (type === 4) {
          sc = config.settings.mouse.mouseButton5;
        }
        let offsetX = e.x - fileShow.dom_imgview.getBoundingClientRect().left;
        let offsetY = e.y - fileShow.dom_imgview.getBoundingClientRect().top;
        script.run(sc, { x: offsetX, y: offsetY });
      });
      Lib.addEventDblclick(fileShow.dom_imgview, async (e) => {
        let sc = config.settings.mouse.leftDoubleClick;
        let offsetX = e.x - fileShow.dom_imgview.getBoundingClientRect().left;
        let offsetY = e.y - fileShow.dom_imgview.getBoundingClientRect().top;
        script.run(sc, { x: offsetX, y: offsetY });
      });
      fileShow.tiefseeview.setEventMouseWheel((type, e, offsetX, offsetY) => {
        let sc = "";
        if (type === "up") {
          if (e.ctrlKey) {
            sc = config.settings.mouse.scrollUpCtrl;
          } else if (e.shiftKey) {
            sc = config.settings.mouse.scrollUpShift;
          } else if (e.altKey) {
            sc = config.settings.mouse.scrollUpAlt;
          } else {
            sc = config.settings.mouse.scrollUp;
          }
        } else {
          if (e.ctrlKey) {
            sc = config.settings.mouse.scrollDownCtrl;
          } else if (e.shiftKey) {
            sc = config.settings.mouse.scrollDownShift;
          } else if (e.altKey) {
            sc = config.settings.mouse.scrollDownAlt;
          } else {
            sc = config.settings.mouse.scrollDown;
          }
        }
        script.run(sc, { x: offsetX, y: offsetY });
      });
      window.addEventListener("dragenter", dragenter, false);
      window.addEventListener("dragover", dragover, false);
      window.addEventListener("drop", drop, false);
      function dragenter(e) {
        e.stopPropagation();
        e.preventDefault();
      }
      function dragover(e) {
        e.stopPropagation();
        e.preventDefault();
      }
      async function drop(e) {
        const e2 = e.detail.event;
        if (e2 !== void 0) {
          e = e2;
        }
        if (e.dataTransfer === null) {
          return;
        }
        let files = e.dataTransfer.files;
        let text = e.dataTransfer.getData("text/plain");
        let textUrl = e.dataTransfer.getData("text/uri-list");
        if ((text === "" || text.indexOf("file://") === 0) && files.length > 0) {
          let arFile = [];
          for (let i = 0; i < files.length; i++) {
            const item = files[i];
            arFile.push(item.name);
          }
          await fileLoad.loadDropFile(arFile);
          e.preventDefault();
        } else if (text.search(/^http:\/\/127\.0\.0\.1:\d+\/file=/) === 0) {
          e.preventDefault();
          var path = text.match(/file=(.+)/)?.[1] || "";
          path = Lib.URLToPath(path);
          await fileLoad.loadFile(path);
        } else if (text.search(/^http:\/\/127\.0\.0\.1:7860\/.*\?filename=([^&]+).*$/) === 0) {
          e.preventDefault();
          const regex = /^http:\/\/127\.0\.0\.1:7860\/.*\?filename=([^&]+).*$/;
          const match = text.match(regex);
          if (match) {
            path = decodeURIComponent(match[1]);
            path = Lib.URLToPath(path);
            await fileLoad.loadFile(path);
          }
        } else if (text.indexOf("https://cdn.discordapp.com/attachments/") === 0) {
          e.preventDefault();
          let file = await downloadFileFromUrl(text);
          if (file != null) {
            let base64 = await readFileAsDataURL(file);
            let extension = await getExtensionFromBase64(base64);
            if (extension !== "") {
              let path2 = await WV_File.Base64ToTempFile(base64, extension);
              await fileLoad.loadFile(path2);
            }
          }
        } else if (text.search(/^((blob:)?http[s]?|file):[/][/]/) === 0 && files.length > 0) {
          e.preventDefault();
          let base64 = await readFileAsDataURL(files[0]);
          let extension = await getExtensionFromBase64(base64);
          if (extension !== "") {
            let path2 = await WV_File.Base64ToTempFile(base64, extension);
            await fileLoad.loadFile(path2);
          } else {
            let file = await downloadFileFromUrl(text);
            if (file != null) {
              let base642 = await readFileAsDataURL(file);
              let extension2 = await getExtensionFromBase64(base642);
              if (extension2 !== "") {
                let path2 = await WV_File.Base64ToTempFile(base642, extension2);
                await fileLoad.loadFile(path2);
              }
            }
          }
        } else if (text.indexOf("data:image/") === 0) {
          e.preventDefault();
          let base64 = text;
          let extension = await getExtensionFromBase64(base64);
          if (extension !== "") {
            let path2 = await WV_File.Base64ToTempFile(base64, extension);
            await fileLoad.loadFile(path2);
          }
        } else if (text.search(/^http[s]:[/][/]/) === 0) {
          e.preventDefault();
          let file = await downloadFileFromUrl(text);
          if (file != null) {
            let base64 = await readFileAsDataURL(file);
            let extension = await getExtensionFromBase64(base64);
            if (extension !== "") {
              let path2 = await WV_File.Base64ToTempFile(base64, extension);
              await fileLoad.loadFile(path2);
            }
          }
        } else if (textUrl.search(/^file:[/][/]/) === 0) {
          e.preventDefault();
          let path2 = Lib.URLToPath(textUrl);
          await fileLoad.loadFile(path2);
        } else {
          e.preventDefault();
        }
      }
      async function readFileAsDataURL(file) {
        return await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (event) => {
            resolve(event.target?.result);
          };
          reader.onerror = (event) => {
            reject(event.target?.error);
          };
          reader.readAsDataURL(file);
        });
      }
      async function getExtensionFromBase64(base64) {
        if (base64.length < 100) {
          return "";
        }
        const base64Header = base64.slice(0, 100);
        const mimeMatch = base64Header.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+).*,.*/);
        if (!mimeMatch) {
          return "";
        }
        const mimeType = mimeMatch[1];
        switch (mimeType) {
          case "image/png":
            return "png";
          case "image/gif":
            return "gif";
          case "image/jpeg":
          case "image/pjpeg":
            return "jpg";
          case "image/bmp":
            return "bmp";
          case "image/tiff":
            return "tiff";
          case "image/svg+xml":
            return "svg";
          case "image/webp":
            return "webp";
          case "image/avif":
            return "avif";
          case "image/x-icon":
          case "image/vnd.microsoft.icon":
            return "ico";
          case "image/octet-stream":
            if (await isValidImageBase64(base64)) {
              return "png";
            } else {
              return "";
            }
          default:
            return "";
        }
      }
      async function isValidImageBase64(base64) {
        return new Promise((resolve, reject) => {
          const img = new Image();
          img.src = base64;
          img.onload = () => {
            try {
              const canvas = document.createElement("canvas");
              canvas.width = 1;
              canvas.height = 1;
              const ctx = canvas.getContext("2d");
              ctx.drawImage(img, 0, 0, 1, 1, 0, 0, 1, 1);
              resolve(true);
            } catch (e) {
              resolve(false);
            }
          };
          img.onerror = () => {
            resolve(false);
          };
        });
      }
      async function downloadFileFromUrl(imageUrl) {
        const timeout = 20 * 1e3;
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);
        script.window.enabledLoading(true);
        try {
          const response = await fetch(imageUrl, { signal: controller.signal });
          if (response.status !== 200) {
            Toast.show(i18n.t("msg.fileDownloadFailed") + ` (code:${response.status})`, 1e3 * 3);
            return null;
          }
          const contentLength = response.headers.get("content-length");
          if (contentLength && parseInt(contentLength, 10) > 50 * 1e3 * 1e3) {
            Toast.show(i18n.t("msg.fileSizeExceededLimit"), 1e3 * 3);
            return null;
          }
          const contentType = response.headers.get("content-type");
          if (!contentType || !contentType.startsWith("image/")) {
            Toast.show(i18n.t("msg.unsupportedFileTypes"), 1e3 * 3);
            return null;
          }
          const blob = await response.blob();
          const fileName = imageUrl.substring(imageUrl.lastIndexOf("/") + 1);
          return new File([blob], fileName, { type: response.headers.get("content-type") ?? "application/octet-stream" });
        } catch (error) {
          Toast.show(i18n.t("msg.fileDownloadFailed"), 1e3 * 3);
          console.error(error);
          return null;
        } finally {
          clearTimeout(timeoutId);
          script.window.enabledLoading(false);
        }
      }
      baseWindow.onNewWindowRequested = (url) => {
        if (url.indexOf("https://maps.google.com/") === 0) {
          WV_RunApp.OpenUrl(url);
          temp_dropPath = "";
        }
      };
      baseWindow.onRightClick = (x, y) => {
        x = x / window.devicePixelRatio;
        y = y / window.devicePixelRatio;
        if (y <= 30) {
          mainMenu.showMenu(new MouseEvent("mouseup"), x, y);
        }
      };
    }
    baseWindow.onCreate = async (json) => {
      baseWindow.appInfo = json;
      startType = json.startType;
      isQuickLook = false;
      if (json.quickLookRunType === 0) {
        if (firstRun === true) {
          firstRun = false;
          initSetting(json.settingTxt);
          await initLastPosition();
          mainMenu.initOpen();
          initLoad(json.args);
          initAERO();
        } else {
          WV_Window.ShowWindow();
          initLoad(json.args);
        }
      }
      if (json.quickLookRunType !== 0) {
        msgbox.closeAll();
        initSetting(json.settingTxt);
        let isKeyboardSpace = json.quickLookRunType === 1;
        let isMouseMiddle = json.quickLookRunType === 2;
        if (isKeyboardSpace && config.settings.quickLook.keyboardSpaceRun || isMouseMiddle && config.settings.quickLook.mouseMiddleRun) {
          if (startType == 4 || startType == 5) {
            WV_Window.ShowWindow();
            initLoad(json.args);
          } else {
            isQuickLook = true;
            fileShow.openNone();
            await initQuickLookPosition();
            mainMenu.initOpen();
            initLoad(json.args);
            initAERO();
          }
          checkDownKey();
        }
      }
      window.focus();
      setTimeout(() => {
        window.onblur = function() {
          menu.close();
        };
      }, 1e3);
    };
    async function quickLookUp() {
      if (startType === 2 || startType === 3) {
        fileShow.openNone();
        await WV_Window.Hide();
      }
    }
    async function initQuickLookPosition() {
      let mousePosition = await WV_System.GetMousePosition();
      let screen = await WV_System.GetScreenFromPoint(mousePosition[0], mousePosition[1]);
      let screenX = screen[0];
      let screenY = screen[1];
      let screenW = screen[2];
      let screenH = screen[3];
      let rate = 0.8;
      let width = screenW * rate;
      let height = screenH * rate;
      let left = screenX + (screenW - width) / 2;
      let top = screenY + (screenH - height) / 2;
      await WV_Window.ShowWindowAtPosition(left, top, width, height, "Normal");
    }
    async function initLastPosition() {
      let txtPosition = config.settings.position;
      if (txtPosition.left !== -9999) {
        if (txtPosition.windowState == "Maximized") {
          await WV_Window.ShowWindowAtPosition(txtPosition.left, txtPosition.top, txtPosition.width, txtPosition.height, "Maximized");
        } else if (txtPosition.windowState == "Normal") {
          await WV_Window.ShowWindowAtPosition(txtPosition.left, txtPosition.top, txtPosition.width, txtPosition.height, "Normal");
        } else {
          await WV_Window.ShowWindow();
          await WV_Window.SetSize(800 * window.devicePixelRatio, 600 * window.devicePixelRatio);
        }
      } else {
        await WV_Window.ShowWindow();
        await WV_Window.SetSize(800 * window.devicePixelRatio, 600 * window.devicePixelRatio);
      }
    }
    function initLoad(args) {
      msgbox.closeAll();
      menu.close();
      args = args.map((arg) => arg.startsWith("\\\\?\\") ? arg.slice(4) : arg);
      if (args.length > 0 && args[0] === "none") {
        args.shift();
      }
      if (args.length === 0) {
        fileShow.openWelcome();
      } else if (args.length === 1) {
        if (args[0] === "") {
          fileShow.openWelcome();
        } else {
          fileLoad.loadFile(args[0]);
        }
      } else {
        let arFile = [];
        for (let i = 0; i < args.length; i++) {
          arFile.push(Lib.GetFileName(args[i]));
        }
        let dirPath = Lib.GetDirectoryName(args[0]);
        if (dirPath != null) {
          fileLoad.loadFiles(dirPath, arFile);
        }
      }
    }
    function initSetting(settingTxt) {
      var userSetting = {};
      try {
        userSetting = JSON.parse(settingTxt);
      } catch (e) {
      }
      $.extend(true, config.settings, userSetting);
      applySetting(config.settings, true);
    }
    var isInitAERO = false;
    function initAERO() {
      if (isInitAERO) {
        return;
      }
      let aeroType = config.settings["theme"]["aeroType"];
      if (aeroType == "win10") {
        WV_Window.SetAERO("win10");
        isInitAERO = true;
      } else if (aeroType == "win7") {
        WV_Window.SetAERO("win7");
        isInitAERO = true;
      }
    }
    async function checkDownKey() {
      let json = JSON.parse(await WV_System.GetDownKey());
      let keyboardSpaceRun = config.settings.quickLook.keyboardSpaceRun;
      let mouseMiddleRun = config.settings.quickLook.mouseMiddleRun;
      if (json.isKeyboardSpace && keyboardSpaceRun || json.isMouseMiddle && mouseMiddleRun) {
      } else {
        quickLookUp();
      }
    }
    function getIsQuickLook() {
      return isQuickLook;
    }
    function updateDomVisibility() {
      let bodyShowType = document.body.getAttribute("showType");
      if (bodyShowType === null) {
        return;
      }
      function getShowType(dom) {
        while (true) {
          let showType = dom.getAttribute("showType");
          if (showType !== null && showType !== "") {
            return showType;
          }
          if (dom === document.body) {
            break;
          }
          dom = dom.parentNode;
        }
        return bodyShowType;
      }
      let arDom = document.querySelectorAll(`[show-not]`);
      for (let i = 0; i < arDom.length; i++) {
        const dom = arDom[i];
        let showType = getShowType(dom);
        if (dom.getAttribute("show-not")?.indexOf(showType + ",") !== -1) {
          dom.classList.add("js-showType-none");
        } else {
          dom.classList.remove("js-showType-none");
        }
      }
      arDom = document.querySelectorAll(`[show-only]`);
      for (let i = 0; i < arDom.length; i++) {
        const dom = arDom[i];
        let showType = getShowType(dom);
        if (dom.getAttribute("show-only")?.indexOf(showType + ",") !== -1) {
          dom.classList.remove("js-showType-none");
        } else {
          dom.classList.add("js-showType-none");
        }
      }
    }
    function applySetting(_settings, isStart = false) {
      let cssRoot = document.body;
      config.settings = _settings;
      let lang = script.window.getLang();
      i18n.setLang(lang);
      let dpizoom = Number(config.settings["image"]["dpizoom"]);
      if (dpizoom == -1 || isNaN(dpizoom)) {
        dpizoom = -1;
      }
      fileShow.tiefseeview.setDpizoom(dpizoom);
      let tiefseeviewImageRendering = Number(config.settings["image"]["tiefseeviewImageRendering"]);
      fileShow.tiefseeview.setRendering(tiefseeviewImageRendering);
      baseWindow.setZoomFactor(config.settings["theme"]["zoomFactor"]);
      cssRoot.style.setProperty("--svgWeight", config.settings["theme"]["svgWeight"]);
      let fontWeight = Number.parseInt(config.settings["theme"]["fontWeight"]);
      let fontWeightBole = Number.parseInt(config.settings["theme"]["fontWeight"]) + 200;
      cssRoot.style.setProperty("--fontWeight", fontWeight.toString());
      cssRoot.style.setProperty("--fontWeightBold", fontWeightBole.toString());
      mainToolbar.setEnabled(config.settings.layout.mainToolbarEnabled);
      dom_toolbar.setAttribute("toolbarAlign", config.settings.layout.mainToolbarAlign);
      mainFileList.setEnabled(config.settings.layout.fileListEnabled);
      mainFileList.setShowNo(config.settings.layout.fileListShowNo);
      mainFileList.setShowName(config.settings.layout.fileListShowName);
      if (isStart) {
        mainFileList.setItemWidth(config.settings.layout.fileListShowWidth);
      }
      mainDirList.setEnabled(config.settings.layout.dirListEnabled);
      mainDirList.setShowNo(config.settings.layout.dirListShowNo);
      mainDirList.setShowName(config.settings.layout.dirListShowName);
      mainDirList.setImgNumber(config.settings.layout.dirListImgNumber);
      if (isStart) {
        mainDirList.setItemWidth(config.settings.layout.dirListShowWidth);
      }
      mainExif.setEnabled(config.settings.layout.mainExifEnabled);
      if (isStart) {
        mainExif.setItemWidth(config.settings.layout.mainExifShowWidth);
      }
      cssRoot.style.setProperty("--mainExifMaxLine", config.settings.layout.mainExifMaxLine + "");
      mainExif.setHorizontal(config.settings.layout.mainExifHorizontal);
      const arGroupName = ["img", "pdf", "txt", "bulkView"];
      arGroupName.map((gn) => {
        let groupName = gn;
        let dom_group = dom_toolbar.querySelector(`.main-toolbar-group[data-name=${groupName}]`);
        let arMainToolbar = config.settings.mainToolbar[groupName];
        for (let i = 0; i < arMainToolbar.length; i++) {
          const item = arMainToolbar[i];
          let dom_btn = dom_group.querySelector(`[data-name="${item.n}"]`);
          if (dom_btn === null) {
            continue;
          }
          if (dom_btn.getAttribute("data-name") == "showBulkViewSetting") {
            continue;
          }
          dom_btn.style.order = i + "";
          dom_btn.style.display = item.v ? "" : "none";
        }
      });
      largeBtn.setShowType(config.settings.layout.largeBtn);
      bulkView.setImgMaxCount(config.settings.bulkView.imgMaxCount);
      let imageArea = Number(config.settings.advanced.highQualityLimit);
      if (imageArea == -1) {
        imageArea = 999999;
      }
      imageArea = imageArea * imageArea;
      fileShow.tiefseeview.setEventHighQualityLimit(() => {
        return imageArea;
      });
      cssRoot.style.setProperty("--window-border-radius", config.settings.theme["--window-border-radius"] + "px");
      initColor("--color-window-background", true);
      initColor("--color-window-border", true);
      initColor("--color-white");
      initColor("--color-black");
      initColor("--color-blue");
      function initColor(name, opacity = false) {
        let c = config.settings.theme[name];
        if (opacity) {
          cssRoot.style.setProperty(name, `rgba(${c.r}, ${c.g}, ${c.b}, ${c.a} )`);
        } else {
          for (let i = 1; i < 9; i++) {
            cssRoot.style.setProperty(name + `${i}0`, `rgba(${c.r}, ${c.g}, ${c.b}, ${i / 10} )`);
          }
          cssRoot.style.setProperty(name, `rgba(${c.r}, ${c.g}, ${c.b}, 1 )`);
        }
      }
      fileShow.iframes.setTheme();
    }
    async function saveSetting() {
      config.settings.position.left = baseWindow.left;
      config.settings.position.top = baseWindow.top;
      config.settings.position.windowState = baseWindow.windowState;
      let s = JSON.stringify(config.settings, null, "	");
      var path = await WV_Window.GetAppDataPath();
      path = Lib.Combine([path, "Setting.json"]);
      await WV_File.SetText(path, s);
    }
  }
}
class ToolbarBack {
  constructor() {
    var btn = document.querySelector("#toolbar-back");
    var clickEvent = () => {
    };
    var active = false;
    this.visible = visible;
    this.getVisible = getVisible;
    this.setEvent = setEvent;
    this.runEvent = runEvent;
    btn.addEventListener("click", () => {
      clickEvent();
    });
    function visible(val) {
      if (val === true) {
        btn.setAttribute("active", "true");
        active = true;
      } else {
        btn.setAttribute("active", "");
        active = false;
      }
    }
    function getVisible() {
      return active;
    }
    function setEvent(func) {
      clickEvent = func;
    }
    function runEvent() {
      clickEvent();
    }
  }
}
class FullScreen {
  constructor(M) {
    this.enabled = false;
    this.showTitlebar = false;
    this.domTitleBar = document.querySelector("#window-titlebar");
    this.domMainT = document.querySelector("#main-T");
    this.btnExitFullScreen = document.querySelector(".titlebar-toolbar-exitFullScreen");
    this.mousemoveEvent = (e) => {
      if (this.showTitlebar === false && e.clientY <= 5) {
        this.showTitlebar = true;
        document.body.setAttribute("showTitlebar", "true");
      } else if (this.showTitlebar === true && e.clientY < this.domTitleBar.offsetHeight + this.domMainT.offsetHeight + 10) {
        this.showTitlebar = true;
        document.body.setAttribute("showTitlebar", "true");
      } else {
        this.showTitlebar = false;
        document.body.setAttribute("showTitlebar", "false");
      }
    };
    this.exitEvent = async () => {
      if (this.getEnabled() === true && baseWindow.windowState !== "Maximized") {
        this.setEnabled(false);
      }
    };
    this.M = M;
    this.btnExitFullScreen.addEventListener("click", () => {
      this.setEnabled(false);
    });
  }
  getEnabled() {
    return this.enabled;
  }
  async setEnabled(val) {
    if (val === void 0) {
      val = !this.enabled;
    }
    this.enabled = val;
    this.M.menu.close();
    await WV_Window.SetFullScreen(val);
    if (val) {
      document.body.setAttribute("fullScreen", "true");
      document.addEventListener("mousemove", this.mousemoveEvent);
      baseWindow.sizeChangeEvents.push(this.exitEvent);
    } else {
      document.body.setAttribute("fullScreen", "false");
      document.removeEventListener("mousemove", this.mousemoveEvent);
      const index = baseWindow.sizeChangeEvents.indexOf(this.exitEvent);
      if (index > -1) {
        baseWindow.sizeChangeEvents.splice(index, 1);
      }
    }
  }
}
