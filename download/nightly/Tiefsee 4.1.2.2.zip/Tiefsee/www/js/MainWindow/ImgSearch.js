class ImgSearch {
  constructor(M) {
    let arData = M.config.imgSearch.list;
    initMenu();
    function initMenu() {
      let domMenu = document.getElementById("menu-imgSearch");
      var domMenuList = document.getElementById("menu-imgSearch-list");
      function getPath() {
        let path = domMenu.getAttribute("data-path");
        if (path !== null && path !== "") {
          return path;
        } else {
          return M.fileLoad.getFilePath();
        }
      }
      for (let i = 0; i < arData.length; i++) {
        const item = arData[i];
        let name = item.name;
        let icon = item.icon;
        let url = item.url;
        let dom = Lib.newDom(`
                    <div class="menu-hor-item">
                        <div class="menu-hor-icon">
                            <img src="${icon}">
                        </div>
                        <div class="menu-hor-txt">${name}</div>
                    </div>
                `);
        dom.onclick = async () => {
          M.menu.close();
          if (url == "googleSearch") {
            let imgSearchUrl = await googleSearch(getPath());
            if (imgSearchUrl === "") {
              M.msgbox.show({ txt: M.i18n.t("msg.imageSearchFailed") });
              return;
            }
            WV_RunApp.OpenUrl(imgSearchUrl);
          } else {
            let imgUrl = await getWebUrl(getPath());
            if (imgUrl === "") {
              M.msgbox.show({ txt: M.i18n.t("msg.imageSearchFailed") });
              return;
            }
            let imgSearchUrl = url.replace("{url}", imgUrl);
            WV_RunApp.OpenUrl(imgSearchUrl);
          }
        };
        domMenuList?.append(dom);
      }
    }
    async function getBlob(path) {
      let max = 1e3;
      let blob;
      if (M.fileLoad.getIsBulkView() === false && path === M.fileLoad.getFilePath()) {
        let w = M.fileShow.tiefseeview.getOriginalWidth();
        let h = M.fileShow.tiefseeview.getOriginalHeight();
        let zoom = 1;
        if (w * h > max * max) {
          zoom = Math.sqrt(max * max / (w * h));
        }
        blob = await M.fileShow.tiefseeview.getCanvasBlob(zoom, "medium", "jpg");
      } else {
        let fileInfo2 = await WebAPI.getFileInfo2(path);
        let imgData = await M.script.img.getImgData(fileInfo2);
        let w = imgData.width;
        let h = imgData.height;
        let zoom = 1;
        if (w * h > max * max) {
          zoom = Math.sqrt(max * max / (w * h));
        }
        let imtUrl = imgData.arUrl[0].url;
        let p = await M.script.img.preloadImg(imtUrl);
        if (p === false) {
          console.log("\u641C\u5716\u5931\u6557\u3002\u7121\u6CD5\u8F09\u5165\u5716\u7247");
          return null;
        }
        let canvas = await M.script.img.urlToCanvas(imtUrl);
        blob = await M.script.img.getCanvasBlob(canvas, zoom, "medium", "jpg");
      }
      if (blob === void 0) {
        return null;
      }
      return blob;
    }
    async function googleSearch(path) {
      let blob = await getBlob(path);
      if (blob === null) {
        return "";
      }
      let formData = new FormData();
      formData.append("encoded_image", blob, "image.jpg");
      formData.append("sbisrc", "Google Chrome 110.0.5481.78 (Official) Windows");
      let rsp = await fetch("https://www.google.com/searchbyimage/upload", {
        "body": formData,
        "method": "POST"
      });
      let retUrl = "";
      if (rsp.status === 200) {
        retUrl = rsp.url;
        let q = retUrl.indexOf("?");
        if (q !== -1) {
          retUrl = "https://www.google.com/search" + retUrl.substring(q);
        }
      }
      return retUrl;
    }
    async function getWebUrl(path) {
      let blob = await getBlob(path);
      if (blob === null) {
        return "";
      }
      let retUrl = "";
      let imgServer = M.config.imgSearch.imgServer;
      for (let i = 0; i < imgServer.length; i++) {
        const url = imgServer[i].url;
        const timeout = imgServer[i].timeout;
        var formData = new FormData();
        formData.append("key", url);
        formData.append("media", blob, "image.jpg");
        retUrl = await submitPost(url, formData, timeout);
        if (retUrl !== "") {
          return retUrl;
        }
      }
      return "";
    }
    async function submitPost(imgServer, formData, timeout) {
      let json = "";
      const controller = new AbortController();
      const signal = controller.signal;
      const timeoutId = setTimeout(() => controller.abort(), timeout);
      try {
        await fetch(imgServer, {
          "body": formData,
          "method": "POST",
          signal
        }).then((response) => {
          return response.json();
        }).then((html) => {
          json = html;
        });
      } catch (error) {
        json = "";
      } finally {
        clearTimeout(timeoutId);
      }
      if (json === "") {
        return "";
      }
      if (json.status != 200) {
        return "";
      }
      let url = json.data.media;
      if (url.indexOf("http:") == 0) {
        url = url.replace(/^http:\/\//i, "https://");
      }
      return url;
    }
  }
}
