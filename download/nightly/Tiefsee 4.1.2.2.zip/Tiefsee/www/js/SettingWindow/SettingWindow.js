var baseWindow;
var settingWindow;
document.addEventListener("DOMContentLoaded", async () => {
  settingWindow = new SettingWindow();
});
class SettingWindow {
  constructor() {
    baseWindow = new BaseWindow();
    this.saveData = saveSetting;
    var appInfo;
    var config = new Config(baseWindow);
    var mainToolbar = new MainToolbar(null);
    var i18n = new I18n();
    i18n.initNone();
    i18n.pushData(langData);
    var msgbox = new Msgbox(i18n);
    var defaultConfig = new Config(baseWindow).settings;
    var loadEvent = [];
    function addLoadEvent(func) {
      loadEvent.push(func);
    }
    function getDom(selectors) {
      return document.querySelector(selectors);
    }
    baseWindow.onCreate = async (json) => {
      baseWindow.appInfo = json;
      appInfo = json;
      await WV_Window.ShowWindowAtCenter(600 * window.devicePixelRatio, 450 * window.devicePixelRatio);
      WV_Window.SetMinimumSize(400 * window.devicePixelRatio, 300 * window.devicePixelRatio);
      WV_Window.Text = "Setting";
      let iconPath = Lib.Combine([await WV_Window.GetAppDirPath(), "www\\img\\logo.ico"]);
      WV_Window.SetIcon(iconPath);
      if (json.isStoreApp) {
        document.body.setAttribute("showType", "storeApp");
      }
      baseWindow.closingEvents.push(async () => {
        await saveSetting();
      });
      let domLeftBox = getDom("#window-left .pagetab");
      domLeftBox.addEventListener("mousedown", async (e) => {
        if (Lib.isScrollbarVisible(domLeftBox)) {
          return;
        }
        let _dom = e.target;
        if (_dom) {
          if (_dom.classList.contains("js-noDrag")) {
            return;
          }
        }
        if (e.button === 0) {
          await WV_Window.WindowDrag("move");
        }
      });
      domLeftBox.addEventListener("touchstart", async (e) => {
        if (Lib.isScrollbarVisible(domLeftBox)) {
          return;
        }
        let _dom = e.target;
        if (_dom) {
          if (_dom.classList.contains("js-noDrag")) {
            return;
          }
        }
        baseWindow.touchDrop.start(domLeftBox, e, "move");
      });
      tippy(".img-help", {
        onShow(instance) {
          const dataI18n = instance.reference.getAttribute("data-i18n");
          let t = dataI18n;
          if (t !== null) {
            t = i18n.t(dataI18n);
          }
          instance.setContent(t);
        },
        allowHTML: true,
        animation: "tippyMyAnimation",
        theme: "tippyMyTheme",
        arrow: false
      });
      var userSetting = {};
      try {
        userSetting = JSON.parse(json.settingTxt);
      } catch (e) {
      }
      $.extend(true, config.settings, userSetting);
      loadEvent.forEach((func) => {
        func();
      });
    };
    addLoadEvent(() => {
      let dom_select = getDom("#select-lang");
      let configLang = config.settings.other.lang;
      if (configLang == "") {
        configLang = Lib.getBrowserLang();
      }
      dom_select.value = configLang;
      i18n.setLang(configLang);
      dom_select.addEventListener("change", () => {
        let val = dom_select.value;
        config.settings.other.lang = val;
        appleSettingOfMain();
        i18n.setLang(val);
      });
    });
    addLoadEvent(() => {
      var mainToolbarArray = mainToolbar.getArrray();
      const arGroupName = ["img", "pdf", "txt", "bulkView"];
      arGroupName.map((gn) => {
        let groupName = gn;
        var dom_toolbarList = getDom(`#toolbarList-${groupName}`);
        var html = "";
        for (let i = 0; i < mainToolbarArray.length; i++) {
          const item = mainToolbarArray[i];
          if (item.type !== "button") {
            continue;
          }
          let h = `
                        <div class="toolbarList-item" data-name="${item.name}">
                            <input class="toolbarList-checkbox base-checkbox" type="checkbox" data-name="${item.name}" checked>
                            ${SvgList[item.icon]}
                            ${i18n.tSpan(item.i18n)}
                        </div>`;
          if (item.group == groupName) {
            html += h;
          }
        }
        dom_toolbarList.innerHTML = html;
        let arMainToolbar = config.settings.mainToolbar[groupName];
        for (let i = 0; i < arMainToolbar.length; i++) {
          let item = arMainToolbar[i];
          let ardomToolbarList = dom_toolbarList.querySelectorAll(".toolbarList-item");
          let d1 = ardomToolbarList[i];
          let d2 = dom_toolbarList.querySelector(`[data-name=${item.n}]`);
          if (d1 == void 0) {
            break;
          }
          if (d2 === null) {
            continue;
          }
          swapDom(d1, d2);
        }
        for (let i = 0; i < arMainToolbar.length; i++) {
          let item = arMainToolbar[i];
          let d2 = dom_toolbarList.querySelector(`[data-name=${item.n}]`);
          if (d2 === null) {
            continue;
          }
          const domCheckbox = d2.querySelector(".toolbarList-checkbox");
          domCheckbox.checked = item.v;
        }
        let domAr_checkbox = dom_toolbarList.querySelectorAll(".toolbarList-checkbox");
        for (let i = 0; i < domAr_checkbox.length; i++) {
          const domCheckbox = domAr_checkbox[i];
          domCheckbox.onchange = () => {
            let data = getToolbarListData();
            config.settings.mainToolbar = data;
            appleSettingOfMain();
          };
        }
        new Sortable(dom_toolbarList, {
          animation: 150,
          onEnd: (evt) => {
            let data = getToolbarListData();
            config.settings.mainToolbar = data;
            appleSettingOfMain();
          }
        });
      });
      function getToolbarListData() {
        function getItem(type) {
          let ar = [];
          let dom_toolbarList = getDom(`#toolbarList-${type}`);
          let domAr = dom_toolbarList.querySelectorAll(".toolbarList-checkbox");
          for (let i = 0; i < domAr.length; i++) {
            const domCheckbox = domAr[i];
            let name = domCheckbox.getAttribute("data-name") + "";
            let val = domCheckbox.checked;
            ar.push({
              n: name,
              v: val
            });
          }
          return ar;
        }
        let data = {
          img: getItem("img"),
          pdf: getItem("pdf"),
          txt: getItem("txt"),
          bulkView: getItem("bulkView")
        };
        return data;
      }
      var select_toolbarListType = getDom("#select-toolbarListType");
      var dom_toolbarList_img = getDom("#toolbarList-img");
      var dom_toolbarList_pdf = getDom("#toolbarList-pdf");
      var dom_toolbarList_txt = getDom("#toolbarList-txt");
      var dom_toolbarList_bulkView = getDom("#toolbarList-bulkView");
      let eventChange = () => {
        let val = select_toolbarListType.value;
        if (val == "img") {
          dom_toolbarList_img.style.display = "block";
          dom_toolbarList_pdf.style.display = "none";
          dom_toolbarList_txt.style.display = "none";
          dom_toolbarList_bulkView.style.display = "none";
        }
        if (val == "pdf") {
          dom_toolbarList_img.style.display = "none";
          dom_toolbarList_pdf.style.display = "block";
          dom_toolbarList_txt.style.display = "none";
          dom_toolbarList_bulkView.style.display = "none";
        }
        if (val == "txt") {
          dom_toolbarList_img.style.display = "none";
          dom_toolbarList_pdf.style.display = "none";
          dom_toolbarList_txt.style.display = "block";
          dom_toolbarList_bulkView.style.display = "none";
        }
        if (val == "bulkView") {
          dom_toolbarList_img.style.display = "none";
          dom_toolbarList_pdf.style.display = "none";
          dom_toolbarList_txt.style.display = "none";
          dom_toolbarList_bulkView.style.display = "block";
        }
      };
      select_toolbarListType.onchange = eventChange;
      eventChange();
    });
    addLoadEvent(() => {
      var jq_colorWindowBackground = $("#text-colorWindowBackground");
      var jq_colorWindowBorder = $("#text-colorWindowBorder");
      var jq_colorWhite = $("#text-colorWhite");
      var jq_colorBlack = $("#text-colorBlack");
      var jq_colorBlue = $("#text-colorBlue");
      var dom_applyThemeBtns = getDom("#applyTheme-btns");
      addEvent(jq_colorWindowBackground, "--color-window-background", true);
      addEvent(jq_colorWindowBorder, "--color-window-border", true);
      addEvent(jq_colorWhite, "--color-white", false);
      addEvent(jq_colorBlack, "--color-black", false);
      addEvent(jq_colorBlue, "--color-blue", false);
      applyTheme();
      function addEvent(jQdim, name, opacity = false) {
        jQdim.minicolors({
          format: "rgb",
          opacity,
          changeDelay: 10,
          change: function(value, opacity2) {
            let c = jQdim.minicolors("rgbObject");
            config.settings["theme"][name] = c;
            appleSettingOfMain();
          }
        });
      }
      function applyTheme() {
        function setRgb(jqdom, c) {
          jqdom.minicolors("value", `rgb(${c.r}, ${c.g}, ${c.b})`);
        }
        function setRgba(jqdom, c) {
          jqdom.minicolors("value", `rgba(${c.r}, ${c.g}, ${c.b}, ${c.a})`);
        }
        setRgba(jq_colorWindowBackground, config.settings.theme["--color-window-background"]);
        setRgba(jq_colorWindowBorder, config.settings.theme["--color-window-border"]);
        setRgb(jq_colorWhite, config.settings.theme["--color-white"]);
        setRgb(jq_colorBlack, config.settings.theme["--color-black"]);
        setRgb(jq_colorBlue, config.settings.theme["--color-blue"]);
      }
      applyThemeAddBtn(`<div class="btn" i18n="sw.theme.darkTheme">${i18n.t("sw.theme.darkTheme")}</div>`, { r: 31, g: 39, b: 43, a: 0.97 }, { r: 255, g: 255, b: 255, a: 0.25 }, { r: 255, g: 255, b: 255 }, { r: 0, g: 0, b: 0 }, { r: 0, g: 200, b: 255 });
      applyThemeAddBtn(`<div class="btn" i18n="sw.theme.lightTheme">${i18n.t("sw.theme.lightTheme")}</div>`, { r: 255, g: 255, b: 255, a: 0.97 }, { r: 112, g: 112, b: 112, a: 0.25 }, { r: 0, g: 0, b: 0 }, { r: 238, g: 238, b: 238 }, { r: 0, g: 135, b: 220 });
      function applyThemeAddBtn(html, windowBackground, windowBorder, white, black, blue) {
        let btn = Lib.newDom(html);
        btn.onclick = () => {
          config.settings.theme["--color-window-background"] = windowBackground;
          config.settings.theme["--color-window-border"] = windowBorder;
          config.settings.theme["--color-white"] = white;
          config.settings.theme["--color-black"] = black;
          config.settings.theme["--color-blue"] = blue;
          applyTheme();
        };
        dom_applyThemeBtns.append(btn);
      }
    });
    addLoadEvent(() => {
      var select_tiefseeviewZoomType = getDom("#select-tiefseeviewZoomType");
      var text_tiefseeviewZoomValue = getDom("#text-tiefseeviewZoomValue");
      var select_tiefseeviewAlignType = getDom("#select-tiefseeviewAlignType");
      select_tiefseeviewZoomType.value = config.settings.image["tiefseeviewZoomType"];
      text_tiefseeviewZoomValue.value = config.settings.image["tiefseeviewZoomValue"].toString();
      select_tiefseeviewAlignType.value = config.settings.image["tiefseeviewAlignType"];
      if (select_tiefseeviewZoomType.value == "") {
        select_tiefseeviewZoomType.value = "fitWindowOrImageOriginal";
      }
      if (select_tiefseeviewAlignType.value == "") {
        select_tiefseeviewAlignType.value = "center";
      }
      showValue();
      function showValue() {
        let val = select_tiefseeviewZoomType.value;
        let ar = ["imageWidthPx", "imageHeightPx", "windowWidthRatio", "windowHeightRatio"];
        if (ar.indexOf(val) !== -1) {
          text_tiefseeviewZoomValue.style.display = "block";
        } else {
          text_tiefseeviewZoomValue.style.display = "none";
        }
      }
      select_tiefseeviewZoomType.addEventListener("change", () => {
        showValue();
        let val = select_tiefseeviewZoomType.value;
        config.settings.image["tiefseeviewZoomType"] = val;
        appleSettingOfMain();
      });
      text_tiefseeviewZoomValue.addEventListener("change", () => {
        let val = Number(text_tiefseeviewZoomValue.value);
        if (isNaN(val)) {
          val = 100;
        }
        if (val > 99999) {
          val = 99999;
        }
        if (val < 1) {
          val = 1;
        }
        text_tiefseeviewZoomValue.value = val.toString();
        config.settings.image["tiefseeviewZoomValue"] = val;
        appleSettingOfMain();
      });
      select_tiefseeviewAlignType.addEventListener("change", () => {
        let val = select_tiefseeviewAlignType.value;
        config.settings.image["tiefseeviewAlignType"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var select_fileSort = getDom("#select-fileSort");
      var select_dirSort = getDom("#select-dirSort");
      select_fileSort.value = config.settings.sort["fileSort"];
      select_dirSort.value = config.settings.sort["dirSort"];
      select_fileSort.addEventListener("change", () => {
        let val = select_fileSort.value;
        config.settings.sort["fileSort"] = val;
        appleSettingOfMain();
      });
      select_dirSort.addEventListener("change", () => {
        let val = select_dirSort.value;
        config.settings.sort["dirSort"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var text_extension = getDom("#text-extension");
      var btn_extension = getDom("#btn-extension");
      var text_disassociate = getDom("#text-disassociate");
      var btn_disassociate = getDom("#btn-disassociate");
      let s_extension = ["JPG", "JPEG", "PNG", "GIF", "BMP", "SVG", "WEBP"];
      text_extension.value = s_extension.join("\n");
      text_disassociate.value = s_extension.join("\n");
      btn_extension.addEventListener("click", async (e) => {
        let ar_extension = text_extension.value.split("\n");
        let ar = [];
        for (let i = 0; i < ar_extension.length; i++) {
          const item = ar_extension[i].toLocaleLowerCase().trim();
          if (item !== "" && ar.indexOf(item) === -1) {
            ar.push(item);
          }
        }
        msgbox.show({
          txt: i18n.t("msg.associationExtension") + "<br>" + ar.join(", "),
          funcYes: async (dom, inputTxt) => {
            msgbox.close(dom);
            let appPath = await WV_Window.GetAppPath();
            await WV_System.AssociationExtension(ar, appPath);
            msgbox.show({ txt: i18n.t("msg.done") });
          }
        });
      });
      btn_disassociate.addEventListener("click", async (e) => {
        let ar_extension = text_disassociate.value.split("\n");
        let ar = [];
        for (let i = 0; i < ar_extension.length; i++) {
          const item = ar_extension[i].toLocaleLowerCase().trim();
          if (item !== "" && ar.indexOf(item) === -1) {
            ar.push(item);
          }
        }
        msgbox.show({
          txt: i18n.t("msg.removeAssociationExtension") + "<br>" + ar.join(", "),
          funcYes: async (dom, inputTxt) => {
            msgbox.close(dom);
            let appPath = await WV_Window.GetAppPath();
            await WV_System.RemoveAssociationExtension(ar, appPath);
            msgbox.show({ txt: i18n.t("msg.done") });
          }
        });
      });
    });
    addLoadEvent(() => {
      let btn = getDom("#btn-openSystemSettings");
      btn.addEventListener("click", async () => {
        let path = "ms-settings:defaultapps";
        WV_RunApp.OpenUrl(path);
      });
    });
    addLoadEvent(() => {
      var domText = getDom("#text-windowBorderRadius");
      domText.value = config.settings.theme["--window-border-radius"].toString();
      domText.addEventListener("change", () => {
        let val = Number(domText.value);
        if (val < 0) {
          val = 0;
        }
        if (val > 15) {
          val = 15;
        }
        domText.value = val.toString();
        config.settings["theme"]["--window-border-radius"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var domText = getDom("#text-zoomFactor");
      domText.value = config.settings.theme["zoomFactor"].toString();
      domText.addEventListener("change", () => {
        let val = Number(domText.value);
        if (isNaN(val)) {
          val = 1;
        }
        if (val === 0) {
          val = 1;
        }
        if (val < 0.5) {
          val = 0.5;
        }
        if (val > 3) {
          val = 3;
        }
        domText.value = val.toString();
        config.settings["theme"]["zoomFactor"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var domSelect = getDom("#select-fontWeight");
      domSelect.value = config.settings.theme["fontWeight"];
      domSelect.addEventListener("change", () => {
        let val = domSelect.value;
        config.settings["theme"]["fontWeight"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var domSelect = getDom("#select-svgWeight");
      domSelect.value = config.settings.theme["svgWeight"];
      domSelect.addEventListener("change", () => {
        let val = domSelect.value;
        config.settings["theme"]["svgWeight"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var switch_areo = getDom("#select-aeroType");
      switch_areo.value = config.settings["theme"]["aeroType"];
      switch_areo.addEventListener("change", () => {
        let val = switch_areo.value;
        config.settings["theme"]["aeroType"] = val;
      });
      var btn_restart = getDom("#btn-windowAero-restart");
      btn_restart.style.display = "none";
      switch_areo.addEventListener("change", () => {
        btn_restart.style.display = "";
      });
      btn_restart.addEventListener("click", () => {
        restartTiefsee();
      });
    });
    addLoadEvent(() => {
      var switch_mainToolbarEnabled = getDom("#switch-mainToolbarEnabled");
      var select_mainToolbarAlign = getDom("#select-mainToolbarAlign");
      switch_mainToolbarEnabled.checked = config.settings["layout"]["mainToolbarEnabled"];
      select_mainToolbarAlign.value = config.settings["layout"]["mainToolbarAlign"];
      switch_mainToolbarEnabled.addEventListener("change", () => {
        let val = switch_mainToolbarEnabled.checked;
        config.settings["layout"]["mainToolbarEnabled"] = val;
        appleSettingOfMain();
      });
      select_mainToolbarAlign.addEventListener("change", () => {
        let val = select_mainToolbarAlign.value;
        config.settings["layout"]["mainToolbarAlign"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var select_leftDoubleClick = getDom("#select-leftDoubleClick");
      var select_scrollWheelButton = getDom("#select-scrollWheelButton");
      var select_mouseButton4 = getDom("#select-mouseButton4");
      var select_mouseButton5 = getDom("#select-mouseButton5");
      var select_scrollUp = getDom("#select-scrollUp");
      var select_scrollDown = getDom("#select-scrollDown");
      var select_scrollUpCtrl = getDom("#select-scrollUpCtrl");
      var select_scrollDownCtrl = getDom("#select-scrollDownCtrl");
      var select_scrollUpShift = getDom("#select-scrollUpShift");
      var select_scrollDownShift = getDom("#select-scrollDownShift");
      var select_scrollUpAlt = getDom("#select-scrollUpAlt");
      var select_scrollDownAlt = getDom("#select-scrollDownAlt");
      let arDom = [
        { dom: select_leftDoubleClick, config: "leftDoubleClick" },
        { dom: select_scrollWheelButton, config: "scrollWheelButton" },
        { dom: select_mouseButton4, config: "mouseButton4" },
        { dom: select_mouseButton5, config: "mouseButton5" },
        { dom: select_scrollUp, config: "scrollUp" },
        { dom: select_scrollDown, config: "scrollDown" },
        { dom: select_scrollUpCtrl, config: "scrollUpCtrl" },
        { dom: select_scrollDownCtrl, config: "scrollDownCtrl" },
        { dom: select_scrollUpShift, config: "scrollUpShift" },
        { dom: select_scrollDownShift, config: "scrollDownShift" },
        { dom: select_scrollUpAlt, config: "scrollUpAlt" },
        { dom: select_scrollDownAlt, config: "scrollDownAlt" }
      ];
      const data = {
        "image": [
          "imageFitWindowOrImageOriginal",
          "imageFitWindow",
          "imageOriginal",
          "imageZoomIn",
          "imageZoomOut",
          "imageRotateCw",
          "imageRotateCcw",
          "imageFlipHorizontal",
          "imageFlipVertical",
          "imageInitialRotation",
          "imageMoveUp",
          "imageMoveDown",
          "imageMoveLeft",
          "imageMoveRight",
          "imageMoveUpOrPrevFile",
          "imageMoveDownOrNextFile",
          "imageMoveLeftOrPrevFile",
          "imageMoveRightOrNextFile",
          "imageMoveRightOrPrevFile",
          "imageMoveLeftOrNextFile"
        ],
        "file": [
          "prevFile",
          "nextFile",
          "firstFile",
          "lastFile",
          "prevDir",
          "nextDir",
          "firstDir",
          "lastDir",
          "newWindow",
          "revealInFileExplorer",
          "systemContextMenu",
          "openWith",
          "renameFile",
          "fileToRecycleBin",
          "fileToPermanentlyDelete"
        ],
        "copy": [
          "copyFile",
          "copyFileName",
          "copyFilePath",
          "copyImage",
          "copyImageBase64",
          "copyText"
        ],
        "layout": [
          "maximizeWindow",
          "topmost",
          "fullScreen",
          "showToolbar",
          "showDirectoryPanel",
          "showFilePanel",
          "showInformationPanel"
        ]
      };
      let htmlString = `
            <optgroup label="-">
                <option value="none" i18n="script.none"></option>
            </optgroup>
            `;
      for (const key in data) {
        htmlString += `<optgroup label="" i18n="script.${key}">`;
        for (const value of data[key]) {
          htmlString += `<option value="${value}" i18n="script.${value}"></option>`;
        }
        htmlString += `</optgroup>`;
      }
      arDom.forEach((item) => {
        let dom = item.dom;
        dom.innerHTML = htmlString;
        dom.value = config.settings.mouse[item.config];
        dom.addEventListener("change", () => {
          config.settings.mouse[item.config] = dom.value;
          appleSettingOfMain();
        });
      });
    });
    addLoadEvent(() => {
      var select_scrollUpCtrl = getDom("#select-bulkViewScrollUpCtrl");
      var select_scrollDownCtrl = getDom("#select-bulkViewScrollDownCtrl");
      var select_scrollUpShift = getDom("#select-bulkViewScrollUpShift");
      var select_scrollDownShift = getDom("#select-bulkViewScrollDownShift");
      var select_scrollUpAlt = getDom("#select-bulkViewScrollUpAlt");
      var select_scrollDownAlt = getDom("#select-bulkViewScrollDownAlt");
      let arDom = [
        { dom: select_scrollUpCtrl, config: "bulkViewScrollUpCtrl" },
        { dom: select_scrollDownCtrl, config: "bulkViewScrollDownCtrl" },
        { dom: select_scrollUpShift, config: "bulkViewScrollUpShift" },
        { dom: select_scrollDownShift, config: "bulkViewScrollDownShift" },
        { dom: select_scrollUpAlt, config: "bulkViewScrollUpAlt" },
        { dom: select_scrollDownAlt, config: "bulkViewScrollDownAlt" }
      ];
      const data = {
        "bulkView": [
          "prevPage",
          "nextPage",
          "incrColumns",
          "decColumns",
          "incrFixedWidth",
          "decFixedWidth"
        ]
      };
      let htmlString = ``;
      for (const key in data) {
        htmlString += `<optgroup label="" i18n="script.${key}">`;
        for (const value of data[key]) {
          htmlString += `<option value="${value}" i18n="script.${value}"></option>`;
        }
        htmlString += `</optgroup>`;
      }
      arDom.forEach((item) => {
        let dom = item.dom;
        dom.innerHTML = htmlString;
        dom.value = config.settings.mouse[item.config];
        dom.addEventListener("change", () => {
          config.settings.mouse[item.config] = dom.value;
          appleSettingOfMain();
        });
      });
    });
    addLoadEvent(() => {
      var switch_fileListEnabled = getDom("#switch-fileListEnabled");
      var switch_fileListShowNo = getDom("#switch-fileListShowNo");
      var switch_fileListShowName = getDom("#switch-fileListShowName");
      switch_fileListEnabled.checked = config.settings["layout"]["fileListEnabled"];
      switch_fileListShowNo.checked = config.settings["layout"]["fileListShowNo"];
      switch_fileListShowName.checked = config.settings["layout"]["fileListShowName"];
      switch_fileListEnabled.addEventListener("change", () => {
        let val = switch_fileListEnabled.checked;
        config.settings["layout"]["fileListEnabled"] = val;
        appleSettingOfMain();
      });
      switch_fileListShowNo.addEventListener("change", () => {
        let val = switch_fileListShowNo.checked;
        config.settings["layout"]["fileListShowNo"] = val;
        appleSettingOfMain();
      });
      switch_fileListShowName.addEventListener("change", () => {
        let val = switch_fileListShowName.checked;
        config.settings["layout"]["fileListShowName"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var switch_dirListEnabled = getDom("#switch-dirListEnabled");
      var switch_dirListShowNo = getDom("#switch-dirListShowNo");
      var switch_dirListShowName = getDom("#switch-dirListShowName");
      var select_dirListImgNumber = getDom("#select-dirListImgNumber");
      switch_dirListEnabled.checked = config.settings["layout"]["dirListEnabled"];
      switch_dirListShowNo.checked = config.settings["layout"]["dirListShowNo"];
      switch_dirListShowName.checked = config.settings["layout"]["dirListShowName"];
      select_dirListImgNumber.value = config.settings["layout"]["dirListImgNumber"] + "";
      switch_dirListEnabled.addEventListener("change", () => {
        let val = switch_dirListEnabled.checked;
        config.settings["layout"]["dirListEnabled"] = val;
        appleSettingOfMain();
      });
      switch_dirListShowNo.addEventListener("change", () => {
        let val = switch_dirListShowNo.checked;
        config.settings["layout"]["dirListShowNo"] = val;
        appleSettingOfMain();
      });
      switch_dirListShowName.addEventListener("change", () => {
        let val = switch_dirListShowName.checked;
        config.settings["layout"]["dirListShowName"] = val;
        appleSettingOfMain();
      });
      select_dirListImgNumber.addEventListener("change", () => {
        let val = Number(select_dirListImgNumber.value);
        config.settings["layout"]["dirListImgNumber"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var switch_mainExifEnabled = getDom("#switch-mainExifEnabled");
      switch_mainExifEnabled.checked = config.settings["layout"]["mainExifEnabled"];
      switch_mainExifEnabled.addEventListener("change", () => {
        let val = switch_mainExifEnabled.checked;
        config.settings["layout"]["mainExifEnabled"] = val;
        appleSettingOfMain();
      });
      var switch_mainExifHorizontal = getDom("#switch-mainExifHorizontal");
      switch_mainExifHorizontal.checked = config.settings["layout"]["mainExifHorizontal"];
      switch_mainExifHorizontal.addEventListener("change", () => {
        let val = switch_mainExifHorizontal.checked;
        config.settings["layout"]["mainExifHorizontal"] = val;
        appleSettingOfMain();
      });
      var text_mainExifMaxLine = getDom("#text-mainExifMaxLine");
      text_mainExifMaxLine.value = config.settings["layout"]["mainExifMaxLine"] + "";
      text_mainExifMaxLine.addEventListener("change", () => {
        let val = Math.floor(Number(text_mainExifMaxLine.value));
        if (val > 1e3) {
          val = 1e3;
        }
        if (val <= 0) {
          val = 1;
        }
        text_mainExifMaxLine.value = val + "";
        config.settings["layout"]["mainExifMaxLine"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      Lib.setRadio("[name='largeBtn']", config.settings.layout.largeBtn);
      let domRadio = getDom("#largeBtn-group");
      domRadio.addEventListener("change", () => {
        let val = Lib.getRadio("[name='largeBtn']");
        config.settings.layout.largeBtn = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var select_imageDpizoom = getDom("#select-imageDpizoom");
      select_imageDpizoom.value = config.settings["image"]["dpizoom"];
      select_imageDpizoom.addEventListener("change", () => {
        let val = select_imageDpizoom.value;
        config.settings["image"]["dpizoom"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var select_tiefseeviewBigimgscaleRatio = getDom("#select-tiefseeviewBigimgscaleRatio");
      select_tiefseeviewBigimgscaleRatio.value = config.settings["image"]["tiefseeviewBigimgscaleRatio"].toString();
      select_tiefseeviewBigimgscaleRatio.addEventListener("change", () => {
        let val = select_tiefseeviewBigimgscaleRatio.value;
        config.settings["image"]["tiefseeviewBigimgscaleRatio"] = Number(val);
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var domText = getDom("#text-bulkViewImgMaxCount");
      domText.value = config.settings.bulkView.imgMaxCount.toString();
      domText.addEventListener("change", () => {
        let val = Number(domText.value);
        if (isNaN(val)) {
          val = 100;
        }
        if (val > 300) {
          val = 300;
        }
        if (val < 1) {
          val = 1;
        }
        val = Math.floor(val);
        domText.value = val.toString();
        config.settings.bulkView.imgMaxCount = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var switch_imageShowPixels = getDom("#switch-imageShowPixels");
      switch_imageShowPixels.checked = config.settings["image"]["tiefseeviewImageRendering"] == "2";
      switch_imageShowPixels.addEventListener("change", () => {
        let val = switch_imageShowPixels.checked;
        if (val) {
          config.settings["image"]["tiefseeviewImageRendering"] = "2";
        } else {
          config.settings["image"]["tiefseeviewImageRendering"] = "0";
        }
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var btn_openAppData = getDom("#btn-openAppData");
      var btn_openWww = getDom("#btn-openWww");
      var btn_openTemp = getDom("#btn-openTemp");
      btn_openAppData.addEventListener("click", async () => {
        let path = await WV_Window.GetAppDataPath();
        WV_RunApp.OpenUrl(path);
      });
      btn_openWww.addEventListener("click", async () => {
        let path = await WV_Window.GetAppDirPath();
        path = Lib.Combine([path, "www"]);
        WV_RunApp.OpenUrl(path);
      });
      btn_openTemp.addEventListener("click", async () => {
        let path = await WV_Path.GetTempPath();
        path = Lib.Combine([path, "Tiefsee"]);
        if (await WV_Directory.Exists(path) === false) {
          await WV_Directory.CreateDirectory(path);
        }
        WV_RunApp.OpenUrl(path);
      });
    });
    addLoadEvent(() => {
      var btn_clearBrowserCache = getDom("#btn-clearBrowserCache");
      btn_clearBrowserCache.addEventListener("click", async () => {
        await WV_System.DeleteAllTemp();
        await WV_Window.ClearBrowserCache();
        msgbox.show({ txt: i18n.t("msg.tempDeleteCompleted") });
      });
    });
    addLoadEvent(() => {
      var select_dirListMaxCount = getDom("#select-dirListMaxCount");
      select_dirListMaxCount.value = config.settings["advanced"]["dirListMaxCount"] + "";
      select_dirListMaxCount.addEventListener("change", () => {
        let val = Number(select_dirListMaxCount.value);
        config.settings["advanced"]["dirListMaxCount"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var select_highQualityLimit = getDom("#select-highQualityLimit");
      select_highQualityLimit.value = config.settings["advanced"]["highQualityLimit"] + "";
      select_highQualityLimit.addEventListener("change", () => {
        let val = Number(select_highQualityLimit.value);
        config.settings["advanced"]["highQualityLimit"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      var text_startPort = getDom("#text-startPort");
      var text_serverCache = getDom("#text-serverCache");
      var btn_restart = getDom("#btn-startupMode-restart");
      Lib.setRadio("[name='radio-startType']", appInfo.startType.toString());
      text_startPort.value = appInfo.startPort.toString();
      text_serverCache.value = appInfo.serverCache.toString();
      btn_restart.style.display = "none";
      $("[name='radio-startType']").on("change", () => {
        btn_restart.style.display = "";
      });
      text_startPort.addEventListener("change", () => {
        let startPort = parseInt(text_startPort.value);
        if (isNaN(startPort)) {
          startPort = 4876;
        }
        if (startPort > 65535) {
          startPort = 65535;
        }
        if (startPort < 1024) {
          startPort = 1024;
        }
        text_startPort.value = startPort.toString();
      });
      baseWindow.closingEvents.push(async () => {
        let startPort = parseInt(text_startPort.value);
        let startType = Lib.getRadio("[name='radio-startType']");
        let serverCache = parseInt(text_serverCache.value);
        if (isNaN(startPort)) {
          startPort = 4876;
        }
        if (startPort > 65535) {
          startPort = 65535;
        }
        if (startPort < 1024) {
          startPort = 1024;
        }
        if (startType.search(/^[1|2|3|4|5]$/) !== 0) {
          startType = 2;
        }
        startType = parseInt(startType);
        if (isNaN(serverCache)) {
          serverCache = 0;
        }
        if (serverCache > 31536e3) {
          serverCache = 31536e3;
        }
        if (serverCache < 0) {
          serverCache = 0;
        }
        await WV_Window.SetStartIni(startPort, startType, serverCache);
      });
      btn_restart.addEventListener("click", async () => {
        restartTiefsee();
      });
    });
    addLoadEvent(() => {
      var btn_resetSettings = getDom("#btn-resetSettings");
      btn_resetSettings.addEventListener("click", async (e) => {
        msgbox.show({
          txt: i18n.t("msg.resetSettings"),
          funcYes: async (dom, inputTxt) => {
            msgbox.close(dom);
            config.settings = defaultConfig;
            Lib.setRadio("[name='radio-startType']", "3");
            let text_startPort = getDom("#text-startPort");
            text_startPort.value = "4876";
            var switch_autoStart = getDom("#switch-autoStart");
            switch_autoStart.checked = false;
            switch_autoStart.dispatchEvent(new Event("change"));
            await Lib.sleep(300);
            await WV_System.DeleteAllTemp();
            await WV_Window.ClearBrowserCache();
            restartTiefsee();
          }
        });
      });
    });
    addLoadEvent(async () => {
      var switch_autoStart = getDom("#switch-autoStart");
      if (appInfo.isStoreApp) {
        let TiefseTask = await WV_System.GetTiefseTask();
        if (TiefseTask === "Enabled" || TiefseTask === "EnabledByPolicy") {
          switch_autoStart.checked = true;
        } else {
          switch_autoStart.checked = false;
        }
        switch_autoStart.addEventListener("change", async () => {
          let val = switch_autoStart.checked;
          let TiefseTask2 = await WV_System.SetTiefseTask(val);
          let msg = null;
          if (TiefseTask2 === "EnabledByPolicy") {
            msg = i18n.t("msg.enabledByPolicy");
            switch_autoStart.checked = true;
          }
          if (TiefseTask2 === "DisabledByPolicy") {
            msg = i18n.t("msg.disabledByPolicy");
            switch_autoStart.checked = false;
          }
          if (TiefseTask2 === "DisabledByUser") {
            msg = i18n.t("msg.disabledByUser");
            switch_autoStart.checked = false;
          }
          if (msg !== null) {
            msgbox.show({ txt: msg });
          }
        });
      } else {
        let startupPath = await WV_Path.GetFolderPathStartup();
        let linkPath = Lib.Combine([startupPath, "Tiefsee.lnk"]);
        let isAutoStart = await WV_File.Exists(linkPath);
        switch_autoStart.checked = isAutoStart;
        switch_autoStart.addEventListener("change", async () => {
          let val = switch_autoStart.checked;
          if (val) {
            let exePath = await WV_Window.GetAppPath();
            WV_System.NewLnk(exePath, linkPath, "none");
          } else {
            WV_File.Delete(linkPath);
          }
        });
        var btn_openStartup = getDom("#btn-openStartup");
        btn_openStartup.addEventListener("click", async () => {
          WV_RunApp.OpenUrl(startupPath);
        });
      }
    });
    addLoadEvent(() => {
      function getHtml(val) {
        if (val) {
          return `<div class="pluginLiet-status color-success">Installed</div>`;
        } else {
          return `<div class="pluginLiet-status color-warning">Not Installed</div>`;
        }
      }
      if (baseWindow.appInfo !== void 0) {
        var dom_QuickLook = getDom("#pluginLiet-QuickLook");
        var dom_PDFTronWebviewer = getDom("#pluginLiet-PDFTronWebviewer");
        var dom_MonacoEditor = getDom("#pluginLiet-MonacoEditor");
        dom_QuickLook.innerHTML = getHtml(baseWindow.appInfo.plugin.QuickLook);
        dom_PDFTronWebviewer.innerHTML = getHtml(baseWindow.appInfo.plugin.PDFTronWebviewer);
        dom_MonacoEditor.innerHTML = getHtml(baseWindow.appInfo.plugin.MonacoEditor);
        let dom_noInstalled = getDom("#quickLook-noInstalled");
        let dom_box = getDom("#quickLook-box");
        if (baseWindow.appInfo.plugin.QuickLook) {
          dom_noInstalled.style.display = "none";
          dom_box.style.opacity = "1";
          dom_box.style.pointerEvents = "";
        } else {
          dom_noInstalled.style.display = "block";
          dom_box.style.opacity = "0.5";
          dom_box.style.pointerEvents = "none";
        }
      }
      getDom("#btn-openPluginDownload")?.addEventListener("click", () => {
        WV_RunApp.OpenUrl("https://hbl917070.github.io/aeropic/plugin.html");
      });
      getDom("#btn-openPluginDir")?.addEventListener("click", async () => {
        let path = await WV_Window.GetAppDataPath();
        path = Lib.Combine([path, "Plugin"]);
        if (await WV_Directory.Exists(path) === false) {
          await WV_Directory.CreateDirectory(path);
        }
        WV_RunApp.OpenUrl(path);
      });
      let btn_restart = getDom("#btn-plugin-restart");
      btn_restart.addEventListener("click", () => {
        restartTiefsee();
      });
    });
    addLoadEvent(() => {
      var switch_keyboardSpaceRun = getDom("#switch-keyboardSpaceRun");
      var switch_mouseMiddleRun = getDom("#switch-mouseMiddleRun");
      switch_keyboardSpaceRun.checked = config.settings.quickLook.keyboardSpaceRun;
      switch_mouseMiddleRun.checked = config.settings.quickLook.mouseMiddleRun;
      switch_keyboardSpaceRun.addEventListener("change", () => {
        let val = switch_keyboardSpaceRun.checked;
        config.settings.quickLook.keyboardSpaceRun = val;
        saveSetting();
      });
      switch_mouseMiddleRun.addEventListener("change", () => {
        let val = switch_mouseMiddleRun.checked;
        config.settings.quickLook.mouseMiddleRun = val;
        saveSetting();
      });
    });
    addLoadEvent(() => {
      var switch_fileDeletingShowCheckMsg = getDom("#switch-fileDeletingShowCheckMsg");
      switch_fileDeletingShowCheckMsg.checked = config.settings["other"]["fileDeletingShowCheckMsg"];
      switch_fileDeletingShowCheckMsg.addEventListener("change", () => {
        let val = switch_fileDeletingShowCheckMsg.checked;
        config.settings["other"]["fileDeletingShowCheckMsg"] = val;
        appleSettingOfMain();
      });
      var select_whenInsertingFile = getDom("#select-whenInsertingFile");
      select_whenInsertingFile.value = config.settings["other"]["whenInsertingFile"];
      select_whenInsertingFile.addEventListener("change", () => {
        let val = select_whenInsertingFile.value;
        config.settings["other"]["whenInsertingFile"] = val;
        appleSettingOfMain();
      });
    });
    addLoadEvent(() => {
      i18n.setAll();
    });
    addLoadEvent(() => {
      function goTop() {
        getDom("#window-body")?.scrollTo(0, 0);
      }
      var tabs = new Tabs();
      tabs.add(getDom("#tabsBtn-general"), getDom("#tabsPage-general"), () => {
        goTop();
      });
      tabs.add(getDom("#tabsBtn-appearance"), getDom("#tabsPage-appearance"), () => {
        goTop();
      });
      tabs.add(getDom("#tabsBtn-layout"), getDom("#tabsPage-layout"), () => {
        goTop();
      });
      tabs.add(getDom("#tabsBtn-toolbar"), getDom("#tabsPage-toolbar"), () => {
        goTop();
      });
      tabs.add(getDom("#tabsBtn-mouse"), getDom("#tabsPage-mouse"), () => {
        goTop();
      });
      tabs.add(getDom("#tabsBtn-extension"), getDom("#tabsPage-extension"), () => {
        goTop();
      });
      tabs.add(getDom("#tabsBtn-advanced"), getDom("#tabsPage-advanced"), () => {
        goTop();
      });
      tabs.add(getDom("#tabsBtn-about"), getDom("#tabsPage-about"), () => {
        goTop();
      });
      tabs.add(getDom("#tabsBtn-plugin"), getDom("#tabsPage-plugin"), () => {
        goTop();
      });
      tabs.add(getDom("#tabsBtn-quickLook"), getDom("#tabsPage-quickLook"), () => {
        goTop();
      });
      tabs.set(getDom("#tabsBtn-general"));
      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
      const toPage = urlParams.get("toPage");
      const toDom = urlParams.get("toDom");
      if (toPage !== null && toPage !== "") {
        tabs.set(getDom(`#tabsBtn-${toPage}`));
      }
      if (toDom !== null && toDom !== "") {
        const element = document.querySelector(`[data-toDom="${toDom}"]`);
        element?.scrollIntoView();
      }
    });
    function swapDom(a, b) {
      if (a.parentNode === null || b.parentNode === null) {
        return;
      }
      if (a == b) {
        return;
      }
      var aParent = a.parentNode;
      var bParent = b.parentNode;
      var aHolder = document.createElement("div");
      var bHolder = document.createElement("div");
      aParent.replaceChild(aHolder, a);
      bParent.replaceChild(bHolder, b);
      aParent.replaceChild(b, aHolder);
      bParent.replaceChild(a, bHolder);
    }
    function appleSettingOfMain() {
      WV_Window.RunJsOfParent(`mainWindow.applySetting(${JSON.stringify(config.settings)})`);
    }
    async function saveSetting() {
      appleSettingOfMain();
      let s = JSON.stringify(config.settings, null, "	");
      var path = await WV_Window.GetAppDataPath();
      path = Lib.Combine([path, "Setting.json"]);
      await WV_File.SetText(path, s);
    }
    async function restartTiefsee() {
      let arFunc = baseWindow.closingEvents;
      for (let i = 0; i < arFunc.length; i++) {
        await arFunc[i]();
      }
      let imgPath = JSON.parse(await WV_Window.RunJsOfParent(`mainWindow.fileLoad.getFilePath()`));
      if (imgPath === null) {
        imgPath = "";
      }
      imgPath = `"${imgPath}"`;
      let exePath = await WV_Window.GetAppPath();
      WV_RunApp.ProcessStart(exePath, imgPath, true, false);
      WV_Window.CloseAllWindow();
    }
  }
}
class Tabs {
  constructor() {
    this.ar = [];
  }
  activeEvent(btn, page, func) {
    for (let i = 0; i < this.ar.length; i++) {
      const item = this.ar[i];
      item.btn?.setAttribute("active", "");
      item.page?.setAttribute("active", "");
    }
    btn?.setAttribute("active", "true");
    page?.setAttribute("active", "true");
    func();
  }
  set(btn) {
    for (let i = 0; i < this.ar.length; i++) {
      const item = this.ar[i];
      if (btn === item.btn) {
        this.activeEvent(btn, item.page, item.func);
      }
    }
  }
  add(btn, page, func) {
    this.ar.push({ btn, page, func });
    btn?.addEventListener("click", () => {
      this.activeEvent(btn, page, func);
    });
  }
}
