const WV2 = window.chrome.webview.hostObjects;
const WV_Window = WV2.WV_Window;
const WV_Directory = WV2.WV_Directory;
const WV_File = WV2.WV_File;
const WV_Path = WV2.WV_Path;
const WV_System = WV2.WV_System;
const WV_RunApp = WV2.WV_RunApp;
const WV_Image = WV2.WV_Image;
const APIURL = "http://127.0.0.1:" + location.hash.replace("#", "");
var temp_dropPath = "";
class BaseWindow {
  constructor() {
    this.topMost = false;
    this.left = 0;
    this.top = 0;
    this.width = 0;
    this.height = 0;
    this.zoomFactor = 1;
    this.windowState = "Normal";
    this.closingEvents = [];
    this.sizeChangeEvents = [];
    this.fileWatcherEvents = [];
    this.touchDrop = new TouchDrop(this);
    var dom_window = document.querySelector(".window");
    var btn_normal = document.querySelector(".titlebar-toolbar-normal");
    var btn_minimized = document.querySelector(".titlebar-toolbar-minimized");
    var btn_maximized = document.querySelector(".titlebar-toolbar-maximized");
    var btn_close = document.querySelector(".titlebar-toolbar-close");
    var dom_titlebarTxt = document.querySelector(".titlebar-txt");
    this.dom_window = dom_window;
    this.btn_normal = btn_normal;
    this.btn_minimized = btn_minimized;
    this.btn_maximized = btn_maximized;
    this.btn_close = btn_close;
    this.dom_titlebarTxt = dom_titlebarTxt;
    (async () => {
      this.windowState = await WV_Window.WindowState;
      this.updateWindowState();
    })();
    btn_normal?.addEventListener("click", async (e) => {
      this.normal();
    });
    btn_minimized?.addEventListener("click", async (e) => {
      this.minimized();
    });
    btn_maximized?.addEventListener("click", async (e) => {
      this.maximized();
    });
    btn_close?.addEventListener("click", async (e) => {
      this.close();
    });
    Lib.addEventDblclick(dom_titlebarTxt, async () => {
      let WindowState = this.windowState;
      if (WindowState === "Maximized") {
        this.normal();
      } else {
        setTimeout(() => {
          this.maximized();
        }, 50);
      }
    });
    dom_window.addEventListener("wheel", (e) => {
      if (e.ctrlKey === true) {
        e.preventDefault();
      }
    }, true);
    dom_window.addEventListener("touchstart", (e) => {
      if (e.touches.length > 1) {
        e.preventDefault();
      }
    }, false);
    windowBorder(document.querySelector(".window-CT"), "CT");
    windowBorder(document.querySelector(".window-RC"), "RC");
    windowBorder(document.querySelector(".window-CB"), "CB");
    windowBorder(document.querySelector(".window-LC"), "LC");
    windowBorder(document.querySelector(".window-LT"), "LT");
    windowBorder(document.querySelector(".window-RT"), "RT");
    windowBorder(document.querySelector(".window-LB"), "LB");
    windowBorder(document.querySelector(".window-RB"), "RB");
    function windowBorder(_dom, _type) {
      _dom.addEventListener("mousedown", async (e) => {
        if (e.button === 0) {
          await WV_Window.WindowDrag(_type);
        }
      });
      _dom.addEventListener("touchstart", async (e) => {
      });
      _dom.addEventListener("touchstart", async (e) => {
        baseWindow.touchDrop.start(_dom, e, _type);
      });
    }
  }
  async getDropPath() {
    let _dropPath = "";
    for (let i = 0; i < 100; i++) {
      if (temp_dropPath !== "") {
        _dropPath = Lib.URLToPath(temp_dropPath);
        break;
      }
      await Lib.sleep(10);
    }
    temp_dropPath = "";
    _dropPath = _dropPath.replace(/[/]/g, "\\");
    return _dropPath;
  }
  async setTitle(txt) {
    WV_Window.Text = txt;
    this.dom_titlebarTxt.innerHTML = `<span>${txt}</span>`;
  }
  async newWindow(_name) {
    let url = _name;
    var w = await WV_Window.NewSubWindow(url, []);
    return w;
  }
  async close() {
    let isClose = true;
    for (let i = 0; i < this.closingEvents.length; i++) {
      let val = await this.closingEvents[i]();
      if (val === false) {
        isClose = false;
      }
    }
    if (isClose) {
      WV_Window.Close();
    }
  }
  setZoomFactor(d) {
    this.zoomFactor = d;
    WV_Window.SetZoomFactor(d);
  }
  maximized() {
    WV_Window.WindowState = "Maximized";
    this.updateWindowState();
  }
  minimized() {
    WV_Window.WindowState = "Minimized";
  }
  normal() {
    WV_Window.WindowState = "Normal";
    this.updateWindowState();
  }
  updateWindowState() {
    if (this.windowState === "Maximized") {
      this.dom_window.classList.add("maximized");
      this.btn_normal.style.display = "flex";
      this.btn_maximized.style.display = "none";
    } else {
      this.dom_window.classList.remove("maximized");
      this.btn_normal.style.display = "none";
      this.btn_maximized.style.display = "flex";
    }
  }
  onCreate(json) {
    WV_Window.ShowWindow();
  }
  async onSizeChanged(left, top, width, height, windowState) {
    this.left = left;
    this.top = top;
    this.width = width;
    this.height = height;
    this.windowState = windowState;
    this.updateWindowState();
    for (let i = 0; i < this.sizeChangeEvents.length; i++) {
      await this.sizeChangeEvents[i]();
    }
  }
  onMove(left, top, width, height, windowState) {
    this.left = left;
    this.top = top;
    this.width = width;
    this.height = height;
    this.windowState = windowState;
  }
  async onFileWatcher(arData) {
    for (let i = 0; i < this.fileWatcherEvents.length; i++) {
      let newArDate = arData.map((a) => {
        return { ...a };
      });
      await this.fileWatcherEvents[i](newArDate);
    }
  }
  onRightClick(x, y) {
  }
  onNewWindowRequested(url) {
    console.log("onNewWindowRequested\uFF1A" + url);
  }
}
class TouchDrop {
  constructor(baseWindow2) {
    this.start = start;
    let temp_touchX = 0;
    let temp_touchY = 0;
    let temp_touchWindowX = 0;
    let temp_touchWindowY = 0;
    let temp_touchWindowW = 0;
    let temp_touchWindowH = 0;
    let temp_start = false;
    var touchMoveThrottle = new Throttle(20);
    function start(_dom, e, _type) {
      touchstart(e);
      async function touchstart(e2) {
        if (baseWindow2.windowState !== "Normal") {
          return;
        }
        if (e2.changedTouches.length !== 1) {
          end();
          return;
        }
        _dom.addEventListener("touchmove", touchmove);
        _dom.addEventListener("touchend", touchend);
        temp_touchX = e2.changedTouches[0].screenX;
        temp_touchY = e2.changedTouches[0].screenY;
        temp_touchWindowX = baseWindow2.left;
        temp_touchWindowY = baseWindow2.top;
        temp_touchWindowW = baseWindow2.width;
        temp_touchWindowH = baseWindow2.height;
        temp_start = true;
      }
      async function touchmove(e2) {
        if (temp_start !== true) {
          return;
        }
        if (e2.changedTouches.length !== 1) {
          end();
          return;
        }
        let x = e2.changedTouches[0].screenX - temp_touchX;
        let y = e2.changedTouches[0].screenY - temp_touchY;
        touchMoveThrottle.run = async () => {
          if (_type === "move") {
            await WV_Window.SetPosition(temp_touchWindowX + x, temp_touchWindowY + y);
            temp_touchWindowX = temp_touchWindowX + x;
            temp_touchWindowY = temp_touchWindowY + y;
          } else if (_type === "RB") {
            await WV_Window.SetSize(temp_touchWindowW + x, temp_touchWindowH + y);
          } else if (_type === "CB") {
            await WV_Window.SetSize(temp_touchWindowW, temp_touchWindowH + y);
          } else if (_type === "RC") {
            await WV_Window.SetSize(temp_touchWindowW + x, temp_touchWindowH);
          } else if (_type === "CT") {
            await WV_Window.SetSize(temp_touchWindowW, temp_touchWindowH - y);
            await WV_Window.SetPosition(temp_touchWindowX, temp_touchWindowY + y);
            temp_touchWindowY = temp_touchWindowY + y;
            temp_touchWindowH = temp_touchWindowH - y;
          } else if (_type === "LC") {
            await WV_Window.SetSize(temp_touchWindowW - x, temp_touchWindowH);
            await WV_Window.SetPosition(temp_touchWindowX + x, temp_touchWindowY);
            temp_touchWindowX = temp_touchWindowX + x;
            temp_touchWindowW = temp_touchWindowW - x;
          } else if (_type === "LT") {
            await WV_Window.SetSize(temp_touchWindowW - x, temp_touchWindowH - y);
            await WV_Window.SetPosition(temp_touchWindowX + x, temp_touchWindowY + y);
            temp_touchWindowX = temp_touchWindowX + x;
            temp_touchWindowY = temp_touchWindowY + y;
            temp_touchWindowW = temp_touchWindowW - x;
            temp_touchWindowH = temp_touchWindowH - y;
          } else if (_type === "LB") {
            await WV_Window.SetSize(temp_touchWindowW - x, temp_touchWindowH + y);
            await WV_Window.SetPosition(temp_touchWindowX + x, temp_touchWindowY);
            temp_touchWindowX = temp_touchWindowX + x;
            temp_touchWindowW = temp_touchWindowW - x;
          } else if (_type === "RT") {
            await WV_Window.SetSize(temp_touchWindowW + x, temp_touchWindowH - y);
            await WV_Window.SetPosition(temp_touchWindowX, temp_touchWindowY + y);
            temp_touchWindowY = temp_touchWindowY + y;
            temp_touchWindowH = temp_touchWindowH - y;
          }
        };
      }
      async function touchend(e2) {
        end();
      }
      function end() {
        temp_start = false;
        _dom.removeEventListener("touchmove", touchmove);
        _dom.removeEventListener("touchend", touchend);
      }
    }
  }
}
