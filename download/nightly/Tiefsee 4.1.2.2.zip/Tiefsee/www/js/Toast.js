const _Toast = class {
};
let Toast = _Toast;
Toast.domToastList = void 0;
Toast.show = (txt, ms) => {
  if (_Toast.domToastList === void 0) {
    _Toast.domToastList = document.createElement("div");
    _Toast.domToastList.setAttribute("class", "toastList base-scrollbar");
    document.body.appendChild(_Toast.domToastList);
  }
  txt = Lib.escape(txt);
  txt = txt.replace(/[\n]/g, "<br>");
  let domItem = Lib.newDom(`
                <div class="toastItem">
                    <div class="toastTxt">${txt}</div>
                    <div class="toastClose"></div>
                </div>
            `);
  setTimeout(() => {
    if (domItem !== void 0) {
      _Toast.domToastList?.removeChild(domItem);
    }
  }, ms);
  let toastClose = domItem.querySelector(".toastClose");
  toastClose.onclick = () => {
    if (domItem === void 0) {
      return;
    }
    _Toast.domToastList?.removeChild(domItem);
    domItem = void 0;
  };
  _Toast.domToastList.insertBefore(domItem, _Toast.domToastList.firstChild);
};
