# Installation
> `npm install --save @types/sortablejs`

# Summary
This package contains type definitions for Sortable.js (https://github.com/RubaXa/Sortable).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/sortablejs.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 16:35:06 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Maw-Fox](https://github.com/Maw-Fox), [Maarten Staa](https://github.com/maartenstaa), and [Wayne Van Son](https://github.com/waynevanson).
