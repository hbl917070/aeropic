// https://github.com/atomiks/tippyjs

declare var tippy: any;